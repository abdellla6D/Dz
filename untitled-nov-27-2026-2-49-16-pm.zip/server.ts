import 'dotenv/config';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import cookieParser from 'cookie-parser';
import express from 'express';
import { authRouter } from './server/auth.ts';
import { geminiRouter } from './server/gemini.ts';
import { attachLiveWebSocketServer } from './server/live.ts';
import { oauthApiRouter, oauthCallbackRouter } from './server/oauth.ts';
import { projectsRouter } from './server/projects.ts';
import { publishRouter } from './server/publish.ts';

async function startServer(): Promise<void> {
  const app = express();
  const port = Number(process.env.PORT) || 3000;
  const isProd = process.env.NODE_ENV === 'production';

  app.set('trust proxy', 1);

  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  app.use(cookieParser());
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, service: 'storymaster-ai-publisher' });
  });

  app.use('/api/auth', authRouter);
  app.use('/api/oauth', oauthApiRouter);
  app.use('/auth', oauthCallbackRouter);
  app.use('/api/ai', geminiRouter);
  app.use('/api/projects', projectsRouter);
  app.use('/api/publish', publishRouter);

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir, { index: false }));
    app.get('*', (_req, res) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build output not found. Run npm run build first.');
      }
    });
  }

  const server = http.createServer(app);
  attachLiveWebSocketServer(server);

  server.listen(port, '0.0.0.0', () => {
    console.log(`StoryMaster AI Publisher listening on http://0.0.0.0:${port}`);
  });
}

void startServer();
