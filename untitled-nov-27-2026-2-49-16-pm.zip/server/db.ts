import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

const dbPath = path.resolve(process.cwd(), process.env.DATABASE_PATH || './data/storymaster.db');
const dbDir = path.dirname(dbPath);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

export const db = new DatabaseSync(dbPath);

db.exec('PRAGMA foreign_keys = ON;');
db.exec('PRAGMA journal_mode = WAL;');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE,
    name TEXT NOT NULL,
    avatar_url TEXT,
    password_hash TEXT,
    recovery_key_hash TEXT,
    bio TEXT NOT NULL DEFAULT '',
    preferred_language TEXT NOT NULL DEFAULT 'ar',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS password_resets (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    code_hash TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    used INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS oauth_states (
    state_id TEXT PRIMARY KEY,
    provider TEXT NOT NULL,
    mode TEXT NOT NULL,
    user_id TEXT,
    code_verifier TEXT,
    redirect_uri TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS oauth_exchange_codes (
    code_hash TEXT PRIMARY KEY,
    session_token TEXT NOT NULL,
    provider TEXT NOT NULL,
    mode TEXT NOT NULL,
    expires_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS oauth_accounts (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider TEXT NOT NULL,
    provider_user_id TEXT NOT NULL,
    display_name TEXT,
    username TEXT,
    avatar_url TEXT,
    email TEXT,
    access_token_enc TEXT NOT NULL,
    refresh_token_enc TEXT,
    token_expires_at TEXT,
    scopes TEXT NOT NULL DEFAULT '',
    metadata_json TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(provider, provider_user_id),
    UNIQUE(user_id, provider)
  );

  CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    topic TEXT NOT NULL DEFAULT '',
    language TEXT NOT NULL DEFAULT 'ar',
    genre TEXT NOT NULL DEFAULT 'cinematic',
    aspect_ratio TEXT NOT NULL DEFAULT '9:16',
    story_text TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'draft',
    voice_name TEXT NOT NULL DEFAULT 'Kore',
    voice_style TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS scenes (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    scene_order INTEGER NOT NULL,
    title TEXT NOT NULL,
    narration_text TEXT NOT NULL,
    image_prompt TEXT NOT NULL,
    image_data_url TEXT,
    audio_data_url TEXT,
    duration_sec REAL NOT NULL DEFAULT 6,
    transition TEXT NOT NULL DEFAULT 'fade',
    subtitle_enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS publish_jobs (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    project_id TEXT REFERENCES projects(id) ON DELETE SET NULL,
    platform TEXT NOT NULL,
    target_id TEXT,
    target_name TEXT,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    privacy_level TEXT,
    status TEXT NOT NULL,
    external_post_id TEXT,
    error_message TEXT,
    created_at TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
  CREATE INDEX IF NOT EXISTS idx_projects_user ON projects(user_id);
  CREATE INDEX IF NOT EXISTS idx_scenes_project ON scenes(project_id, scene_order);
  CREATE INDEX IF NOT EXISTS idx_publish_user ON publish_jobs(user_id);
`);

try {
  db.exec('ALTER TABLE users ADD COLUMN firebase_uid TEXT');
} catch {
  // Column already exists
}
try {
  db.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_firebase_uid ON users(firebase_uid) WHERE firebase_uid IS NOT NULL');
} catch {
  // Index already exists
}

export interface UserRow {
  id: string;
  email: string | null;
  name: string;
  avatar_url: string | null;
  password_hash: string | null;
  recovery_key_hash: string | null;
  bio: string;
  preferred_language: string;
  firebase_uid?: string | null;
  created_at: string;
  updated_at: string;
}

export interface OAuthAccountRow {
  id: string;
  user_id: string;
  provider: string;
  provider_user_id: string;
  display_name: string | null;
  username: string | null;
  avatar_url: string | null;
  email: string | null;
  access_token_enc: string;
  refresh_token_enc: string | null;
  token_expires_at: string | null;
  scopes: string;
  metadata_json: string;
  created_at: string;
  updated_at: string;
}

export interface ProjectRow {
  id: string;
  user_id: string;
  title: string;
  topic: string;
  language: string;
  genre: string;
  aspect_ratio: string;
  story_text: string;
  status: string;
  voice_name: string;
  voice_style: string;
  created_at: string;
  updated_at: string;
}

export interface SceneRow {
  id: string;
  project_id: string;
  user_id: string;
  scene_order: number;
  title: string;
  narration_text: string;
  image_prompt: string;
  image_data_url: string | null;
  audio_data_url: string | null;
  duration_sec: number;
  transition: string;
  subtitle_enabled: number;
  created_at: string;
  updated_at: string;
}

export function cleanExpiredRecords(): void {
  const now = new Date().toISOString();
  db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(now);
  db.prepare('DELETE FROM oauth_states WHERE expires_at < ?').run(now);
  db.prepare('DELETE FROM oauth_exchange_codes WHERE expires_at < ?').run(now);
  db.prepare('DELETE FROM password_resets WHERE expires_at < ?').run(now);
}
