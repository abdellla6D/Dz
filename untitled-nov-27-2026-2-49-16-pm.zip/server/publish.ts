import crypto from 'node:crypto';
import type { Response } from 'express';
import { Router } from 'express';
import { z } from 'zod';
import { requireAuth } from './auth.ts';
import type { AuthenticatedRequest } from './auth.ts';
import { decryptText } from './crypto.ts';
import { db } from './db.ts';
import type { OAuthAccountRow } from './db.ts';

export const publishRouter = Router();
publishRouter.use(requireAuth);

publishRouter.get('/jobs', (req: AuthenticatedRequest, res: Response) => {
  const jobs = db
    .prepare('SELECT * FROM publish_jobs WHERE user_id = ? ORDER BY created_at DESC LIMIT 50')
    .all(req.user!.id);
  res.json({ jobs });
});

const facebookPublishSchema = z.object({
  projectId: z.string().uuid().optional(),
  pageId: z.string().trim().min(1),
  pageName: z.string().trim().min(1).max(160),
  title: z.string().trim().min(1).max(200),
  description: z.string().trim().max(5000),
  mediaType: z.enum(['video', 'photo', 'text']).default('video'),
  mediaBase64: z.string().optional(),
  mediaMimeType: z.string().optional(),
});

publishRouter.post('/facebook', async (req: AuthenticatedRequest, res: Response) => {
  const parsed = facebookPublishSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'يرجى تحديد الصفحة والعنوان والوصف بشكل صحيح.' });
    return;
  }

  const acc = db
    .prepare("SELECT * FROM oauth_accounts WHERE user_id = ? AND provider = 'facebook'")
    .get(req.user!.id) as OAuthAccountRow | undefined;

  if (!acc) {
    res.status(400).json({ error: 'يجب ربط حساب Facebook أولاً من قسم حساباتي المرتبطة.' });
    return;
  }

  const jobId = crypto.randomUUID();
  const now = new Date().toISOString();
  const d = parsed.data;

  db.prepare(
    `INSERT INTO publish_jobs (id, user_id, project_id, platform, target_id, target_name, title, description, privacy_level, status, created_at)
     VALUES (?, ?, ?, 'facebook', ?, ?, ?, ?, 'PUBLIC', 'processing', ?)`
  ).run(jobId, req.user!.id, d.projectId ?? null, d.pageId, d.pageName, d.title, d.description, now);

  try {
    const userAccessToken = decryptText(acc.access_token_enc);

    // Fetch the Page Access Token for the selected pageId
    const pageTokenRes = await fetch(
      `https://graph.facebook.com/v21.0/${encodeURIComponent(d.pageId)}?fields=access_token,name&access_token=${encodeURIComponent(userAccessToken)}`
    );
    const pageTokenJson = (await pageTokenRes.json()) as {
      access_token?: string;
      error?: { message?: string };
    };

    if (!pageTokenRes.ok || !pageTokenJson.access_token) {
      throw new Error(
        pageTokenJson.error?.message ||
          'تعذر الحصول على رمز صلاحية النشر للصفحة (Page Access Token). تأكد من الموافقة على صلاحية pages_manage_posts.'
      );
    }

    const pageAccessToken = pageTokenJson.access_token;
    let externalPostId: string | null = null;

    if (d.mediaType === 'video') {
      if (!d.mediaBase64) {
        throw new Error('يرجى تصدير الفيديو من محرر الفيديو أو اختيار ملف فيديو قبل النشر.');
      }
      const cleanBase64 = d.mediaBase64.includes(',') ? d.mediaBase64.split(',')[1] : d.mediaBase64;
      const videoBuffer = Buffer.from(cleanBase64, 'base64');
      const mime = d.mediaMimeType || 'video/webm';
      const ext = mime.includes('mp4') ? 'mp4' : 'webm';

      const form = new FormData();
      form.append('access_token', pageAccessToken);
      form.append('title', d.title);
      form.append('description', d.description);
      form.append('source', new Blob([videoBuffer], { type: mime }), `storymaster.${ext}`);

      const uploadRes = await fetch(
        `https://graph-video.facebook.com/v21.0/${encodeURIComponent(d.pageId)}/videos`,
        {
          method: 'POST',
          body: form,
        }
      );
      const uploadJson = (await uploadRes.json()) as { id?: string; error?: { message?: string } };
      if (!uploadRes.ok || !uploadJson.id) {
        throw new Error(uploadJson.error?.message || 'فشل رفع الفيديو إلى صفحة فيسبوك.');
      }
      externalPostId = uploadJson.id;
    } else if (d.mediaType === 'photo' && d.mediaBase64) {
      const cleanBase64 = d.mediaBase64.includes(',') ? d.mediaBase64.split(',')[1] : d.mediaBase64;
      const imgBuffer = Buffer.from(cleanBase64, 'base64');
      const mime = d.mediaMimeType || 'image/jpeg';

      const form = new FormData();
      form.append('access_token', pageAccessToken);
      form.append('caption', `${d.title}\n\n${d.description}`);
      form.append('source', new Blob([imgBuffer], { type: mime }), 'scene.jpg');

      const photoRes = await fetch(
        `https://graph.facebook.com/v21.0/${encodeURIComponent(d.pageId)}/photos`,
        { method: 'POST', body: form }
      );
      const photoJson = (await photoRes.json()) as { id?: string; post_id?: string; error?: { message?: string } };
      if (!photoRes.ok || (!photoJson.id && !photoJson.post_id)) {
        throw new Error(photoJson.error?.message || 'فشل نشر الصورة على صفحة فيسبوك.');
      }
      externalPostId = photoJson.post_id || photoJson.id || null;
    } else {
      const feedRes = await fetch(
        `https://graph.facebook.com/v21.0/${encodeURIComponent(d.pageId)}/feed`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            access_token: pageAccessToken,
            message: `${d.title}\n\n${d.description}`,
          }),
        }
      );
      const feedJson = (await feedRes.json()) as { id?: string; error?: { message?: string } };
      if (!feedRes.ok || !feedJson.id) {
        throw new Error(feedJson.error?.message || 'فشل النشر النصي على صفحة فيسبوك.');
      }
      externalPostId = feedJson.id;
    }

    db.prepare('UPDATE publish_jobs SET status = ?, external_post_id = ? WHERE id = ?').run(
      'published',
      externalPostId,
      jobId
    );
    if (d.projectId) {
      db.prepare("UPDATE projects SET status = 'published', updated_at = ? WHERE id = ? AND user_id = ?").run(
        new Date().toISOString(),
        d.projectId,
        req.user!.id
      );
    }

    const job = db.prepare('SELECT * FROM publish_jobs WHERE id = ?').get(jobId);
    res.json({ job });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'فشل النشر على Facebook';
    db.prepare('UPDATE publish_jobs SET status = ?, error_message = ? WHERE id = ?').run(
      'failed',
      message,
      jobId
    );
    const job = db.prepare('SELECT * FROM publish_jobs WHERE id = ?').get(jobId);
    res.status(400).json({ error: message, job });
  }
});

const tiktokPublishSchema = z.object({
  projectId: z.string().uuid().optional(),
  title: z.string().trim().min(1).max(150),
  description: z.string().trim().max(2200).optional().default(''),
  privacyLevel: z
    .enum(['PUBLIC_TO_EVERYONE', 'MUTUAL_FOLLOW_FRIENDS', 'FOLLOWER_OF_CREATOR', 'SELF_ONLY'])
    .default('SELF_ONLY'),
  disableComment: z.boolean().default(false),
  disableDuet: z.boolean().default(false),
  disableStitch: z.boolean().default(false),
  videoBase64: z.string().min(10),
  videoMimeType: z.string().default('video/webm'),
});

publishRouter.post('/tiktok', async (req: AuthenticatedRequest, res: Response) => {
  const parsed = tiktokPublishSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'يرجى توفير الفيديو والعنوان وإعدادات الخصوصية بشكل صحيح.' });
    return;
  }

  const acc = db
    .prepare("SELECT * FROM oauth_accounts WHERE user_id = ? AND provider = 'tiktok'")
    .get(req.user!.id) as OAuthAccountRow | undefined;

  if (!acc) {
    res.status(400).json({ error: 'يجب ربط حساب TikTok أولاً من قسم حساباتي المرتبطة.' });
    return;
  }

  const jobId = crypto.randomUUID();
  const now = new Date().toISOString();
  const d = parsed.data;

  db.prepare(
    `INSERT INTO publish_jobs (id, user_id, project_id, platform, target_id, target_name, title, description, privacy_level, status, created_at)
     VALUES (?, ?, ?, 'tiktok', ?, ?, ?, ?, ?, 'processing', ?)`
  ).run(
    jobId,
    req.user!.id,
    d.projectId ?? null,
    acc.provider_user_id,
    acc.display_name || acc.username || 'TikTok',
    d.title,
    d.description,
    d.privacyLevel,
    now
  );

  try {
    const accessToken = decryptText(acc.access_token_enc);
    const cleanBase64 = d.videoBase64.includes(',') ? d.videoBase64.split(',')[1] : d.videoBase64;
    const videoBuffer = Buffer.from(cleanBase64, 'base64');
    const videoSize = videoBuffer.length;
    const caption = d.description ? `${d.title} ${d.description}`.slice(0, 2200) : d.title;

    const initRes = await fetch('https://open.tiktokapis.com/v2/post/publish/video/init/', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: JSON.stringify({
        post_info: {
          title: caption,
          privacy_level: d.privacyLevel,
          disable_duet: d.disableDuet,
          disable_comment: d.disableComment,
          disable_stitch: d.disableStitch,
        },
        source_info: {
          source: 'FILE_UPLOAD',
          video_size: videoSize,
          chunk_size: videoSize,
          total_chunk_count: 1,
        },
      }),
    });

    const initJson = (await initRes.json()) as {
      data?: { publish_id?: string; upload_url?: string };
      error?: { code?: string; message?: string };
    };

    if (!initRes.ok || !initJson.data?.upload_url || !initJson.data?.publish_id) {
      throw new Error(
        initJson.error?.message ||
          'رفضت منصة TikTok تهيئة النشر. تأكد من موافقة Content Posting API (Direct Post) وصلاحية video.publish.'
      );
    }

    const uploadRes = await fetch(initJson.data.upload_url, {
      method: 'PUT',
      headers: {
        'Content-Range': `bytes 0-${videoSize - 1}/${videoSize}`,
        'Content-Type': d.videoMimeType || 'video/webm',
        'Content-Length': String(videoSize),
      },
      body: videoBuffer,
    });

    if (!uploadRes.ok) {
      const errText = await uploadRes.text();
      throw new Error(`فشل رفع ملف الفيديو إلى خوادم TikTok (${uploadRes.status}): ${errText}`);
    }

    const publishId = initJson.data.publish_id;
    db.prepare('UPDATE publish_jobs SET status = ?, external_post_id = ? WHERE id = ?').run(
      'published',
      publishId,
      jobId
    );
    if (d.projectId) {
      db.prepare("UPDATE projects SET status = 'published', updated_at = ? WHERE id = ? AND user_id = ?").run(
        new Date().toISOString(),
        d.projectId,
        req.user!.id
      );
    }

    const job = db.prepare('SELECT * FROM publish_jobs WHERE id = ?').get(jobId);
    res.json({ job });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'فشل النشر على TikTok';
    db.prepare('UPDATE publish_jobs SET status = ?, error_message = ? WHERE id = ?').run(
      'failed',
      message,
      jobId
    );
    const job = db.prepare('SELECT * FROM publish_jobs WHERE id = ?').get(jobId);
    res.status(400).json({ error: message, job });
  }
});
