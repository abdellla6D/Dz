import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type { NextFunction, Request, Response } from 'express';
import { Router } from 'express';
import { z } from 'zod';
import { db, cleanExpiredRecords } from './db.ts';
import type { OAuthAccountRow, UserRow } from './db.ts';
import {
  generateOpaqueToken,
  generateRecoveryKey,
  hashPassword,
  hashToken,
  verifyPassword,
} from './crypto.ts';

export interface LinkedAccountDTO {
  provider: 'facebook' | 'tiktok';
  providerUserId: string;
  displayName: string | null;
  username: string | null;
  avatarUrl: string | null;
  email: string | null;
  scopes: string[];
  connectedAt: string;
  metadata: Record<string, unknown>;
}

export interface PublicUserDTO {
  id: string;
  email: string | null;
  name: string;
  avatarUrl: string | null;
  bio: string;
  preferredLanguage: 'ar' | 'en';
  hasPassword: boolean;
  hasRecoveryKey: boolean;
  createdAt: string;
  linkedAccounts: LinkedAccountDTO[];
}

export interface AuthenticatedRequest extends Request {
  user?: PublicUserDTO;
  sessionTokenHash?: string;
}

export const SESSION_COOKIE_NAME = 'sm_session';

export function buildSessionCookieHeader(token: string, maxAgeSeconds: number, isHttps: boolean): string {
  const parts = [
    `${SESSION_COOKIE_NAME}=${encodeURIComponent(token)}`,
    'Path=/',
    `Max-Age=${maxAgeSeconds}`,
    'HttpOnly',
  ];
  if (isHttps) {
    parts.push('Secure', 'SameSite=None', 'Partitioned');
  } else {
    parts.push('SameSite=Lax');
  }
  return parts.join('; ');
}

export function isHttpsRequest(req: Request): boolean {
  const proto = req.headers['x-forwarded-proto'];
  if (typeof proto === 'string' && proto.includes('https')) return true;
  if (req.secure) return true;
  const appUrl = process.env.APP_URL || '';
  return appUrl.startsWith('https://');
}

export function setSessionCookie(req: Request, res: Response, token: string): void {
  const maxAge = 30 * 24 * 60 * 60;
  res.append('Set-Cookie', buildSessionCookieHeader(token, maxAge, isHttpsRequest(req)));
}

export function clearSessionCookie(req: Request, res: Response): void {
  res.append('Set-Cookie', buildSessionCookieHeader('', 0, isHttpsRequest(req)));
}

export function createSessionForUser(userId: string): string {
  cleanExpiredRecords();
  const rawToken = generateOpaqueToken(32);
  const tokenHash = hashToken(rawToken);
  const now = new Date();
  const expires = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
  db.prepare(
    'INSERT INTO sessions (token_hash, user_id, expires_at, created_at) VALUES (?, ?, ?, ?)'
  ).run(tokenHash, userId, expires.toISOString(), now.toISOString());
  return rawToken;
}

export function getPublicUserById(userId: string): PublicUserDTO | null {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as UserRow | undefined;
  if (!user) return null;

  const accounts = db
    .prepare('SELECT * FROM oauth_accounts WHERE user_id = ? ORDER BY created_at ASC')
    .all(userId) as unknown as OAuthAccountRow[];

  const linkedAccounts: LinkedAccountDTO[] = accounts.map((acc) => {
    let metadata: Record<string, unknown> = {};
    try {
      metadata = JSON.parse(acc.metadata_json || '{}') as Record<string, unknown>;
    } catch {
      metadata = {};
    }
    return {
      provider: acc.provider as 'facebook' | 'tiktok',
      providerUserId: acc.provider_user_id,
      displayName: acc.display_name,
      username: acc.username,
      avatarUrl: acc.avatar_url,
      email: acc.email,
      scopes: acc.scopes ? acc.scopes.split(',').map((s) => s.trim()).filter(Boolean) : [],
      connectedAt: acc.created_at,
      metadata,
    };
  });

  return {
    id: user.id,
    email: user.email,
    name: user.name,
    avatarUrl: user.avatar_url,
    bio: user.bio,
    preferredLanguage: user.preferred_language === 'en' ? 'en' : 'ar',
    hasPassword: Boolean(user.password_hash),
    hasRecoveryKey: Boolean(user.recovery_key_hash),
    createdAt: user.created_at,
    linkedAccounts,
  };
}

function extractToken(req: Request): { token: string | null; viaCookie: boolean } {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.slice(7).trim();
    if (token) return { token, viaCookie: false };
  }
  const cookieToken = req.cookies?.[SESSION_COOKIE_NAME];
  if (typeof cookieToken === 'string' && cookieToken.trim()) {
    return { token: cookieToken.trim(), viaCookie: true };
  }
  return { token: null, viaCookie: false };
}

function verifyCsrfOriginForCookie(req: Request): boolean {
  if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') {
    return true;
  }
  const origin = req.headers.origin;
  if (!origin) return true;
  const forwardedHost = req.headers['x-forwarded-host'];
  const host = (typeof forwardedHost === 'string' ? forwardedHost : req.headers.host) || '';
  try {
    const originHost = new URL(origin).host;
    if (host && originHost === host) return true;
    const appUrl = process.env.APP_URL;
    if (appUrl && appUrl !== 'MY_APP_URL') {
      if (new URL(appUrl).host === originHost) return true;
    }
  } catch {
    return false;
  }
  return false;
}

export function attachOptionalUser(req: AuthenticatedRequest, _res: Response, next: NextFunction): void {
  const { token } = extractToken(req);
  if (!token) {
    next();
    return;
  }
  const tokenHash = hashToken(token);
  const session = db
    .prepare('SELECT user_id, expires_at FROM sessions WHERE token_hash = ?')
    .get(tokenHash) as { user_id: string; expires_at: string } | undefined;

  if (!session || new Date(session.expires_at).getTime() <= Date.now()) {
    if (session) {
      db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenHash);
    }
    next();
    return;
  }

  const user = getPublicUserById(session.user_id);
  if (user) {
    req.user = user;
    req.sessionTokenHash = tokenHash;
  }
  next();
}

export function verifySessionToken(token: string): PublicUserDTO | null {
  if (!token) return null;
  const tokenHash = hashToken(token);
  const session = db
    .prepare('SELECT user_id, expires_at FROM sessions WHERE token_hash = ?')
    .get(tokenHash) as { user_id: string; expires_at: string } | undefined;

  if (!session || new Date(session.expires_at).getTime() <= Date.now()) {
    return null;
  }
  return getPublicUserById(session.user_id);
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const { token, viaCookie } = extractToken(req);
  if (!token) {
    res.status(401).json({ error: 'Authentication required', code: 'UNAUTHORIZED' });
    return;
  }
  if (viaCookie && !verifyCsrfOriginForCookie(req)) {
    res.status(403).json({ error: 'Origin verification failed', code: 'CSRF_BLOCKED' });
    return;
  }

  const tokenHash = hashToken(token);
  const session = db
    .prepare('SELECT user_id, expires_at FROM sessions WHERE token_hash = ?')
    .get(tokenHash) as { user_id: string; expires_at: string } | undefined;

  if (!session || new Date(session.expires_at).getTime() <= Date.now()) {
    if (session) {
      db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenHash);
    }
    res.status(401).json({ error: 'Session expired', code: 'SESSION_EXPIRED' });
    return;
  }

  const user = getPublicUserById(session.user_id);
  if (!user) {
    res.status(401).json({ error: 'User not found', code: 'UNAUTHORIZED' });
    return;
  }

  req.user = user;
  req.sessionTokenHash = tokenHash;
  next();
}

export const authRouter = Router();

const registerSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(180),
  password: z.string().min(8).max(128),
  preferredLanguage: z.enum(['ar', 'en']).optional().default('ar'),
});

authRouter.post('/register', async (req: Request, res: Response) => {
  try {
    const parsed = registerSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'بيانات التسجيل غير صالحة. يجب أن تكون كلمة المرور 8 أحرف على الأقل.' });
      return;
    }

    const emailLower = parsed.data.email.toLowerCase();
    const existing = db.prepare('SELECT id FROM users WHERE lower(email) = ?').get(emailLower);
    if (existing) {
      res.status(409).json({ error: 'البريد الإلكتروني مستخدم بالفعل في حساب آخر.' });
      return;
    }

    const userId = crypto.randomUUID();
    const now = new Date().toISOString();
    const passwordHash = await hashPassword(parsed.data.password);
    const recoveryKey = generateRecoveryKey();
    const recoveryKeyHash = hashToken(recoveryKey);

    db.prepare(
      `INSERT INTO users (id, email, name, avatar_url, password_hash, recovery_key_hash, bio, preferred_language, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, '', ?, ?, ?)`
    ).run(
      userId,
      emailLower,
      parsed.data.name,
      '/src/assets/images/studio_creator_avatar_1795782744107.jpg',
      passwordHash,
      recoveryKeyHash,
      parsed.data.preferredLanguage,
      now,
      now
    );

    const sessionToken = createSessionForUser(userId);
    setSessionCookie(req, res, sessionToken);
    const user = getPublicUserById(userId);

    res.status(201).json({
      user,
      sessionToken,
      recoveryKey,
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'تعذر إنشاء الحساب حالياً.' });
  }
});

const loginSchema = z.object({
  email: z.string().trim().email(),
  password: z.string().min(1),
});

authRouter.post('/login', async (req: Request, res: Response) => {
  try {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'يرجى إدخال بريد إلكتروني وكلمة مرور صالحة.' });
      return;
    }

    const emailLower = parsed.data.email.toLowerCase();
    const user = db.prepare('SELECT * FROM users WHERE lower(email) = ?').get(emailLower) as UserRow | undefined;
    if (!user || !user.password_hash) {
      res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' });
      return;
    }

    const ok = await verifyPassword(parsed.data.password, user.password_hash);
    if (!ok) {
      res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' });
      return;
    }

    const sessionToken = createSessionForUser(user.id);
    setSessionCookie(req, res, sessionToken);
    res.json({
      user: getPublicUserById(user.id),
      sessionToken,
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'حدث خطأ أثناء تسجيل الدخول.' });
  }
});

authRouter.post('/oauth-exchange', (req: Request, res: Response) => {
  const code = typeof req.body?.exchangeCode === 'string' ? req.body.exchangeCode.trim() : '';
  if (!code) {
    res.status(400).json({ error: 'Missing exchange code' });
    return;
  }

  cleanExpiredRecords();
  const codeHash = hashToken(code);
  const row = db
    .prepare('SELECT * FROM oauth_exchange_codes WHERE code_hash = ?')
    .get(codeHash) as { code_hash: string; session_token: string; expires_at: string } | undefined;

  if (!row || new Date(row.expires_at).getTime() <= Date.now()) {
    res.status(400).json({ error: 'Exchange code expired or invalid' });
    return;
  }

  db.prepare('DELETE FROM oauth_exchange_codes WHERE code_hash = ?').run(codeHash);

  const sessionHash = hashToken(row.session_token);
  const session = db
    .prepare('SELECT user_id FROM sessions WHERE token_hash = ?')
    .get(sessionHash) as { user_id: string } | undefined;

  if (!session) {
    res.status(401).json({ error: 'Session no longer valid' });
    return;
  }

  setSessionCookie(req, res, row.session_token);
  res.json({
    user: getPublicUserById(session.user_id),
    sessionToken: row.session_token,
  });
});

authRouter.post('/logout', attachOptionalUser, (req: AuthenticatedRequest, res: Response) => {
  if (req.sessionTokenHash) {
    db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(req.sessionTokenHash);
  }
  clearSessionCookie(req, res);
  res.json({ ok: true });
});

authRouter.get('/me', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  res.json({ user: req.user });
});

const updateProfileSchema = z.object({
  name: z.string().trim().min(2).max(80).optional(),
  email: z.string().trim().email().max(180).optional(),
  bio: z.string().trim().max(400).optional(),
  preferredLanguage: z.enum(['ar', 'en']).optional(),
});

authRouter.patch('/profile', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const parsed = updateProfileSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'بيانات الملف الشخصي غير صالحة.' });
    return;
  }

  const userId = req.user!.id;
  const current = db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as unknown as UserRow;

  let nextEmail = current.email;
  if (parsed.data.email) {
    const emailLower = parsed.data.email.toLowerCase();
    const conflict = db
      .prepare('SELECT id FROM users WHERE lower(email) = ? AND id != ?')
      .get(emailLower, userId);
    if (conflict) {
      res.status(409).json({ error: 'هذا البريد الإلكتروني مرتبط بحساب آخر.' });
      return;
    }
    nextEmail = emailLower;
  }

  const nextName = parsed.data.name ?? current.name;
  const nextBio = parsed.data.bio ?? current.bio;
  const nextLang = parsed.data.preferredLanguage ?? current.preferred_language;
  const now = new Date().toISOString();

  db.prepare(
    'UPDATE users SET name = ?, email = ?, bio = ?, preferred_language = ?, updated_at = ? WHERE id = ?'
  ).run(nextName, nextEmail, nextBio, nextLang, now, userId);

  res.json({ user: getPublicUserById(userId) });
});

const changePasswordSchema = z.object({
  currentPassword: z.string().optional(),
  newPassword: z.string().min(8).max(128),
});

authRouter.post('/change-password', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const parsed = changePasswordSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'يجب أن تتكون كلمة المرور الجديدة من 8 أحرف على الأقل.' });
    return;
  }

  const userId = req.user!.id;
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as unknown as UserRow;

  if (user.password_hash) {
    if (!parsed.data.currentPassword) {
      res.status(400).json({ error: 'يرجى إدخال كلمة المرور الحالية.' });
      return;
    }
    const valid = await verifyPassword(parsed.data.currentPassword, user.password_hash);
    if (!valid) {
      res.status(401).json({ error: 'كلمة المرور الحالية غير صحيحة.' });
      return;
    }
  }

  const newHash = await hashPassword(parsed.data.newPassword);
  db.prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?').run(
    newHash,
    new Date().toISOString(),
    userId
  );

  res.json({ ok: true, user: getPublicUserById(userId) });
});

authRouter.post('/regenerate-recovery-key', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const userId = req.user!.id;
  const recoveryKey = generateRecoveryKey();
  const recoveryKeyHash = hashToken(recoveryKey);
  db.prepare('UPDATE users SET recovery_key_hash = ?, updated_at = ? WHERE id = ?').run(
    recoveryKeyHash,
    new Date().toISOString(),
    userId
  );
  res.json({ recoveryKey, user: getPublicUserById(userId) });
});

authRouter.post('/forgot-password', async (req: Request, res: Response) => {
  const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  if (!email) {
    res.status(400).json({ error: 'يرجى إدخال البريد الإلكتروني.' });
    return;
  }

  const user = db.prepare('SELECT * FROM users WHERE lower(email) = ?').get(email) as UserRow | undefined;
  const resendKey = process.env.RESEND_API_KEY?.trim();

  if (!resendKey) {
    res.json({
      emailConfigured: false,
      message:
        'خدمة إرسال البريد الإلكتروني (RESEND_API_KEY) غير مفعلة على الخادم حالياً. يمكنك استعادة حسابك فوراً باستخدام رمز الاسترداد الاحتياطي (Backup Recovery Key) الذي حصلت عليه عند إنشاء الحساب.',
    });
    return;
  }

  if (user) {
    const code = crypto.randomInt(100000, 999999).toString();
    const codeHash = hashToken(code);
    const now = new Date();
    const expires = new Date(now.getTime() + 15 * 60 * 1000);
    db.prepare('DELETE FROM password_resets WHERE user_id = ?').run(user.id);
    db.prepare(
      'INSERT INTO password_resets (id, user_id, code_hash, expires_at, used, created_at) VALUES (?, ?, ?, ?, 0, ?)'
    ).run(crypto.randomUUID(), user.id, codeHash, expires.toISOString(), now.toISOString());

    try {
      const fromEmail = process.env.RESEND_FROM_EMAIL || 'StoryMaster AI <onboarding@resend.dev>';
      await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${resendKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: fromEmail,
          to: [email],
          subject: 'StoryMaster AI — رمز استعادة كلمة المرور',
          html: `<div dir="rtl" style="font-family:sans-serif;padding:24px;"><h2>استعادة كلمة المرور</h2><p>رمز التحقق الخاص بك هو: <strong style="font-size:22px;letter-spacing:3px;">${code}</strong></p><p>ينتهي الرمز خلال 15 دقيقة.</p></div>`,
        }),
      });
    } catch (err) {
      console.error('Resend email error:', err);
    }
  }

  res.json({
    emailConfigured: true,
    message: 'إذا كان البريد الإلكتروني مسجلاً لدينا، فقد تم إرسال رمز التحقق إليه.',
  });
});

const resetPasswordSchema = z.object({
  email: z.string().trim().email(),
  method: z.enum(['email_code', 'recovery_key']),
  code: z.string().trim().min(4).max(64),
  newPassword: z.string().min(8).max(128),
});

authRouter.post('/reset-password', async (req: Request, res: Response) => {
  const parsed = resetPasswordSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'يرجى التحقق من البيانات المدخلة وكلمة المرور الجديدة (8 أحرف على الأقل).' });
    return;
  }

  const emailLower = parsed.data.email.toLowerCase();
  const user = db.prepare('SELECT * FROM users WHERE lower(email) = ?').get(emailLower) as UserRow | undefined;
  if (!user) {
    res.status(400).json({ error: 'بيانات الاستعادة غير صالحة.' });
    return;
  }

  const submittedHash = hashToken(parsed.data.code.trim().toUpperCase());
  const rawHash = hashToken(parsed.data.code.trim());

  if (parsed.data.method === 'recovery_key') {
    if (!user.recovery_key_hash) {
      res.status(400).json({ error: 'لا يوجد رمز استرداد احتياطي مسجل لهذا الحساب.' });
      return;
    }
    const a = Buffer.from(submittedHash);
    const b = Buffer.from(user.recovery_key_hash);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      res.status(400).json({ error: 'رمز الاسترداد الاحتياطي غير صحيح.' });
      return;
    }
  } else {
    const resetRow = db
      .prepare('SELECT * FROM password_resets WHERE user_id = ? AND used = 0 ORDER BY created_at DESC LIMIT 1')
      .get(user.id) as { id: string; code_hash: string; expires_at: string } | undefined;

    if (!resetRow || new Date(resetRow.expires_at).getTime() <= Date.now()) {
      res.status(400).json({ error: 'رمز التحقق منتهي الصلاحية أو غير صالح.' });
      return;
    }
    const a = Buffer.from(rawHash);
    const b = Buffer.from(resetRow.code_hash);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      res.status(400).json({ error: 'رمز التحقق غير صحيح.' });
      return;
    }
    db.prepare('UPDATE password_resets SET used = 1 WHERE id = ?').run(resetRow.id);
  }

  const newPasswordHash = await hashPassword(parsed.data.newPassword);
  db.prepare('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?').run(
    newPasswordHash,
    new Date().toISOString(),
    user.id
  );
  // Revoke existing sessions on password reset
  db.prepare('DELETE FROM sessions WHERE user_id = ?').run(user.id);

  res.json({ ok: true, message: 'تم تحديث كلمة المرور بنجاح. يمكنك تسجيل الدخول الآن.' });
});

authRouter.post('/firebase', async (req: Request, res: Response) => {
  const idToken = typeof req.body?.idToken === 'string' ? req.body.idToken.trim() : '';
  const preferredLanguage = req.body?.preferredLanguage === 'en' ? 'en' : 'ar';
  if (!idToken) {
    res.status(400).json({ error: 'Missing Firebase ID token' });
    return;
  }

  try {
    const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
    const fbConfig = JSON.parse(fs.readFileSync(configPath, 'utf8')) as { apiKey?: string };
    if (!fbConfig.apiKey) {
      res.status(500).json({ error: 'Firebase configuration missing on server' });
      return;
    }

    const verifyRes = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(fbConfig.apiKey)}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken }),
      }
    );
    const verifyJson = (await verifyRes.json()) as {
      users?: Array<{
        localId?: string;
        email?: string;
        emailVerified?: boolean;
        displayName?: string;
        photoUrl?: string;
      }>;
      error?: { message?: string };
    };

    const fbAccount = verifyJson.users?.[0];
    if (!verifyRes.ok || !fbAccount?.localId) {
      res.status(401).json({ error: verifyJson.error?.message || 'Invalid Firebase token' });
      return;
    }

    const fbUid = fbAccount.localId;
    const emailLower = fbAccount.email ? fbAccount.email.toLowerCase() : null;
    const displayName = fbAccount.displayName || (emailLower ? emailLower.split('@')[0] : 'Google Creator');
    const avatarUrl = fbAccount.photoUrl || '/src/assets/images/studio_creator_avatar_1795782744107.jpg';
    const now = new Date().toISOString();

    let user = db
      .prepare('SELECT * FROM users WHERE firebase_uid = ?')
      .get(fbUid) as unknown as UserRow | undefined;

    if (!user && emailLower && fbAccount.emailVerified) {
      user = db
        .prepare('SELECT * FROM users WHERE lower(email) = ?')
        .get(emailLower) as unknown as UserRow | undefined;
      if (user) {
        db.prepare('UPDATE users SET firebase_uid = ?, avatar_url = COALESCE(avatar_url, ?), updated_at = ? WHERE id = ?').run(
          fbUid,
          avatarUrl,
          now,
          user.id
        );
      }
    }

    let userId: string;
    if (!user) {
      userId = crypto.randomUUID();
      const recoveryKey = generateRecoveryKey();
      db.prepare(
        `INSERT INTO users (id, email, name, avatar_url, password_hash, recovery_key_hash, bio, preferred_language, firebase_uid, created_at, updated_at)
         VALUES (?, ?, ?, ?, NULL, ?, '', ?, ?, ?, ?)`
      ).run(
        userId,
        emailLower,
        displayName,
        avatarUrl,
        hashToken(recoveryKey),
        preferredLanguage,
        fbUid,
        now,
        now
      );
    } else {
      userId = user.id;
    }

    const sessionToken = createSessionForUser(userId);
    setSessionCookie(req, res, sessionToken);
    res.json({
      user: getPublicUserById(userId),
      sessionToken,
    });
  } catch (err) {
    console.error('Firebase auth exchange error:', err);
    res.status(500).json({ error: 'تعذر التحقق من تسجيل الدخول عبر Google Firebase.' });
  }
});

authRouter.delete('/account', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const userId = req.user!.id;
  db.prepare('DELETE FROM users WHERE id = ?').run(userId);
  clearSessionCookie(req, res);
  res.json({ ok: true });
});
