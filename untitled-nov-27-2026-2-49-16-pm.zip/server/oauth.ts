import crypto from 'node:crypto';
import type { Request, Response } from 'express';
import { Router } from 'express';
import { db, cleanExpiredRecords } from './db.ts';
import type { OAuthAccountRow, UserRow } from './db.ts';
import {
  decryptText,
  encryptText,
  generateOpaqueToken,
  generatePkcePair,
  generateRecoveryKey,
  hashToken,
  signState,
  verifySignedState,
} from './crypto.ts';
import {
  attachOptionalUser,
  createSessionForUser,
  getPublicUserById,
  requireAuth,
  setSessionCookie,
} from './auth.ts';
import type { AuthenticatedRequest } from './auth.ts';

export function getAppBaseUrl(): string {
  const envUrl = process.env.APP_URL?.trim();
  if (envUrl && envUrl !== 'MY_APP_URL') {
    return envUrl.replace(/\/+$/, '');
  }
  const port = process.env.PORT || '3000';
  return `http://localhost:${port}`;
}

function isFacebookConfigured(): boolean {
  return Boolean(process.env.FACEBOOK_APP_ID?.trim() && process.env.FACEBOOK_APP_SECRET?.trim());
}

function isTikTokConfigured(): boolean {
  return Boolean(process.env.TIKTOK_CLIENT_KEY?.trim() && process.env.TIKTOK_CLIENT_SECRET?.trim());
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function renderPopupResultHtml(payload: Record<string, unknown>, message: string): string {
  const jsonPayload = JSON.stringify(payload).replace(/</g, '\\u003c');
  return `<!doctype html>
<html lang="ar" dir="rtl">
  <head>
    <meta charset="UTF-8" />
    <title>StoryMaster AI — OAuth</title>
    <style>
      body { font-family: system-ui, sans-serif; background: #0B0F17; color: #F8FAFC; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
      .card { border: 1px solid #1E293B; background: #111827; padding: 28px 32px; border-radius: 14px; max-width: 420px; text-align: center; }
      p { color: #CBD5E1; line-height: 1.6; }
    </style>
  </head>
  <body>
    <div class="card">
      <h2>StoryMaster AI Publisher</h2>
      <p>${escapeHtml(message)}</p>
    </div>
    <script>
      (function() {
        var data = ${jsonPayload};
        if (window.opener) {
          window.opener.postMessage(data, '*');
          setTimeout(function() { window.close(); }, 350);
        } else {
          window.location.href = '/';
        }
      })();
    </script>
  </body>
</html>`;
}

function createExchangeCode(sessionToken: string, provider: string, mode: string): string {
  const code = generateOpaqueToken(24);
  const codeHash = hashToken(code);
  const expires = new Date(Date.now() + 60 * 1000).toISOString();
  db.prepare(
    'INSERT INTO oauth_exchange_codes (code_hash, session_token, provider, mode, expires_at) VALUES (?, ?, ?, ?, ?)'
  ).run(codeHash, sessionToken, provider, mode, expires);
  return code;
}

function resolveOrCreateOAuthUser(params: {
  provider: 'facebook' | 'tiktok';
  providerUserId: string;
  displayName: string;
  username: string | null;
  avatarUrl: string | null;
  email: string | null;
  accessToken: string;
  refreshToken: string | null;
  expiresInSec: number | null;
  scopes: string;
  metadata: Record<string, unknown>;
  mode: string;
  connectUserId: string | null;
}): { userId: string } {
  const now = new Date().toISOString();
  const expiresAt = params.expiresInSec
    ? new Date(Date.now() + params.expiresInSec * 1000).toISOString()
    : null;

  const existingOAuth = db
    .prepare('SELECT * FROM oauth_accounts WHERE provider = ? AND provider_user_id = ?')
    .get(params.provider, params.providerUserId) as OAuthAccountRow | undefined;

  let targetUserId: string | null = null;

  if (params.mode === 'connect' && params.connectUserId) {
    if (existingOAuth && existingOAuth.user_id !== params.connectUserId) {
      throw new Error('هذا الحساب مرتبط بالفعل بمستخدم آخر في المنصة.');
    }
    targetUserId = params.connectUserId;
  } else if (existingOAuth) {
    targetUserId = existingOAuth.user_id;
  } else if (params.email) {
    const emailUser = db
      .prepare('SELECT id FROM users WHERE lower(email) = ?')
      .get(params.email.toLowerCase()) as { id: string } | undefined;
    if (emailUser) {
      targetUserId = emailUser.id;
    }
  }

  if (!targetUserId) {
    targetUserId = crypto.randomUUID();
    const recoveryKey = generateRecoveryKey();
    db.prepare(
      `INSERT INTO users (id, email, name, avatar_url, password_hash, recovery_key_hash, bio, preferred_language, created_at, updated_at)
       VALUES (?, ?, ?, ?, NULL, ?, '', 'ar', ?, ?)`
    ).run(
      targetUserId,
      params.email ? params.email.toLowerCase() : null,
      params.displayName,
      params.avatarUrl || '/src/assets/images/studio_creator_avatar_1795782744107.jpg',
      hashToken(recoveryKey),
      now,
      now
    );
  } else {
    const currentUser = db.prepare('SELECT * FROM users WHERE id = ?').get(targetUserId) as unknown as UserRow | undefined;
    if (currentUser && !currentUser.avatar_url && params.avatarUrl) {
      db.prepare('UPDATE users SET avatar_url = ?, updated_at = ? WHERE id = ?').run(
        params.avatarUrl,
        now,
        targetUserId
      );
    }
  }

  const accessTokenEnc = encryptText(params.accessToken);
  const refreshTokenEnc = params.refreshToken ? encryptText(params.refreshToken) : null;
  const metadataJson = JSON.stringify(params.metadata || {});

  const userExistingProvider = db
    .prepare('SELECT id FROM oauth_accounts WHERE user_id = ? AND provider = ?')
    .get(targetUserId, params.provider) as { id: string } | undefined;

  if (userExistingProvider) {
    db.prepare(
      `UPDATE oauth_accounts SET
        provider_user_id = ?, display_name = ?, username = ?, avatar_url = ?, email = ?,
        access_token_enc = ?, refresh_token_enc = ?, token_expires_at = ?, scopes = ?, metadata_json = ?, updated_at = ?
       WHERE id = ?`
    ).run(
      params.providerUserId,
      params.displayName,
      params.username,
      params.avatarUrl,
      params.email,
      accessTokenEnc,
      refreshTokenEnc,
      expiresAt,
      params.scopes,
      metadataJson,
      now,
      userExistingProvider.id
    );
  } else {
    db.prepare(
      `INSERT INTO oauth_accounts (
        id, user_id, provider, provider_user_id, display_name, username, avatar_url, email,
        access_token_enc, refresh_token_enc, token_expires_at, scopes, metadata_json, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      crypto.randomUUID(),
      targetUserId,
      params.provider,
      params.providerUserId,
      params.displayName,
      params.username,
      params.avatarUrl,
      params.email,
      accessTokenEnc,
      refreshTokenEnc,
      expiresAt,
      params.scopes,
      metadataJson,
      now,
      now
    );
  }

  return { userId: targetUserId };
}

export const oauthApiRouter = Router();
export const oauthCallbackRouter = Router();

oauthApiRouter.get('/status', (_req: Request, res: Response) => {
  const baseUrl = getAppBaseUrl();
  res.json({
    appUrl: baseUrl,
    facebook: {
      configured: isFacebookConfigured(),
      callbackUrl: `${baseUrl}/auth/facebook/callback`,
    },
    tiktok: {
      configured: isTikTokConfigured(),
      callbackUrl: `${baseUrl}/auth/tiktok/callback`,
    },
  });
});

// ======================== FACEBOOK LOGIN OAUTH ========================

oauthApiRouter.get('/facebook/url', attachOptionalUser, (req: AuthenticatedRequest, res: Response) => {
  if (!isFacebookConfigured()) {
    res.status(400).json({
      error:
        'إعدادات Facebook OAuth غير مكتملة. يرجى إضافة FACEBOOK_APP_ID و FACEBOOK_APP_SECRET في متغيرات البيئة.',
      code: 'OAUTH_NOT_CONFIGURED',
      callbackUrl: `${getAppBaseUrl()}/auth/facebook/callback`,
    });
    return;
  }

  const mode = req.query.mode === 'connect' && req.user ? 'connect' : 'login';
  const includePages = req.query.includePages === '1' || mode === 'connect';
  const redirectUri = `${getAppBaseUrl()}/auth/facebook/callback`;

  cleanExpiredRecords();
  const stateId = generateOpaqueToken(18);
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

  db.prepare(
    `INSERT INTO oauth_states (state_id, provider, mode, user_id, code_verifier, redirect_uri, expires_at, created_at)
     VALUES (?, 'facebook', ?, ?, NULL, ?, ?, ?)`
  ).run(stateId, mode, req.user?.id ?? null, redirectUri, expiresAt, new Date().toISOString());

  const scopes = includePages
    ? 'public_profile,email,pages_show_list,pages_read_engagement,pages_manage_posts'
    : 'public_profile,email';

  const params = new URLSearchParams({
    client_id: process.env.FACEBOOK_APP_ID!.trim(),
    redirect_uri: redirectUri,
    state: signState(stateId),
    response_type: 'code',
    scope: scopes,
  });

  res.json({ url: `https://www.facebook.com/v21.0/dialog/oauth?${params.toString()}` });
});

async function handleFacebookCallback(req: Request, res: Response): Promise<void> {
  const errorParam = typeof req.query.error === 'string' ? req.query.error : '';
  const errorDescription = typeof req.query.error_description === 'string' ? req.query.error_description : '';
  if (errorParam) {
    res.status(200).send(
      renderPopupResultHtml(
        { type: 'OAUTH_AUTH_ERROR', provider: 'facebook', error: errorDescription || errorParam },
        `تم إلغاء تسجيل الدخول عبر Facebook: ${errorDescription || errorParam}`
      )
    );
    return;
  }

  const code = typeof req.query.code === 'string' ? req.query.code : '';
  const rawState = typeof req.query.state === 'string' ? req.query.state : '';
  const stateId = verifySignedState(rawState);

  if (!code || !stateId) {
    res.status(400).send(
      renderPopupResultHtml(
        { type: 'OAUTH_AUTH_ERROR', provider: 'facebook', error: 'Invalid OAuth state or missing code' },
        'فشل التحقق من جلسة المصادقة (State غير صالح).'
      )
    );
    return;
  }

  const stateRow = db
    .prepare("SELECT * FROM oauth_states WHERE state_id = ? AND provider = 'facebook'")
    .get(stateId) as
    | {
        state_id: string;
        mode: string;
        user_id: string | null;
        redirect_uri: string;
        expires_at: string;
      }
    | undefined;

  if (!stateRow || new Date(stateRow.expires_at).getTime() <= Date.now()) {
    res.status(400).send(
      renderPopupResultHtml(
        { type: 'OAUTH_AUTH_ERROR', provider: 'facebook', error: 'OAuth state expired' },
        'انتهت صلاحية طلب المصادقة. يرجى المحاولة مجدداً.'
      )
    );
    return;
  }

  db.prepare('DELETE FROM oauth_states WHERE state_id = ?').run(stateId);

  try {
    const appId = process.env.FACEBOOK_APP_ID!.trim();
    const appSecret = process.env.FACEBOOK_APP_SECRET!.trim();

    const tokenUrl = new URL('https://graph.facebook.com/v21.0/oauth/access_token');
    tokenUrl.searchParams.set('client_id', appId);
    tokenUrl.searchParams.set('client_secret', appSecret);
    tokenUrl.searchParams.set('redirect_uri', stateRow.redirect_uri);
    tokenUrl.searchParams.set('code', code);

    const tokenRes = await fetch(tokenUrl.toString());
    const tokenJson = (await tokenRes.json()) as {
      access_token?: string;
      expires_in?: number;
      error?: { message?: string };
    };

    if (!tokenRes.ok || !tokenJson.access_token) {
      throw new Error(tokenJson.error?.message || 'فشل تبديل رمز Facebook Token');
    }

    let finalToken = tokenJson.access_token;
    let expiresIn = tokenJson.expires_in ?? null;

    // Exchange for long-lived user token when available
    try {
      const longUrl = new URL('https://graph.facebook.com/v21.0/oauth/access_token');
      longUrl.searchParams.set('grant_type', 'fb_exchange_token');
      longUrl.searchParams.set('client_id', appId);
      longUrl.searchParams.set('client_secret', appSecret);
      longUrl.searchParams.set('fb_exchange_token', finalToken);
      const longRes = await fetch(longUrl.toString());
      const longJson = (await longRes.json()) as { access_token?: string; expires_in?: number };
      if (longRes.ok && longJson.access_token) {
        finalToken = longJson.access_token;
        expiresIn = longJson.expires_in ?? expiresIn;
      }
    } catch {
      // Keep short-lived token if exchange fails
    }

    const meRes = await fetch(
      `https://graph.facebook.com/v21.0/me?fields=id,name,email,picture.type(large)&access_token=${encodeURIComponent(finalToken)}`
    );
    const meJson = (await meRes.json()) as {
      id?: string;
      name?: string;
      email?: string;
      picture?: { data?: { url?: string } };
      error?: { message?: string };
    };

    if (!meRes.ok || !meJson.id) {
      throw new Error(meJson.error?.message || 'تعذر جلب ملف Facebook الشخصي');
    }

    // Fetch granted permissions & pages if permitted
    let scopesList = '';
    try {
      const permRes = await fetch(
        `https://graph.facebook.com/v21.0/me/permissions?access_token=${encodeURIComponent(finalToken)}`
      );
      const permJson = (await permRes.json()) as {
        data?: Array<{ permission: string; status: string }>;
      };
      if (Array.isArray(permJson.data)) {
        scopesList = permJson.data
          .filter((p) => p.status === 'granted')
          .map((p) => p.permission)
          .join(',');
      }
    } catch {
      scopesList = 'public_profile';
    }

    let pages: Array<{ id: string; name: string; category?: string }> = [];
    try {
      const pagesRes = await fetch(
        `https://graph.facebook.com/v21.0/me/accounts?fields=id,name,category&access_token=${encodeURIComponent(finalToken)}`
      );
      const pagesJson = (await pagesRes.json()) as {
        data?: Array<{ id: string; name: string; category?: string }>;
      };
      if (Array.isArray(pagesJson.data)) {
        pages = pagesJson.data.map((p) => ({ id: p.id, name: p.name, category: p.category }));
      }
    } catch {
      pages = [];
    }

    const { userId } = resolveOrCreateOAuthUser({
      provider: 'facebook',
      providerUserId: meJson.id,
      displayName: meJson.name || 'Facebook Creator',
      username: null,
      avatarUrl: meJson.picture?.data?.url ?? null,
      email: meJson.email ?? null,
      accessToken: finalToken,
      refreshToken: null,
      expiresInSec: expiresIn,
      scopes: scopesList || 'public_profile',
      metadata: { pages },
      mode: stateRow.mode,
      connectUserId: stateRow.user_id,
    });

    const sessionToken = createSessionForUser(userId);
    setSessionCookie(req, res, sessionToken);
    const exchangeCode = createExchangeCode(sessionToken, 'facebook', stateRow.mode);

    res.status(200).send(
      renderPopupResultHtml(
        {
          type: 'OAUTH_AUTH_SUCCESS',
          provider: 'facebook',
          mode: stateRow.mode,
          exchangeCode,
        },
        'تم تسجيل الدخول وربط حساب Facebook بنجاح. يمكنك إغلاق هذه النافذة.'
      )
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : 'فشل الاتصال بـ Facebook';
    res.status(500).send(
      renderPopupResultHtml({ type: 'OAUTH_AUTH_ERROR', provider: 'facebook', error: message }, message)
    );
  }
}

oauthCallbackRouter.get(['/facebook/callback', '/facebook/callback/'], (req, res) => {
  void handleFacebookCallback(req, res);
});

oauthApiRouter.get('/facebook/pages', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const acc = db
    .prepare("SELECT * FROM oauth_accounts WHERE user_id = ? AND provider = 'facebook'")
    .get(req.user!.id) as OAuthAccountRow | undefined;

  if (!acc) {
    res.status(404).json({ error: 'حساب Facebook غير مرتبط بهذا المستخدم.' });
    return;
  }

  try {
    const token = decryptText(acc.access_token_enc);
    const pagesRes = await fetch(
      `https://graph.facebook.com/v21.0/me/accounts?fields=id,name,category,picture{url}&access_token=${encodeURIComponent(token)}`
    );
    const pagesJson = (await pagesRes.json()) as {
      data?: Array<{ id: string; name: string; category?: string; picture?: { data?: { url?: string } } }>;
      error?: { message?: string };
    };

    if (!pagesRes.ok) {
      res.status(400).json({
        error:
          pagesJson.error?.message ||
          'تعذر جلب صفحات Facebook. تأكد من منح صلاحيات pages_show_list و pages_manage_posts.',
      });
      return;
    }

    const pages = (pagesJson.data ?? []).map((p) => ({
      id: p.id,
      name: p.name,
      category: p.category || '',
      pictureUrl: p.picture?.data?.url || null,
    }));

    db.prepare('UPDATE oauth_accounts SET metadata_json = ?, updated_at = ? WHERE id = ?').run(
      JSON.stringify({ pages }),
      new Date().toISOString(),
      acc.id
    );

    res.json({ pages });
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'خطأ في جلب صفحات فيسبوك' });
  }
});

// ======================== TIKTOK LOGIN KIT V2 OAUTH ========================

oauthApiRouter.get('/tiktok/url', attachOptionalUser, (req: AuthenticatedRequest, res: Response) => {
  if (!isTikTokConfigured()) {
    res.status(400).json({
      error:
        'إعدادات TikTok Login Kit غير مكتملة. يرجى إضافة TIKTOK_CLIENT_KEY و TIKTOK_CLIENT_SECRET في متغيرات البيئة.',
      code: 'OAUTH_NOT_CONFIGURED',
      callbackUrl: `${getAppBaseUrl()}/auth/tiktok/callback`,
    });
    return;
  }

  const mode = req.query.mode === 'connect' && req.user ? 'connect' : 'login';
  const includePublish = req.query.includePublish === '1' || mode === 'connect';
  const redirectUri = `${getAppBaseUrl()}/auth/tiktok/callback`;

  cleanExpiredRecords();
  const stateId = generateOpaqueToken(18);
  const { verifier, challenge } = generatePkcePair();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

  db.prepare(
    `INSERT INTO oauth_states (state_id, provider, mode, user_id, code_verifier, redirect_uri, expires_at, created_at)
     VALUES (?, 'tiktok', ?, ?, ?, ?, ?, ?)`
  ).run(stateId, mode, req.user?.id ?? null, verifier, redirectUri, expiresAt, new Date().toISOString());

  const scopes = includePublish
    ? 'user.info.basic,user.info.profile,video.publish,video.upload'
    : 'user.info.basic,user.info.profile';

  const params = new URLSearchParams({
    client_key: process.env.TIKTOK_CLIENT_KEY!.trim(),
    scope: scopes,
    response_type: 'code',
    redirect_uri: redirectUri,
    state: signState(stateId),
    code_challenge: challenge,
    code_challenge_method: 'S256',
  });

  res.json({ url: `https://www.tiktok.com/v2/auth/authorize/?${params.toString()}` });
});

async function handleTikTokCallback(req: Request, res: Response): Promise<void> {
  const errorParam = typeof req.query.error === 'string' ? req.query.error : '';
  const errorDesc = typeof req.query.error_description === 'string' ? req.query.error_description : '';
  if (errorParam) {
    res.status(200).send(
      renderPopupResultHtml(
        { type: 'OAUTH_AUTH_ERROR', provider: 'tiktok', error: errorDesc || errorParam },
        `تم إلغاء تسجيل الدخول عبر TikTok: ${errorDesc || errorParam}`
      )
    );
    return;
  }

  const code = typeof req.query.code === 'string' ? req.query.code : '';
  const rawState = typeof req.query.state === 'string' ? req.query.state : '';
  const stateId = verifySignedState(rawState);

  if (!code || !stateId) {
    res.status(400).send(
      renderPopupResultHtml(
        { type: 'OAUTH_AUTH_ERROR', provider: 'tiktok', error: 'Invalid TikTok state or missing code' },
        'فشل التحقق من جلسة المصادقة (State غير صالح).'
      )
    );
    return;
  }

  const stateRow = db
    .prepare("SELECT * FROM oauth_states WHERE state_id = ? AND provider = 'tiktok'")
    .get(stateId) as
    | {
        state_id: string;
        mode: string;
        user_id: string | null;
        code_verifier: string | null;
        redirect_uri: string;
        expires_at: string;
      }
    | undefined;

  if (!stateRow || new Date(stateRow.expires_at).getTime() <= Date.now()) {
    res.status(400).send(
      renderPopupResultHtml(
        { type: 'OAUTH_AUTH_ERROR', provider: 'tiktok', error: 'OAuth state expired' },
        'انتهت صلاحية طلب المصادقة. يرجى المحاولة مجدداً.'
      )
    );
    return;
  }

  db.prepare('DELETE FROM oauth_states WHERE state_id = ?').run(stateId);

  try {
    const bodyParams = new URLSearchParams({
      client_key: process.env.TIKTOK_CLIENT_KEY!.trim(),
      client_secret: process.env.TIKTOK_CLIENT_SECRET!.trim(),
      code,
      grant_type: 'authorization_code',
      redirect_uri: stateRow.redirect_uri,
      code_verifier: stateRow.code_verifier || '',
    });

    const tokenRes = await fetch('https://open.tiktokapis.com/v2/oauth/token/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: bodyParams.toString(),
    });

    const tokenJson = (await tokenRes.json()) as {
      access_token?: string;
      refresh_token?: string;
      expires_in?: number;
      open_id?: string;
      scope?: string;
      error?: string;
      error_description?: string;
    };

    if (!tokenRes.ok || !tokenJson.access_token || !tokenJson.open_id) {
      throw new Error(tokenJson.error_description || tokenJson.error || 'فشل تبديل رمز TikTok Token');
    }

    const userRes = await fetch(
      'https://open.tiktokapis.com/v2/user/info/?fields=open_id,union_id,avatar_url,display_name,username',
      {
        headers: {
          Authorization: `Bearer ${tokenJson.access_token}`,
        },
      }
    );

    const userJson = (await userRes.json()) as {
      data?: {
        user?: {
          open_id?: string;
          display_name?: string;
          avatar_url?: string;
          username?: string;
        };
      };
    };

    const tkUser = userJson.data?.user;

    const { userId } = resolveOrCreateOAuthUser({
      provider: 'tiktok',
      providerUserId: tkUser?.open_id || tokenJson.open_id,
      displayName: tkUser?.display_name || tkUser?.username || 'TikTok Creator',
      username: tkUser?.username ?? null,
      avatarUrl: tkUser?.avatar_url ?? null,
      email: null,
      accessToken: tokenJson.access_token,
      refreshToken: tokenJson.refresh_token ?? null,
      expiresInSec: tokenJson.expires_in ?? null,
      scopes: tokenJson.scope || 'user.info.basic',
      metadata: {},
      mode: stateRow.mode,
      connectUserId: stateRow.user_id,
    });

    const sessionToken = createSessionForUser(userId);
    setSessionCookie(req, res, sessionToken);
    const exchangeCode = createExchangeCode(sessionToken, 'tiktok', stateRow.mode);

    res.status(200).send(
      renderPopupResultHtml(
        {
          type: 'OAUTH_AUTH_SUCCESS',
          provider: 'tiktok',
          mode: stateRow.mode,
          exchangeCode,
        },
        'تم تسجيل الدخول وربط حساب TikTok بنجاح. يمكنك إغلاق هذه النافذة.'
      )
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : 'فشل الاتصال بـ TikTok';
    res.status(500).send(
      renderPopupResultHtml({ type: 'OAUTH_AUTH_ERROR', provider: 'tiktok', error: message }, message)
    );
  }
}

oauthCallbackRouter.get(['/tiktok/callback', '/tiktok/callback/'], (req, res) => {
  void handleTikTokCallback(req, res);
});

oauthApiRouter.get('/tiktok/creator-info', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const acc = db
    .prepare("SELECT * FROM oauth_accounts WHERE user_id = ? AND provider = 'tiktok'")
    .get(req.user!.id) as OAuthAccountRow | undefined;

  if (!acc) {
    res.status(404).json({ error: 'حساب TikTok غير مرتبط بهذا المستخدم.' });
    return;
  }

  try {
    const token = decryptText(acc.access_token_enc);
    const infoRes = await fetch('https://open.tiktokapis.com/v2/post/publish/creator_info/query/', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json; charset=UTF-8',
      },
    });
    const infoJson = (await infoRes.json()) as {
      data?: Record<string, unknown>;
      error?: { code?: string; message?: string };
    };

    if (!infoRes.ok || (infoJson.error?.code && infoJson.error.code !== 'ok')) {
      res.status(400).json({
        error:
          infoJson.error?.message ||
          'تعذر جلب إعدادات النشر من TikTok. تأكد من تفعيل Content Posting API وصلاحية video.publish.',
      });
      return;
    }

    res.json({ creatorInfo: infoJson.data ?? {} });
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'خطأ في الاستعلام عن حساب TikTok' });
  }
});

oauthApiRouter.delete('/:provider', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const provider = req.params.provider;
  if (provider !== 'facebook' && provider !== 'tiktok') {
    res.status(400).json({ error: 'منصة غير معروفة.' });
    return;
  }

  const user = req.user!;
  const otherProviders = user.linkedAccounts.filter((a) => a.provider !== provider);
  if (!user.hasPassword && otherProviders.length === 0) {
    res.status(400).json({
      error:
        'لا يمكن فصل طريقة الدخول الوحيدة لحسابك قبل تعيين كلمة مرور في إعدادات الحساب أولاً.',
    });
    return;
  }

  db.prepare('DELETE FROM oauth_accounts WHERE user_id = ? AND provider = ?').run(user.id, provider);
  res.json({ user: getPublicUserById(user.id) });
});
