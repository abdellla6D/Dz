import type { IncomingMessage } from 'node:http';
import type http from 'node:http';
import type { Duplex } from 'node:stream';
import { GoogleGenAI, Modality } from '@google/genai';
import type { LiveServerMessage } from '@google/genai';
import { WebSocket, WebSocketServer } from 'ws';
import { SESSION_COOKIE_NAME, verifySessionToken } from './auth.ts';

function getCookieValue(cookieHeader: string | undefined, name: string): string | null {
  if (!cookieHeader) return null;
  const pairs = cookieHeader.split(';');
  for (const pair of pairs) {
    const idx = pair.indexOf('=');
    if (idx === -1) continue;
    const key = pair.slice(0, idx).trim();
    if (key === name) {
      return decodeURIComponent(pair.slice(idx + 1).trim());
    }
  }
  return null;
}

const VALID_VOICES = new Set(['Kore', 'Puck', 'Charon', 'Fenrir', 'Zephyr']);

export function attachLiveWebSocketServer(server: http.Server): void {
  const wss = new WebSocketServer({ noServer: true });

  server.on('upgrade', (req: IncomingMessage, socket: Duplex, head: Buffer) => {
    try {
      const url = new URL(req.url || '/', 'http://localhost');
      if (url.pathname !== '/api/live') {
        return;
      }

      const queryToken = url.searchParams.get('token')?.trim() || null;
      const cookieToken = getCookieValue(req.headers.cookie, SESSION_COOKIE_NAME);
      const token = queryToken || cookieToken || '';

      const user = verifySessionToken(token);
      if (!user) {
        socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');
        socket.destroy();
        return;
      }

      wss.handleUpgrade(req, socket, head, (ws) => {
        wss.emit('connection', ws, req);
      });
    } catch {
      socket.destroy();
    }
  });

  wss.on('connection', async (clientWs: WebSocket, req: IncomingMessage) => {
    const apiKey = process.env.GEMINI_API_KEY?.trim();
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(
          JSON.stringify({
            error: 'مفتاح GEMINI_API_KEY غير مضبوط في إعدادات البيئة (Settings > Secrets).',
          })
        );
      }
      clientWs.close(1008, 'GEMINI_API_KEY missing');
      return;
    }

    const url = new URL(req.url || '/', 'http://localhost');
    const requestedVoice = url.searchParams.get('voiceName') || 'Kore';
    const voiceName = VALID_VOICES.has(requestedVoice) ? requestedVoice : 'Kore';
    const lang = url.searchParams.get('lang') === 'en' ? 'en' : 'ar';

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    let clientClosed = false;
    type LiveSession = Awaited<ReturnType<typeof ai.live.connect>>;
    let activeSession: LiveSession | null = null;

    const systemInstruction =
      lang === 'ar'
        ? 'أنت مخرج قصصي ومساعد إبداعي في استوديو StoryMaster AI. ساعد المبدع باللغة العربية الواضحة في تطوير أفكار القصص، صياغة نصوص التعليق الصوتي، وتحسين وصف المشاهد بإجابات مختصرة وودودة.'
        : 'You are a creative story director and voiceover coach inside StoryMaster AI Studio. Help the creator develop story concepts, narration scripts, and visual scene ideas concisely and warmly.';

    const sessionPromise = ai.live.connect({
      model: 'gemini-3.8-live',
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
        inputAudioTranscription: {},
        outputAudioTranscription: {},
        systemInstruction,
      },
      callbacks: {
        onopen: () => {
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify({ ready: true }));
          }
        },
        onmessage: (message: LiveServerMessage) => {
          if (clientWs.readyState !== WebSocket.OPEN) return;

          const content = message.serverContent;
          if (content?.inputTranscription?.text) {
            clientWs.send(JSON.stringify({ inputTranscript: content.inputTranscription.text }));
          }
          if (content?.outputTranscription?.text) {
            clientWs.send(JSON.stringify({ outputTranscript: content.outputTranscription.text }));
          }
          for (const part of content?.modelTurn?.parts ?? []) {
            if (part.inlineData?.data) {
              clientWs.send(JSON.stringify({ audio: part.inlineData.data }));
            }
          }
          if (content?.interrupted) {
            clientWs.send(JSON.stringify({ interrupted: true }));
          }
          if (content?.turnComplete) {
            clientWs.send(JSON.stringify({ turnComplete: true }));
          }
        },
        onerror: (err: unknown) => {
          if (clientWs.readyState === WebSocket.OPEN) {
            const msg = err instanceof Error ? err.message : 'Live session error';
            clientWs.send(JSON.stringify({ error: msg }));
          }
        },
        onclose: () => {
          if (!clientClosed && clientWs.readyState === WebSocket.OPEN) {
            clientWs.close();
          }
        },
      },
    });

    sessionPromise
      .then((session) => {
        activeSession = session;
        if (clientClosed) {
          session.close();
        }
      })
      .catch((err) => {
        if (clientWs.readyState === WebSocket.OPEN) {
          const msg = err instanceof Error ? err.message : 'Failed to open Gemini Live session';
          clientWs.send(JSON.stringify({ error: msg }));
          clientWs.close(1011, 'Gemini Live failed');
        }
      });

    clientWs.on('message', (rawData) => {
      try {
        const parsed = JSON.parse(rawData.toString()) as { audio?: string; text?: string };
        sessionPromise
          .then((session) => {
            if (clientClosed) return;
            if (typeof parsed.audio === 'string' && parsed.audio.length > 0) {
              session.sendRealtimeInput({
                audio: { data: parsed.audio, mimeType: 'audio/pcm;rate=16000' },
              });
            } else if (typeof parsed.text === 'string' && parsed.text.trim()) {
              session.sendRealtimeInput({ text: parsed.text.trim() });
            }
          })
          .catch(() => {});
      } catch {
        // Ignore malformed WS payload
      }
    });

    clientWs.on('close', () => {
      clientClosed = true;
      if (activeSession) {
        try {
          activeSession.close();
        } catch {
          // ignore
        }
      } else {
        sessionPromise
          .then((session) => {
            try {
              session.close();
            } catch {
              // ignore
            }
          })
          .catch(() => {});
      }
    });
  });
}
