import crypto from 'node:crypto';
import type { Response } from 'express';
import { Router } from 'express';
import { z } from 'zod';
import { requireAuth } from './auth.ts';
import type { AuthenticatedRequest } from './auth.ts';
import { db } from './db.ts';
import type { ProjectRow, SceneRow } from './db.ts';

export const projectsRouter = Router();
projectsRouter.use(requireAuth);

projectsRouter.get('/', (req: AuthenticatedRequest, res: Response) => {
  const projects = db
    .prepare(
      `SELECT p.*,
        (SELECT COUNT(*) FROM scenes s WHERE s.project_id = p.id) AS scene_count,
        (SELECT s2.image_data_url FROM scenes s2 WHERE s2.project_id = p.id AND s2.image_data_url IS NOT NULL ORDER BY s2.scene_order ASC LIMIT 1) AS cover_image
       FROM projects p
       WHERE p.user_id = ?
       ORDER BY p.updated_at DESC`
    )
    .all(req.user!.id);

  res.json({ projects });
});

const createProjectSchema = z.object({
  title: z.string().trim().min(1).max(160),
  topic: z.string().trim().max(2000).optional().default(''),
  language: z.enum(['ar', 'en']).optional().default('ar'),
  genre: z.string().trim().max(60).optional().default('cinematic'),
  aspectRatio: z.enum(['9:16', '16:9', '1:1']).optional().default('9:16'),
  storyText: z.string().max(30000).optional().default(''),
  voiceName: z.enum(['Kore', 'Puck', 'Charon', 'Fenrir', 'Zephyr']).optional().default('Kore'),
});

projectsRouter.post('/', (req: AuthenticatedRequest, res: Response) => {
  const parsed = createProjectSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'بيانات المشروع غير صالحة.' });
    return;
  }

  const projectId = crypto.randomUUID();
  const now = new Date().toISOString();
  const d = parsed.data;

  db.prepare(
    `INSERT INTO projects (id, user_id, title, topic, language, genre, aspect_ratio, story_text, status, voice_name, voice_style, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?, '', ?, ?)`
  ).run(projectId, req.user!.id, d.title, d.topic, d.language, d.genre, d.aspectRatio, d.storyText, d.voiceName, now, now);

  const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(projectId) as unknown as ProjectRow;
  res.status(201).json({ project, scenes: [] });
});

projectsRouter.get('/:id', (req: AuthenticatedRequest, res: Response) => {
  const project = db
    .prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?')
    .get(req.params.id, req.user!.id) as ProjectRow | undefined;

  if (!project) {
    res.status(404).json({ error: 'المشروع غير موجود.' });
    return;
  }

  const scenes = db
    .prepare('SELECT * FROM scenes WHERE project_id = ? AND user_id = ? ORDER BY scene_order ASC')
    .all(project.id, req.user!.id) as unknown as SceneRow[];

  res.json({ project, scenes });
});

const updateProjectSchema = z.object({
  title: z.string().trim().min(1).max(160).optional(),
  storyText: z.string().max(30000).optional(),
  aspectRatio: z.enum(['9:16', '16:9', '1:1']).optional(),
  language: z.enum(['ar', 'en']).optional(),
  genre: z.string().trim().max(60).optional(),
  status: z.enum(['draft', 'ready', 'published']).optional(),
  voiceName: z.enum(['Kore', 'Puck', 'Charon', 'Fenrir', 'Zephyr']).optional(),
  voiceStyle: z.string().trim().max(200).optional(),
});

projectsRouter.patch('/:id', (req: AuthenticatedRequest, res: Response) => {
  const parsed = updateProjectSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'تعذر التحقق من البيانات المرسلة.' });
    return;
  }

  const current = db
    .prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?')
    .get(req.params.id, req.user!.id) as ProjectRow | undefined;

  if (!current) {
    res.status(404).json({ error: 'المشروع غير موجود.' });
    return;
  }

  const d = parsed.data;
  const now = new Date().toISOString();

  db.prepare(
    `UPDATE projects SET
      title = ?, story_text = ?, aspect_ratio = ?, language = ?, genre = ?,
      status = ?, voice_name = ?, voice_style = ?, updated_at = ?
     WHERE id = ? AND user_id = ?`
  ).run(
    d.title ?? current.title,
    d.storyText ?? current.story_text,
    d.aspectRatio ?? current.aspect_ratio,
    d.language ?? current.language,
    d.genre ?? current.genre,
    d.status ?? current.status,
    d.voiceName ?? current.voice_name,
    d.voiceStyle ?? current.voice_style,
    now,
    current.id,
    req.user!.id
  );

  const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(current.id) as unknown as ProjectRow;
  res.json({ project });
});

projectsRouter.delete('/:id', (req: AuthenticatedRequest, res: Response) => {
  const info = db
    .prepare('DELETE FROM projects WHERE id = ? AND user_id = ?')
    .run(req.params.id, req.user!.id);

  if (info.changes === 0) {
    res.status(404).json({ error: 'المشروع غير موجود.' });
    return;
  }
  res.json({ ok: true });
});

const addSceneSchema = z.object({
  title: z.string().trim().min(1).max(160),
  narrationText: z.string().trim().max(4000).default(''),
  imagePrompt: z.string().trim().max(2000).default(''),
  durationSec: z.number().min(2).max(60).default(6),
});

projectsRouter.post('/:id/scenes', (req: AuthenticatedRequest, res: Response) => {
  const parsed = addSceneSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'بيانات المشهد غير صالحة.' });
    return;
  }

  const project = db
    .prepare('SELECT id FROM projects WHERE id = ? AND user_id = ?')
    .get(req.params.id, req.user!.id);
  if (!project) {
    res.status(404).json({ error: 'المشروع غير موجود.' });
    return;
  }

  const maxOrderRow = db
    .prepare('SELECT COALESCE(MAX(scene_order), 0) AS max_order FROM scenes WHERE project_id = ?')
    .get(req.params.id) as { max_order: number };

  const sceneId = crypto.randomUUID();
  const now = new Date().toISOString();
  db.prepare(
    `INSERT INTO scenes (
      id, project_id, user_id, scene_order, title, narration_text, image_prompt,
      image_data_url, audio_data_url, duration_sec, transition, subtitle_enabled, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, NULL, NULL, ?, 'fade', 1, ?, ?)`
  ).run(
    sceneId,
    req.params.id,
    req.user!.id,
    maxOrderRow.max_order + 1,
    parsed.data.title,
    parsed.data.narrationText,
    parsed.data.imagePrompt,
    parsed.data.durationSec,
    now,
    now
  );

  const scene = db.prepare('SELECT * FROM scenes WHERE id = ?').get(sceneId) as unknown as SceneRow;
  res.status(201).json({ scene });
});

const updateSceneSchema = z.object({
  title: z.string().trim().min(1).max(160).optional(),
  narrationText: z.string().max(4000).optional(),
  imagePrompt: z.string().max(2000).optional(),
  imageDataUrl: z.string().max(12_000_000).nullable().optional(),
  audioDataUrl: z.string().max(25_000_000).nullable().optional(),
  durationSec: z.number().min(2).max(60).optional(),
  transition: z.enum(['fade', 'zoom', 'slide', 'none']).optional(),
  subtitleEnabled: z.boolean().optional(),
  sceneOrder: z.number().int().min(1).max(100).optional(),
});

function isSafeImageRef(val: string): boolean {
  if (val.startsWith('/src/assets/images/') && !val.includes('..')) return true;
  return /^data:image\/(png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=]+$/.test(val);
}

function isSafeAudioRef(val: string): boolean {
  return /^data:audio\/(wav|mpeg|mp3|ogg|webm);base64,[A-Za-z0-9+/=]+$/.test(val);
}

projectsRouter.patch('/scenes/:sceneId', (req: AuthenticatedRequest, res: Response) => {
  const parsed = updateSceneSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'بيانات تحديث المشهد غير صالحة.' });
    return;
  }

  const current = db
    .prepare('SELECT * FROM scenes WHERE id = ? AND user_id = ?')
    .get(req.params.sceneId, req.user!.id) as SceneRow | undefined;

  if (!current) {
    res.status(404).json({ error: 'المشهد غير موجود.' });
    return;
  }

  const d = parsed.data;
  if (typeof d.imageDataUrl === 'string' && !isSafeImageRef(d.imageDataUrl)) {
    res.status(400).json({ error: 'صيغة الصورة غير مدعومة (PNG/JPEG/WebP فقط).' });
    return;
  }
  if (typeof d.audioDataUrl === 'string' && !isSafeAudioRef(d.audioDataUrl)) {
    res.status(400).json({ error: 'صيغة الصوت غير مدعومة.' });
    return;
  }

  const now = new Date().toISOString();
  db.prepare(
    `UPDATE scenes SET
      title = ?, narration_text = ?, image_prompt = ?, image_data_url = ?, audio_data_url = ?,
      duration_sec = ?, transition = ?, subtitle_enabled = ?, scene_order = ?, updated_at = ?
     WHERE id = ? AND user_id = ?`
  ).run(
    d.title ?? current.title,
    d.narrationText ?? current.narration_text,
    d.imagePrompt ?? current.image_prompt,
    d.imageDataUrl !== undefined ? d.imageDataUrl : current.image_data_url,
    d.audioDataUrl !== undefined ? d.audioDataUrl : current.audio_data_url,
    d.durationSec ?? current.duration_sec,
    d.transition ?? current.transition,
    d.subtitleEnabled !== undefined ? (d.subtitleEnabled ? 1 : 0) : current.subtitle_enabled,
    d.sceneOrder ?? current.scene_order,
    now,
    current.id,
    req.user!.id
  );

  db.prepare('UPDATE projects SET updated_at = ? WHERE id = ?').run(now, current.project_id);
  const scene = db.prepare('SELECT * FROM scenes WHERE id = ?').get(current.id) as unknown as SceneRow;
  res.json({ scene });
});

projectsRouter.delete('/scenes/:sceneId', (req: AuthenticatedRequest, res: Response) => {
  const info = db
    .prepare('DELETE FROM scenes WHERE id = ? AND user_id = ?')
    .run(req.params.sceneId, req.user!.id);
  if (info.changes === 0) {
    res.status(404).json({ error: 'المشهد غير موجود.' });
    return;
  }
  res.json({ ok: true });
});
