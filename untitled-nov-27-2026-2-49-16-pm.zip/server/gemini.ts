import crypto from 'node:crypto';
import { GoogleGenAI, Type } from '@google/genai';
import type { Response } from 'express';
import { Router } from 'express';
import { z } from 'zod';
import { requireAuth } from './auth.ts';
import type { AuthenticatedRequest } from './auth.ts';
import { db } from './db.ts';
import type { ProjectRow, SceneRow } from './db.ts';

function getAiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('GEMINI_API_KEY_MISSING');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function classifyGeminiError(err: unknown): { status: number; message: string; code: string } {
  const raw = err instanceof Error ? err.message : String(err);
  if (raw === 'GEMINI_API_KEY_MISSING') {
    return {
      status: 503,
      code: 'GEMINI_KEY_MISSING',
      message: 'مفتاح GEMINI_API_KEY غير مضبوط في إعدادات البيئة (Settings > Secrets).',
    };
  }
  const upper = raw.toUpperCase();
  if (upper.includes('PERMISSION_DENIED') || upper.includes('403') || upper.includes('BILLING')) {
    return {
      status: 403,
      code: 'PAID_KEY_REQUIRED',
      message:
        'توليد الصور يتطلب مفتاح Gemini API مرتبطاً بحساب فوترة (Paid Key). يرجى تحديد مفتاح مدفوع في Settings > Secrets أو رفع صورة خاصة للمشهد.',
    };
  }
  if (upper.includes('RESOURCE_EXHAUSTED') || upper.includes('429') || upper.includes('QUOTA')) {
    return {
      status: 429,
      code: 'QUOTA_EXCEEDED',
      message:
        'تم تجاوز حصة الاستخدام المتاحة لمفتاح Gemini API الحالي (429). يرجى المحاولة لاحقاً أو الترقية إلى مفتاح مدفوع في Settings > Secrets.',
    };
  }
  if (upper.includes('API_KEY_INVALID') || upper.includes('INVALID_ARGUMENT')) {
    return {
      status: 400,
      code: 'API_KEY_INVALID',
      message: 'مفتاح Gemini API غير صالح أو البيانات المرسلة غير مدعومة.',
    };
  }
  return {
    status: 500,
    code: 'GEMINI_ERROR',
    message: raw || 'حدث خطأ أثناء الاتصال بخدمة Google Gemini.',
  };
}

export const geminiRouter = Router();
geminiRouter.use(requireAuth);

const generateStorySchema = z.object({
  topic: z.string().trim().min(3).max(2000),
  language: z.enum(['ar', 'en']).default('ar'),
  genre: z.string().trim().min(2).max(60).default('cinematic'),
  aspectRatio: z.enum(['9:16', '16:9', '1:1']).default('9:16'),
  sceneCount: z.number().int().min(3).max(12).default(5),
  voiceName: z.enum(['Kore', 'Puck', 'Charon', 'Fenrir', 'Zephyr']).default('Kore'),
});

const storyResponseSchema = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: 'Compelling story title' },
    fullStory: {
      type: Type.STRING,
      description: 'Complete, rich narrative story prose suitable for storytelling and adaptation',
    },
    scenes: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          sceneOrder: { type: Type.INTEGER },
          title: { type: Type.STRING },
          narrationText: {
            type: Type.STRING,
            description: 'Voiceover narration script for this scene in the requested language',
          },
          imagePrompt: {
            type: Type.STRING,
            description: 'Detailed cinematic English visual prompt for AI image generation, with lighting, lens, mood, and composition',
          },
          durationSec: { type: Type.NUMBER },
        },
        required: ['sceneOrder', 'title', 'narrationText', 'imagePrompt', 'durationSec'],
      },
    },
  },
  required: ['title', 'fullStory', 'scenes'],
};

geminiRouter.post('/generate-story', async (req: AuthenticatedRequest, res: Response) => {
  const parsed = generateStorySchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'يرجى إدخال فكرة أو موضوع صالح للقصة (3 أحرف على الأقل).' });
    return;
  }

  const { topic, language, genre, aspectRatio, sceneCount, voiceName } = parsed.data;
  const langLabel = language === 'ar' ? 'Arabic (Modern Standard / engaging narrative)' : 'English';

  try {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Create a long, vivid, emotionally engaging story based on this prompt/topic: "${topic}".
Genre / Tone: ${genre}.
Target Language for Title, Full Story, Scene Titles, and Narration: ${langLabel}.
Target Aspect Ratio: ${aspectRatio}.
Break the full story into exactly ${sceneCount} sequential visual scenes.
For every scene:
- "title" and "narrationText" MUST be written in ${langLabel}.
- "narrationText" should be rich, natural voiceover narration (around 2-4 sentences per scene).
- "imagePrompt" MUST be written in descriptive cinematic English optimized for visual generation (camera angle, lighting, atmosphere, color palette, no text/watermarks).
- "durationSec" should be between 5 and 12 seconds depending on narration length.`,
      config: {
        systemInstruction:
          'You are an award-winning screenwriter, storyteller, and film director. Produce cohesive, deeply engaging stories and structured cinematic scenes.',
        responseMimeType: 'application/json',
        responseSchema: storyResponseSchema,
      },
    });

    const rawText = (response.text ?? '').trim();
    if (!rawText) {
      throw new Error('لم يُرجع نموذج Gemini نصاً للقصة.');
    }

    const generated = JSON.parse(rawText) as {
      title: string;
      fullStory: string;
      scenes: Array<{
        sceneOrder: number;
        title: string;
        narrationText: string;
        imagePrompt: string;
        durationSec: number;
      }>;
    };

    const projectId = crypto.randomUUID();
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO projects (
        id, user_id, title, topic, language, genre, aspect_ratio, story_text, status, voice_name, voice_style, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?, '', ?, ?)`
    ).run(
      projectId,
      req.user!.id,
      generated.title || topic.slice(0, 60),
      topic,
      language,
      genre,
      aspectRatio,
      generated.fullStory || '',
      voiceName,
      now,
      now
    );

    const insertScene = db.prepare(
      `INSERT INTO scenes (
        id, project_id, user_id, scene_order, title, narration_text, image_prompt,
        image_data_url, audio_data_url, duration_sec, transition, subtitle_enabled, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, NULL, NULL, ?, 'fade', 1, ?, ?)`
    );

    const scenes = (generated.scenes ?? []).map((sc, idx) => {
      const id = crypto.randomUUID();
      const order = idx + 1;
      const duration = Math.min(20, Math.max(4, Number(sc.durationSec) || 6));
      insertScene.run(
        id,
        projectId,
        req.user!.id,
        order,
        sc.title || `Scene ${order}`,
        sc.narrationText || '',
        sc.imagePrompt || '',
        duration,
        now,
        now
      );
      return {
        id,
        project_id: projectId,
        user_id: req.user!.id,
        scene_order: order,
        title: sc.title,
        narration_text: sc.narrationText,
        image_prompt: sc.imagePrompt,
        image_data_url: null,
        audio_data_url: null,
        duration_sec: duration,
        transition: 'fade',
        subtitle_enabled: 1,
        created_at: now,
        updated_at: now,
      };
    });

    const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(projectId) as unknown as ProjectRow;
    res.status(201).json({ project, scenes });
  } catch (err) {
    const info = classifyGeminiError(err);
    res.status(info.status).json({ error: info.message, code: info.code });
  }
});

const regenerateScenesSchema = z.object({
  projectId: z.string().uuid(),
  storyText: z.string().trim().min(20).max(30000),
  title: z.string().trim().min(1).max(160).optional(),
  sceneCount: z.number().int().min(3).max(12).default(5),
  language: z.enum(['ar', 'en']).optional(),
});

geminiRouter.post('/regenerate-scenes', async (req: AuthenticatedRequest, res: Response) => {
  const parsed = regenerateScenesSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'نص القصة قصير جداً أو معرف المشروع غير صالح.' });
    return;
  }

  const { projectId, storyText, title, sceneCount, language } = parsed.data;
  const project = db
    .prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?')
    .get(projectId, req.user!.id) as ProjectRow | undefined;

  if (!project) {
    res.status(404).json({ error: 'المشروع غير موجود أو لا تملك صلاحية تعديله.' });
    return;
  }

  const targetLang = language ?? (project.language === 'en' ? 'en' : 'ar');
  const langLabel = targetLang === 'ar' ? 'Arabic' : 'English';

  try {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Adapt and split the following edited story into exactly ${sceneCount} sequential cinematic scenes.
Language for scene title & narration: ${langLabel}.
Aspect Ratio: ${project.aspect_ratio}.
Story:
"""
${storyText}
"""
Return the updated story (cleaned/preserved) and exactly ${sceneCount} scenes with vivid English image prompts.`,
      config: {
        systemInstruction:
          'You are a film director adapting a written story into structured scenes for video production. Preserve the author narrative closely.',
        responseMimeType: 'application/json',
        responseSchema: storyResponseSchema,
      },
    });

    const rawText = (response.text ?? '').trim();
    const generated = JSON.parse(rawText) as {
      title: string;
      fullStory: string;
      scenes: Array<{
        sceneOrder: number;
        title: string;
        narrationText: string;
        imagePrompt: string;
        durationSec: number;
      }>;
    };

    const now = new Date().toISOString();
    db.prepare(
      'UPDATE projects SET title = ?, story_text = ?, language = ?, updated_at = ? WHERE id = ? AND user_id = ?'
    ).run(title || project.title, storyText, targetLang, now, projectId, req.user!.id);

    db.prepare('DELETE FROM scenes WHERE project_id = ? AND user_id = ?').run(projectId, req.user!.id);

    const insertScene = db.prepare(
      `INSERT INTO scenes (
        id, project_id, user_id, scene_order, title, narration_text, image_prompt,
        image_data_url, audio_data_url, duration_sec, transition, subtitle_enabled, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, NULL, NULL, ?, 'fade', 1, ?, ?)`
    );

    const scenes = (generated.scenes ?? []).map((sc, idx) => {
      const id = crypto.randomUUID();
      const order = idx + 1;
      const duration = Math.min(20, Math.max(4, Number(sc.durationSec) || 6));
      insertScene.run(
        id,
        projectId,
        req.user!.id,
        order,
        sc.title || `Scene ${order}`,
        sc.narrationText || '',
        sc.imagePrompt || '',
        duration,
        now,
        now
      );
      return {
        id,
        project_id: projectId,
        user_id: req.user!.id,
        scene_order: order,
        title: sc.title,
        narration_text: sc.narrationText,
        image_prompt: sc.imagePrompt,
        image_data_url: null,
        audio_data_url: null,
        duration_sec: duration,
        transition: 'fade',
        subtitle_enabled: 1,
        created_at: now,
        updated_at: now,
      };
    });

    const updatedProject = db.prepare('SELECT * FROM projects WHERE id = ?').get(projectId) as unknown as ProjectRow;
    res.json({ project: updatedProject, scenes });
  } catch (err) {
    const info = classifyGeminiError(err);
    res.status(info.status).json({ error: info.message, code: info.code });
  }
});

const refinePromptSchema = z.object({
  narrationText: z.string().trim().min(2).max(4000),
  styleHint: z.string().trim().max(200).optional(),
});

geminiRouter.post('/refine-prompt', async (req: AuthenticatedRequest, res: Response) => {
  const parsed = refinePromptSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'يرجى إدخال نص المشهد لإنشاء وصف بصري.' });
    return;
  }

  try {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Write a single vivid, cinematic English image-generation prompt (no quotes, no preamble) for this scene narration:
"${parsed.data.narrationText}"
${parsed.data.styleHint ? `Visual style: ${parsed.data.styleHint}` : 'Visual style: Cinematic film still, dramatic lighting, rich textures, no text or watermarks.'}`,
    });

    res.json({ imagePrompt: (response.text ?? '').trim() });
  } catch (err) {
    const info = classifyGeminiError(err);
    res.status(info.status).json({ error: info.message, code: info.code });
  }
});

const generateImageSchema = z.object({
  prompt: z.string().trim().min(3).max(2000),
  aspectRatio: z.enum(['1:1', '3:4', '4:3', '9:16', '16:9']).default('9:16'),
  sceneId: z.string().uuid().optional(),
});

geminiRouter.post('/generate-image', async (req: AuthenticatedRequest, res: Response) => {
  const parsed = generateImageSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'يرجى كتابة وصف واضح للصورة.' });
    return;
  }

  const { prompt, aspectRatio, sceneId } = parsed.data;

  if (sceneId) {
    const scene = db
      .prepare('SELECT id FROM scenes WHERE id = ? AND user_id = ?')
      .get(sceneId, req.user!.id);
    if (!scene) {
      res.status(404).json({ error: 'المشهد غير موجود أو لا تملك صلاحية تعديله.' });
      return;
    }
  }

  try {
    const ai = getAiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite-image',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio,
        },
      },
    });

    let imageDataUrl: string | null = null;
    for (const part of response.candidates?.[0]?.content?.parts ?? []) {
      if (part.inlineData?.data) {
        const mime = part.inlineData.mimeType ?? 'image/png';
        imageDataUrl = `data:${mime};base64,${part.inlineData.data}`;
        break;
      }
    }

    if (!imageDataUrl) {
      throw new Error('لم تُرجع عملية التوليد صورة صالحة.');
    }

    if (sceneId) {
      const now = new Date().toISOString();
      db.prepare('UPDATE scenes SET image_data_url = ?, image_prompt = ?, updated_at = ? WHERE id = ? AND user_id = ?').run(
        imageDataUrl,
        prompt,
        now,
        sceneId,
        req.user!.id
      );
    }

    res.json({ imageDataUrl });
  } catch (err) {
    const info = classifyGeminiError(err);
    res.status(info.status).json({ error: info.message, code: info.code });
  }
});

const generateVoiceoverSchema = z.object({
  text: z.string().trim().min(2).max(5000),
  voiceName: z.enum(['Kore', 'Puck', 'Charon', 'Fenrir', 'Zephyr']).default('Kore'),
  style: z.string().trim().max(200).optional(),
  language: z.enum(['ar', 'en']).default('ar'),
  sceneId: z.string().uuid().optional(),
});

geminiRouter.post('/generate-voiceover', async (req: AuthenticatedRequest, res: Response) => {
  const parsed = generateVoiceoverSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'يرجى إدخال نص التعليق الصوتي.' });
    return;
  }

  const { text, voiceName, style, language, sceneId } = parsed.data;

  if (sceneId) {
    const scene = db
      .prepare('SELECT id FROM scenes WHERE id = ? AND user_id = ?')
      .get(sceneId, req.user!.id) as SceneRow | undefined;
    if (!scene) {
      res.status(404).json({ error: 'المشهد غير موجود أو لا تملك صلاحية تعديله.' });
      return;
    }
  }

  try {
    const ai = getAiClient();
    const defaultStyle =
      language === 'ar'
        ? 'Warm, expressive Arabic documentary storyteller with clear pronunciation'
        : 'Warm, expressive cinematic documentary narrator';

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text,
              speechMetadata: {
                style: style?.trim() || defaultStyle,
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      throw new Error('لم يُرجع نموذج الصوت بيانات WAV صالحة.');
    }

    const audioDataUrl = `data:audio/wav;base64,${base64Audio}`;

    if (sceneId) {
      db.prepare('UPDATE scenes SET audio_data_url = ?, narration_text = ?, updated_at = ? WHERE id = ? AND user_id = ?').run(
        audioDataUrl,
        text,
        new Date().toISOString(),
        sceneId,
        req.user!.id
      );
    }

    res.json({ audioDataUrl });
  } catch (err) {
    const info = classifyGeminiError(err);
    res.status(info.status).json({ error: info.message, code: info.code });
  }
});

const generateVideoSchema = z.object({
  prompt: z.string().trim().min(5).max(2000),
  aspectRatio: z.enum(['16:9', '9:16']).default('16:9'),
  duration: z.enum(['3s', '5s', '8s', '10s']).default('5s'),
});

geminiRouter.post('/generate-video', async (req: AuthenticatedRequest, res: Response) => {
  const parsed = generateVideoSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'يرجى إدخال وصف واضح للفيديو (5 أحرف على الأقل).' });
    return;
  }

  const { prompt, aspectRatio, duration } = parsed.data;

  try {
    const ai = getAiClient();
    const interaction = await ai.interactions.create(
      {
        model: 'gemini-omni-1.2-flash',
        input: prompt,
        background: false,
        store: false,
        stream: false,
        response_format: {
          type: 'video',
          aspect_ratio: aspectRatio,
          duration,
          resolution: '720p',
        },
      },
      { timeout: 300000 }
    );

    const videoPart = interaction.output_video;
    if (!videoPart || (!videoPart.data && !videoPart.uri)) {
      throw new Error('لم يُرجع نموذج Omni Flash مقطع فيديو.');
    }

    const mimeType = videoPart.mime_type || 'video/mp4';
    const videoDataUrl = videoPart.data
      ? `data:${mimeType};base64,${videoPart.data}`
      : null;

    res.json({
      videoDataUrl,
      videoUri: videoPart.uri ?? null,
      mimeType,
    });
  } catch (err) {
    const info = classifyGeminiError(err);
    res.status(info.status).json({ error: info.message, code: info.code });
  }
});

const transcribeAudioSchema = z.object({
  audioBase64: z.string().min(10),
  mimeType: z.string().trim().min(3).max(80).default('audio/webm'),
  language: z.enum(['ar', 'en']).optional(),
});

geminiRouter.post('/transcribe-audio', async (req: AuthenticatedRequest, res: Response) => {
  const parsed = transcribeAudioSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'بيانات الصوت المرسلة غير صالحة.' });
    return;
  }

  const { audioBase64, mimeType, language } = parsed.data;
  const cleanBase64 = audioBase64.includes(',') ? audioBase64.split(',')[1] : audioBase64;
  const cleanMime = mimeType.split(';')[0].trim() || 'audio/webm';

  try {
    const ai = getAiClient();
    const langInstruction =
      language === 'ar'
        ? 'Transcribe this spoken audio accurately in Arabic (or preserve mixed words naturally). Return only the transcript text.'
        : language === 'en'
        ? 'Transcribe this spoken audio accurately in English. Return only the transcript text.'
        : 'Transcribe this audio accurately in its original spoken language. Return only the transcript text.';

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-transcribe',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: cleanMime,
              data: cleanBase64,
            },
          },
          { text: langInstruction },
        ],
      },
    });

    res.json({ transcript: (response.text ?? '').trim() });
  } catch (err) {
    const info = classifyGeminiError(err);
    res.status(info.status).json({ error: info.message, code: info.code });
  }
});

