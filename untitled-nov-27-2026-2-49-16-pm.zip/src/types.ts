export type Lang = 'ar' | 'en';

export type SectionKey =
  | 'home'
  | 'create'
  | 'projects'
  | 'images'
  | 'voiceover'
  | 'editor'
  | 'accounts'
  | 'settings';

export interface LinkedAccount {
  provider: 'facebook' | 'tiktok';
  providerUserId: string;
  displayName: string | null;
  username: string | null;
  avatarUrl: string | null;
  email: string | null;
  scopes: string[];
  connectedAt: string;
  metadata: Record<string, unknown>;
}

export interface User {
  id: string;
  email: string | null;
  name: string;
  avatarUrl: string | null;
  bio: string;
  preferredLanguage: Lang;
  hasPassword: boolean;
  hasRecoveryKey: boolean;
  createdAt: string;
  linkedAccounts: LinkedAccount[];
}

export interface Project {
  id: string;
  user_id: string;
  title: string;
  topic: string;
  language: Lang;
  genre: string;
  aspect_ratio: '9:16' | '16:9' | '1:1';
  story_text: string;
  status: 'draft' | 'ready' | 'published';
  voice_name: 'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr';
  voice_style: string;
  created_at: string;
  updated_at: string;
  scene_count?: number;
  cover_image?: string | null;
}

export interface Scene {
  id: string;
  project_id: string;
  user_id: string;
  scene_order: number;
  title: string;
  narration_text: string;
  image_prompt: string;
  image_data_url: string | null;
  audio_data_url: string | null;
  duration_sec: number;
  transition: 'fade' | 'zoom' | 'slide' | 'none';
  subtitle_enabled: number;
  created_at: string;
  updated_at: string;
}

export interface PublishJob {
  id: string;
  user_id: string;
  project_id: string | null;
  platform: 'facebook' | 'tiktok';
  target_id: string | null;
  target_name: string | null;
  title: string;
  description: string;
  privacy_level: string | null;
  status: 'pending' | 'processing' | 'published' | 'failed';
  external_post_id: string | null;
  error_message: string | null;
  created_at: string;
}

export interface OAuthStatus {
  appUrl: string;
  facebook: {
    configured: boolean;
    callbackUrl: string;
  };
  tiktok: {
    configured: boolean;
    callbackUrl: string;
  };
}

export interface FacebookPage {
  id: string;
  name: string;
  category: string;
  pictureUrl: string | null;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  title: string;
  description?: string;
}
