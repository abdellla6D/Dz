import { useCallback, useEffect, useState } from 'react';
import { signOut } from 'firebase/auth';
import {
  Film,
  FolderOpen,
  Home,
  Image as ImageIcon,
  Link2,
  Loader2,
  LogOut,
  Menu,
  Mic,
  Moon,
  PenTool,
  Settings,
  Sun,
  X,
} from 'lucide-react';
import { AccountSettingsView } from './components/AccountSettingsView';
import { AuthView } from './components/AuthView';
import { BrandMark } from './components/BrandMark';
import { HomeView } from './components/HomeView';
import { ImageStudioView } from './components/ImageStudioView';
import { LinkedAccountsView } from './components/LinkedAccountsView';
import { ProjectsView } from './components/ProjectsView';
import { ResilientImage } from './components/ResilientImage';
import { StoryStudioView } from './components/StoryStudioView';
import { ToastContainer } from './components/ToastContainer';
import { VideoEditorPublishView } from './components/VideoEditorPublishView';
import { VoiceoverStudioView } from './components/VoiceoverStudioView';
import { auth } from './firebase';
import { navItems, t } from './i18n';
import { api, setAuthToken } from './lib/api';
import {
  deleteProjectFromFirestore,
  subscribeUserProjects,
  syncProjectToFirestore,
  syncPublishJobToFirestore,
  syncUserProfileToFirestore,
} from './lib/firestoreSync';
import type { Lang, Project, PublishJob, Scene, SectionKey, ToastMessage, User } from './types';

const SECTION_ICONS: Record<SectionKey, typeof Home> = {
  home: Home,
  create: PenTool,
  projects: FolderOpen,
  images: ImageIcon,
  voiceover: Mic,
  editor: Film,
  accounts: Link2,
  settings: Settings,
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [checkingAuth, setCheckingAuth] = useState(true);

  const [lang, setLang] = useState<Lang>('ar');
  const [darkMode, setDarkMode] = useState(true);
  const [section, setSection] = useState<SectionKey>('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const [scenes, setScenes] = useState<Scene[]>([]);
  const [publishJobs, setPublishJobs] = useState<PublishJob[]>([]);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((item) => item.id !== id));
  }, []);

  const addToast = useCallback((toast: Omit<ToastMessage, 'id'>) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    setToasts((prev) => [...prev.slice(-4), { ...toast, id }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((item) => item.id !== id));
    }, 6500);
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const loadWorkspaceData = useCallback(async () => {
    try {
      const [projRes, jobsRes] = await Promise.all([api.listProjects(), api.listPublishJobs()]);
      setProjects(projRes.projects);
      setPublishJobs(jobsRes.jobs);
      if (projRes.projects.length > 0) {
        const firstId = projRes.projects[0].id;
        const detail = await api.getProject(firstId);
        setActiveProject(detail.project);
        setScenes(detail.scenes);
      } else {
        setActiveProject(null);
        setScenes([]);
      }
    } catch {
      // Ignore background fetch errors if logged out
    }
  }, []);

  useEffect(() => {
    api
      .me()
      .then((res) => {
        setUser(res.user);
        setLang(res.user.preferredLanguage);
        return loadWorkspaceData();
      })
      .catch(() => {
        setUser(null);
      })
      .finally(() => {
        setCheckingAuth(false);
      });
  }, [loadWorkspaceData]);

  useEffect(() => {
    const fbUid = auth.currentUser?.uid;
    if (!user || !fbUid || !auth.currentUser?.emailVerified) return;
    const unsubscribe = subscribeUserProjects(fbUid, () => {});
    return () => unsubscribe();
  }, [user]);

  const handleAuthenticated = async (authedUser: User) => {
    setUser(authedUser);
    setLang(authedUser.preferredLanguage);
    setSection('home');
    await loadWorkspaceData();
  };

  const handleLoggedOut = () => {
    if (auth.currentUser) {
      void signOut(auth).catch(() => {});
    }
    setAuthToken(null);
    setUser(null);
    setProjects([]);
    setActiveProject(null);
    setScenes([]);
    setPublishJobs([]);
    setSection('home');
  };

  const handleSelectProject = async (projectId: string, targetSection?: SectionKey) => {
    try {
      const res = await api.getProject(projectId);
      setActiveProject(res.project);
      setScenes(res.scenes);
      if (targetSection) setSection(targetSection);
    } catch {
      // ignore
    }
  };

  const handleProjectCreatedOrUpdated = (project: Project, nextScenes: Scene[]) => {
    setActiveProject(project);
    setScenes(nextScenes);
    setProjects((prev) => {
      const exists = prev.some((p) => p.id === project.id);
      const withCounts: Project = {
        ...project,
        scene_count: nextScenes.length,
        cover_image: nextScenes.find((s) => s.image_data_url)?.image_data_url ?? project.cover_image ?? null,
      };
      if (exists) {
        return prev.map((p) => (p.id === project.id ? withCounts : p));
      }
      return [withCounts, ...prev];
    });
    void syncProjectToFirestore(project, nextScenes.length).catch(() => {});
  };

  const handleSceneUpdated = (updatedScene: Scene) => {
    setScenes((prev) => prev.map((s) => (s.id === updatedScene.id ? updatedScene : s)));
    setProjects((prev) =>
      prev.map((p) =>
        p.id === updatedScene.project_id && updatedScene.image_data_url && !p.cover_image
          ? { ...p, cover_image: updatedScene.image_data_url }
          : p
      )
    );
  };

  const handleSceneDeleted = (sceneId: string) => {
    setScenes((prev) => prev.filter((s) => s.id !== sceneId));
  };

  const handleProjectDeleted = async (projectId: string) => {
    void deleteProjectFromFirestore(projectId).catch(() => {});
    const remaining = projects.filter((p) => p.id !== projectId);
    setProjects(remaining);
    if (activeProject?.id === projectId) {
      if (remaining.length > 0) {
        await handleSelectProject(remaining[0].id);
      } else {
        setActiveProject(null);
        setScenes([]);
      }
    }
  };

  if (checkingAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-[#0B0F17]">
        <div className="flex flex-col items-center gap-3 text-slate-600 dark:text-slate-300">
          <Loader2 className="w-7 h-7 animate-spin text-amber-500" />
          <span className="text-sm font-medium">{t(lang, 'جاري تحميل الاستوديو...', 'Loading Studio...')}</span>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <>
        <AuthView
          lang={lang}
          onToggleLang={() => setLang((l) => (l === 'ar' ? 'en' : 'ar'))}
          darkMode={darkMode}
          onToggleTheme={() => setDarkMode((d) => !d)}
          onAuthenticated={handleAuthenticated}
          onToast={addToast}
        />
        <ToastContainer toasts={toasts} onDismiss={dismissToast} />
      </>
    );
  }

  const currentNavLabel = navItems.find((n) => n.key === section);

  return (
    <div className="min-h-screen flex bg-slate-50 dark:bg-[#0B0F17] text-slate-900 dark:text-slate-100">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-[264px] lg:flex-col lg:fixed lg:inset-y-0 border-e border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827]">
        <div className="h-16 px-5 flex items-center border-b border-slate-200 dark:border-slate-800">
          <BrandMark />
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = SECTION_ICONS[item.key];
            const active = section === item.key;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => setSection(item.key)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-amber-600 text-white'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{lang === 'ar' ? item.ar : item.en}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
          <button
            type="button"
            onClick={() => setSection('settings')}
            className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800/70 transition-colors text-start"
          >
            <ResilientImage
              src={user.avatarUrl || '/src/assets/images/studio_creator_avatar_1795782744107.jpg'}
              alt={user.name}
              className="w-9 h-9 rounded-full object-cover shrink-0"
            />
            <div className="min-w-0 flex-1">
              <p className="text-xs font-bold text-slate-900 dark:text-white truncate">{user.name}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                {user.email || t(lang, 'حساب متصل', 'Connected Account')}
              </p>
            </div>
          </button>
        </div>
      </aside>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/60"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative z-10 w-72 max-w-[85vw] bg-white dark:bg-[#111827] h-full flex flex-col border-e border-slate-200 dark:border-slate-800">
            <div className="h-16 px-5 flex items-center justify-between border-b border-slate-200 dark:border-slate-800">
              <BrandMark />
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
              {navItems.map((item) => {
                const Icon = SECTION_ICONS[item.key];
                const active = section === item.key;
                return (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => {
                      setSection(item.key);
                      setMobileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium min-h-[44px] ${
                      active
                        ? 'bg-amber-600 text-white'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{lang === 'ar' ? item.ar : item.en}</span>
                  </button>
                );
              })}
            </nav>
            <div className="p-4 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={async () => {
                  await api.logout().catch(() => {});
                  handleLoggedOut();
                }}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold"
              >
                <LogOut className="w-4 h-4" />
                <span>{t(lang, 'تسجيل الخروج', 'Sign Out')}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Shell */}
      <div className="flex-1 lg:ps-[264px] flex flex-col min-w-0">
        {/* Top Bar (Clean 3-Zone Contract) */}
        <header className="sticky top-0 z-30 h-16 px-4 sm:px-8 flex items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-[#0B0F17]/90 backdrop-blur">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label={t(lang, 'فتح القائمة', 'Open menu')}
              className="lg:hidden p-2 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 min-w-[40px] min-h-[40px] flex items-center justify-center"
            >
              <Menu className="w-5 h-5" />
            </button>
            <span className="text-sm font-semibold text-slate-900 dark:text-white truncate">
              {currentNavLabel ? (lang === 'ar' ? currentNavLabel.ar : currentNavLabel.en) : 'StoryMaster AI'}
              {activeProject && (section === 'create' || section === 'images' || section === 'voiceover' || section === 'editor')
                ? ` / ${activeProject.title}`
                : ''}
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setLang((l) => (l === 'ar' ? 'en' : 'ar'))}
              className="px-3 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap"
            >
              {lang === 'ar' ? 'EN' : 'AR'}
            </button>
            <button
              type="button"
              onClick={() => setDarkMode((d) => !d)}
              aria-label={t(lang, 'تبديل المظهر', 'Toggle theme')}
              className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={() => setSection('create')}
              className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold whitespace-nowrap"
            >
              <PenTool className="w-3.5 h-3.5" />
              <span>{t(lang, 'قصة جديدة', 'New Story')}</span>
            </button>
          </div>
        </header>

        {/* Viewport Content */}
        <main className="flex-1 p-4 sm:p-8 max-w-[1280px] w-full mx-auto">
          {section === 'home' && (
            <HomeView
              lang={lang}
              user={user}
              projects={projects}
              publishJobs={publishJobs}
              onNavigate={setSection}
              onSelectProject={handleSelectProject}
            />
          )}

          {section === 'create' && (
            <StoryStudioView
              lang={lang}
              activeProject={activeProject}
              scenes={scenes}
              onProjectCreatedOrUpdated={handleProjectCreatedOrUpdated}
              onSceneUpdated={handleSceneUpdated}
              onSceneDeleted={handleSceneDeleted}
              onNavigate={setSection}
            />
          )}

          {section === 'projects' && (
            <ProjectsView
              lang={lang}
              projects={projects}
              activeProjectId={activeProject?.id ?? null}
              onSelectProject={handleSelectProject}
              onProjectDeleted={handleProjectDeleted}
              onNavigate={setSection}
            />
          )}

          {section === 'images' && (
            <ImageStudioView
              lang={lang}
              projects={projects}
              activeProject={activeProject}
              scenes={scenes}
              onSelectProject={(id) => handleSelectProject(id)}
              onSceneUpdated={handleSceneUpdated}
              onNavigate={setSection}
            />
          )}

          {section === 'voiceover' && (
            <VoiceoverStudioView
              lang={lang}
              projects={projects}
              activeProject={activeProject}
              scenes={scenes}
              onSelectProject={(id) => handleSelectProject(id)}
              onSceneUpdated={handleSceneUpdated}
              onNavigate={setSection}
              onToast={addToast}
            />
          )}

          {section === 'editor' && (
            <VideoEditorPublishView
              lang={lang}
              user={user}
              projects={projects}
              activeProject={activeProject}
              scenes={scenes}
              publishJobs={publishJobs}
              onSelectProject={(id) => handleSelectProject(id)}
              onSceneUpdated={handleSceneUpdated}
              onJobCreated={(job) => {
                setPublishJobs((prev) => [job, ...prev]);
                void syncPublishJobToFirestore(job).catch(() => {});
              }}
              onNavigate={setSection}
              onToast={addToast}
            />
          )}

          {section === 'accounts' && (
            <LinkedAccountsView
              lang={lang}
              user={user}
              onUserUpdated={setUser}
              onToast={addToast}
            />
          )}

          {section === 'settings' && (
            <AccountSettingsView
              lang={lang}
              user={user}
              onUserUpdated={(next) => {
                setUser(next);
                setLang(next.preferredLanguage);
                void syncUserProfileToFirestore(next).catch(() => {});
              }}
              onLoggedOut={handleLoggedOut}
            />
          )}
        </main>
      </div>

      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
