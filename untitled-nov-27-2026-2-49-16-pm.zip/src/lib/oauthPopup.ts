import { api } from './api';

export async function startOAuthPopup(
  provider: 'facebook' | 'tiktok',
  mode: 'login' | 'connect',
  extraQuery = ''
): Promise<void> {
  const { url } = await api.getOAuthUrl(provider, mode, extraQuery);
  const width = 600;
  const height = 720;
  const left = Math.max(0, Math.round(window.screenX + (window.outerWidth - width) / 2));
  const top = Math.max(0, Math.round(window.screenY + (window.outerHeight - height) / 2));

  const popup = window.open(
    url,
    `storymaster_${provider}_oauth`,
    `width=${width},height=${height},left=${left},top=${top},scrollbars=yes,resizable=yes`
  );

  if (!popup) {
    throw new Error('POPUP_BLOCKED');
  }
}

export function isAllowedOAuthOrigin(origin: string): boolean {
  if (!origin) return false;
  if (origin === window.location.origin) return true;
  if (origin.endsWith('.run.app')) return true;
  if (origin.includes('localhost') || origin.includes('127.0.0.1')) return true;
  return false;
}
