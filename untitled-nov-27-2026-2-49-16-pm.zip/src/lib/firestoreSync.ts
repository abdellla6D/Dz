import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import type { Project, PublishJob, User } from '../types';

function canSyncToFirestore(): string | null {
  const fbUser = auth.currentUser;
  if (!fbUser || !fbUser.emailVerified) return null;
  if (!/^[a-zA-Z0-9_\-]+$/.test(fbUser.uid)) return null;
  return fbUser.uid;
}

export async function syncUserProfileToFirestore(user: User): Promise<void> {
  const uid = canSyncToFirestore();
  if (!uid) return;

  const path = `users/${uid}/private/profile`;
  const ref = doc(db, 'users', uid, 'private', 'profile');

  try {
    const snap = await getDoc(ref);
    const safeName = (user.name || 'Creator').trim().slice(0, 80) || 'Creator';
    const safeEmail = (user.email || auth.currentUser?.email || '').trim().slice(0, 180);
    const safeBio = (user.bio || '').trim().slice(0, 400);
    const safeLang = user.preferredLanguage === 'en' ? 'en' : 'ar';

    if (snap.exists()) {
      await updateDoc(ref, {
        name: safeName,
        email: safeEmail,
        preferredLanguage: safeLang,
        bio: safeBio,
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(ref, {
        uid,
        name: safeName,
        email: safeEmail,
        preferredLanguage: safeLang,
        bio: safeBio,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function syncProjectToFirestore(project: Project, sceneCount: number): Promise<void> {
  const uid = canSyncToFirestore();
  if (!uid) return;
  if (!/^[a-zA-Z0-9_\-]+$/.test(project.id)) return;

  const path = `projects/${project.id}`;
  const ref = doc(db, 'projects', project.id);

  try {
    const snap = await getDoc(ref);
    const payloadFields = {
      title: (project.title || 'Untitled').trim().slice(0, 160) || 'Untitled',
      topic: (project.topic || '').slice(0, 2000),
      language: project.language === 'en' ? 'en' : 'ar',
      genre: (project.genre || 'cinematic').trim().slice(0, 60) || 'cinematic',
      aspectRatio: project.aspect_ratio,
      storyText: (project.story_text || '').slice(0, 25000),
      status: project.status,
      sceneCount: Math.max(0, Math.min(100, Math.round(sceneCount))),
    };

    if (snap.exists()) {
      if (snap.data().ownerId === uid) {
        await updateDoc(ref, {
          ...payloadFields,
          updatedAt: serverTimestamp(),
        });
      }
    } else {
      await setDoc(ref, {
        id: project.id,
        ownerId: uid,
        ...payloadFields,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteProjectFromFirestore(projectId: string): Promise<void> {
  const uid = canSyncToFirestore();
  if (!uid) return;
  if (!/^[a-zA-Z0-9_\-]+$/.test(projectId)) return;

  const path = `projects/${projectId}`;
  const ref = doc(db, 'projects', projectId);

  try {
    const snap = await getDoc(ref);
    if (snap.exists() && snap.data().ownerId === uid) {
      await deleteDoc(ref);
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function syncPublishJobToFirestore(job: PublishJob): Promise<void> {
  const uid = canSyncToFirestore();
  if (!uid) return;
  if (!/^[a-zA-Z0-9_\-]+$/.test(job.id)) return;

  const path = `publishJobs/${job.id}`;
  const ref = doc(db, 'publishJobs', job.id);

  try {
    const snap = await getDoc(ref);
    if (snap.exists()) return;

    const record: Record<string, unknown> = {
      id: job.id,
      ownerId: uid,
      platform: job.platform,
      title: (job.title || 'Post').trim().slice(0, 200) || 'Post',
      status: job.status,
      createdAt: serverTimestamp(),
    };
    if (job.external_post_id) {
      record.externalPostId = job.external_post_id.slice(0, 200);
    }
    if (job.error_message) {
      record.errorMessage = job.error_message.slice(0, 1000);
    }
    await setDoc(ref, record);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export function subscribeUserProjects(
  uid: string,
  onProjectsCount: (count: number) => void
): () => void {
  const q = query(collection(db, 'projects'), where('ownerId', '==', uid));
  return onSnapshot(
    q,
    (snapshot) => {
      onProjectsCount(snapshot.size);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, 'projects');
    }
  );
}
