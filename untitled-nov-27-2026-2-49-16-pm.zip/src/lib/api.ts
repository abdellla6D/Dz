import type {
  FacebookPage,
  OAuthStatus,
  Project,
  PublishJob,
  Scene,
  User,
} from '../types';

let inMemorySessionToken: string | null = null;

export function setAuthToken(token: string | null): void {
  inMemorySessionToken = token;
}

export function getAuthToken(): string | null {
  return inMemorySessionToken;
}

export class ApiError extends Error {
  status: number;
  code?: string;
  details?: Record<string, unknown>;

  constructor(message: string, status: number, code?: string, details?: Record<string, unknown>) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  if (!headers.has('Content-Type') && init.body && typeof init.body === 'string') {
    headers.set('Content-Type', 'application/json');
  }
  if (inMemorySessionToken) {
    headers.set('Authorization', `Bearer ${inMemorySessionToken}`);
  }

  const res = await fetch(path, {
    ...init,
    headers,
    credentials: 'include',
  });

  const text = await res.text();
  let data: Record<string, unknown> = {};
  try {
    data = text ? (JSON.parse(text) as Record<string, unknown>) : {};
  } catch {
    data = {};
  }

  if (!res.ok) {
    throw new ApiError(
      typeof data.error === 'string' ? data.error : `Request failed (${res.status})`,
      res.status,
      typeof data.code === 'string' ? data.code : undefined,
      data
    );
  }

  return data as T;
}

export const api = {
  // Auth
  me: () => request<{ user: User }>('/api/auth/me'),
  register: (body: { name: string; email: string; password: string; preferredLanguage: 'ar' | 'en' }) =>
    request<{ user: User; sessionToken: string; recoveryKey: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  login: (body: { email: string; password: string }) =>
    request<{ user: User; sessionToken: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  oauthExchange: (exchangeCode: string) =>
    request<{ user: User; sessionToken: string }>('/api/auth/oauth-exchange', {
      method: 'POST',
      body: JSON.stringify({ exchangeCode }),
    }),
  firebaseLogin: (body: { idToken: string; preferredLanguage: 'ar' | 'en' }) =>
    request<{ user: User; sessionToken: string }>('/api/auth/firebase', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  logout: () => request<{ ok: boolean }>('/api/auth/logout', { method: 'POST' }),
  updateProfile: (body: { name?: string; email?: string; bio?: string; preferredLanguage?: 'ar' | 'en' }) =>
    request<{ user: User }>('/api/auth/profile', {
      method: 'PATCH',
      body: JSON.stringify(body),
    }),
  changePassword: (body: { currentPassword?: string; newPassword: string }) =>
    request<{ ok: boolean; user: User }>('/api/auth/change-password', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  regenerateRecoveryKey: () =>
    request<{ recoveryKey: string; user: User }>('/api/auth/regenerate-recovery-key', {
      method: 'POST',
    }),
  forgotPassword: (email: string) =>
    request<{ emailConfigured: boolean; message: string }>('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    }),
  resetPassword: (body: {
    email: string;
    method: 'email_code' | 'recovery_key';
    code: string;
    newPassword: string;
  }) =>
    request<{ ok: boolean; message: string }>('/api/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  deleteAccount: () => request<{ ok: boolean }>('/api/auth/account', { method: 'DELETE' }),

  // OAuth
  oauthStatus: () => request<OAuthStatus>('/api/oauth/status'),
  getOAuthUrl: (provider: 'facebook' | 'tiktok', mode: 'login' | 'connect', extraQuery = '') =>
    request<{ url: string }>(`/api/oauth/${provider}/url?mode=${mode}${extraQuery}`),
  disconnectOAuth: (provider: 'facebook' | 'tiktok') =>
    request<{ user: User }>(`/api/oauth/${provider}`, { method: 'DELETE' }),
  getFacebookPages: () => request<{ pages: FacebookPage[] }>('/api/oauth/facebook/pages'),
  getTikTokCreatorInfo: () => request<{ creatorInfo: Record<string, unknown> }>('/api/oauth/tiktok/creator-info'),

  // Projects & Scenes
  listProjects: () => request<{ projects: Project[] }>('/api/projects'),
  createProject: (body: {
    title: string;
    topic?: string;
    language?: 'ar' | 'en';
    genre?: string;
    aspectRatio?: '9:16' | '16:9' | '1:1';
    storyText?: string;
  }) =>
    request<{ project: Project; scenes: Scene[] }>('/api/projects', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  getProject: (id: string) => request<{ project: Project; scenes: Scene[] }>(`/api/projects/${id}`),
  updateProject: (
    id: string,
    body: Partial<{
      title: string;
      storyText: string;
      aspectRatio: '9:16' | '16:9' | '1:1';
      language: 'ar' | 'en';
      genre: string;
      status: 'draft' | 'ready' | 'published';
      voiceName: 'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr';
      voiceStyle: string;
    }>
  ) =>
    request<{ project: Project }>(`/api/projects/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(body),
    }),
  deleteProject: (id: string) => request<{ ok: boolean }>(`/api/projects/${id}`, { method: 'DELETE' }),
  addScene: (
    projectId: string,
    body: { title: string; narrationText?: string; imagePrompt?: string; durationSec?: number }
  ) =>
    request<{ scene: Scene }>(`/api/projects/${projectId}/scenes`, {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  updateScene: (
    sceneId: string,
    body: Partial<{
      title: string;
      narrationText: string;
      imagePrompt: string;
      imageDataUrl: string | null;
      audioDataUrl: string | null;
      durationSec: number;
      transition: 'fade' | 'zoom' | 'slide' | 'none';
      subtitleEnabled: boolean;
      sceneOrder: number;
    }>
  ) =>
    request<{ scene: Scene }>(`/api/projects/scenes/${sceneId}`, {
      method: 'PATCH',
      body: JSON.stringify(body),
    }),
  deleteScene: (sceneId: string) =>
    request<{ ok: boolean }>(`/api/projects/scenes/${sceneId}`, { method: 'DELETE' }),

  // Gemini AI
  generateStory: (body: {
    topic: string;
    language: 'ar' | 'en';
    genre: string;
    aspectRatio: '9:16' | '16:9' | '1:1';
    sceneCount: number;
    voiceName: 'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr';
  }) =>
    request<{ project: Project; scenes: Scene[] }>('/api/ai/generate-story', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  regenerateScenes: (body: {
    projectId: string;
    storyText: string;
    title?: string;
    sceneCount: number;
    language?: 'ar' | 'en';
  }) =>
    request<{ project: Project; scenes: Scene[] }>('/api/ai/regenerate-scenes', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  refinePrompt: (body: { narrationText: string; styleHint?: string }) =>
    request<{ imagePrompt: string }>('/api/ai/refine-prompt', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  generateImage: (body: {
    prompt: string;
    aspectRatio: '1:1' | '3:4' | '4:3' | '9:16' | '16:9';
    sceneId?: string;
  }) =>
    request<{ imageDataUrl: string }>('/api/ai/generate-image', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  generateVoiceover: (body: {
    text: string;
    voiceName: 'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr';
    style?: string;
    language: 'ar' | 'en';
    sceneId?: string;
  }) =>
    request<{ audioDataUrl: string }>('/api/ai/generate-voiceover', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  generateVideo: (body: {
    prompt: string;
    aspectRatio: '16:9' | '9:16';
    duration: '3s' | '5s' | '8s' | '10s';
  }) =>
    request<{ videoDataUrl: string | null; videoUri: string | null; mimeType: string }>(
      '/api/ai/generate-video',
      {
        method: 'POST',
        body: JSON.stringify(body),
      }
    ),
  transcribeAudio: (body: {
    audioBase64: string;
    mimeType: string;
    language?: 'ar' | 'en';
  }) =>
    request<{ transcript: string }>('/api/ai/transcribe-audio', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  // Publishing
  listPublishJobs: () => request<{ jobs: PublishJob[] }>('/api/publish/jobs'),
  publishFacebook: (body: {
    projectId?: string;
    pageId: string;
    pageName: string;
    title: string;
    description: string;
    mediaType: 'video' | 'photo' | 'text';
    mediaBase64?: string;
    mediaMimeType?: string;
  }) =>
    request<{ job: PublishJob }>('/api/publish/facebook', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  publishTikTok: (body: {
    projectId?: string;
    title: string;
    description?: string;
    privacyLevel: 'PUBLIC_TO_EVERYONE' | 'MUTUAL_FOLLOW_FRIENDS' | 'FOLLOWER_OF_CREATOR' | 'SELF_ONLY';
    disableComment: boolean;
    disableDuet: boolean;
    disableStitch: boolean;
    videoBase64: string;
    videoMimeType: string;
  }) =>
    request<{ job: PublishJob }>('/api/publish/tiktok', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
};
