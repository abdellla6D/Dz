import type { Lang, SectionKey } from './types';

export const navItems: Array<{ key: SectionKey; ar: string; en: string }> = [
  { key: 'home', ar: 'الرئيسية', en: 'Home' },
  { key: 'create', ar: 'إنشاء قصة', en: 'New Story' },
  { key: 'projects', ar: 'مشاريعي', en: 'Projects' },
  { key: 'images', ar: 'توليد الصور', en: 'Images' },
  { key: 'voiceover', ar: 'التعليق الصوتي', en: 'Voiceover' },
  { key: 'editor', ar: 'محرر الفيديو والنشر', en: 'Editor & Publish' },
  { key: 'accounts', ar: 'حساباتي المرتبطة', en: 'Linked Accounts' },
  { key: 'settings', ar: 'إعدادات الحساب', en: 'Account Settings' },
];

export const t = (lang: Lang, ar: string, en: string): string => (lang === 'ar' ? ar : en);

export const VOICE_OPTIONS: Array<{
  id: 'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr';
  ar: string;
  en: string;
}> = [
  { id: 'Kore', ar: 'Kore — راوٍ واضح ودافئ', en: 'Kore — Clear & Warm Narrator' },
  { id: 'Puck', ar: 'Puck — إيقاع حيوي وسريع', en: 'Puck — Energetic & Upbeat' },
  { id: 'Charon', ar: 'Charon — صوت وثائقي عميق', en: 'Charon — Deep Documentary' },
  { id: 'Fenrir', ar: 'Fenrir — نبرة درامية قوية', en: 'Fenrir — Dramatic & Bold' },
  { id: 'Zephyr', ar: 'Zephyr — نبرة هادئة وسلسة', en: 'Zephyr — Calm & Smooth' },
];

export const GENRE_OPTIONS: Array<{ id: string; ar: string; en: string }> = [
  { id: 'cinematic', ar: 'دراما سينمائية', en: 'Cinematic Drama' },
  { id: 'documentary', ar: 'وثائقي معرفي', en: 'Documentary' },
  { id: 'historical', ar: 'تاريخي ملهم', en: 'Historical Epic' },
  { id: 'scifi', ar: 'خيال علمي ومستقبلي', en: 'Sci-Fi & Future' },
  { id: 'mystery', ar: 'غموض وتشويق', en: 'Mystery & Thriller' },
  { id: 'kids', ar: 'قصص تربوية هادفة', en: 'Educational & Family' },
];
