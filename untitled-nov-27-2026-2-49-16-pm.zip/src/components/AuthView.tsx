import { useEffect, useState } from 'react';
import { signInWithPopup } from 'firebase/auth';
import { Check, Copy, Eye, EyeOff, KeyRound, Lock, Mail, Moon, Sun, User as UserIcon } from 'lucide-react';
import { auth, googleProvider } from '../firebase';
import { api, ApiError, setAuthToken } from '../lib/api';
import { syncUserProfileToFirestore } from '../lib/firestoreSync';
import { isAllowedOAuthOrigin, startOAuthPopup } from '../lib/oauthPopup';
import { t } from '../i18n';
import type { Lang, OAuthStatus, ToastMessage, User } from '../types';
import { BrandMark } from './BrandMark';
import { ResilientImage } from './ResilientImage';

interface AuthViewProps {
  lang: Lang;
  onToggleLang: () => void;
  darkMode: boolean;
  onToggleTheme: () => void;
  onAuthenticated: (user: User) => void;
  onToast?: (toast: Omit<ToastMessage, 'id'>) => void;
}

type AuthTab = 'login' | 'register' | 'recover';

export function AuthView({
  lang,
  onToggleLang,
  darkMode,
  onToggleTheme,
  onAuthenticated,
  onToast,
}: AuthViewProps) {
  const [tab, setTab] = useState<AuthTab>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Recovery state
  const [recoverMethod, setRecoverMethod] = useState<'recovery_key' | 'email_code'>('recovery_key');
  const [recoverCode, setRecoverCode] = useState('');
  const [recoverNewPass, setRecoverNewPass] = useState('');
  const [recoverInfo, setRecoverInfo] = useState<string | null>(null);

  // Signup generated recovery key display
  const [createdUser, setCreatedUser] = useState<User | null>(null);
  const [newRecoveryKey, setNewRecoveryKey] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState(false);

  const [loading, setLoading] = useState(false);
  const [oauthLoading, setOauthLoading] = useState<'facebook' | 'tiktok' | 'google' | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [oauthStatus, setOauthStatus] = useState<OAuthStatus | null>(null);

  useEffect(() => {
    api.oauthStatus().then(setOauthStatus).catch(() => {});
  }, []);

  useEffect(() => {
    const onMessage = async (event: MessageEvent) => {
      if (!isAllowedOAuthOrigin(event.origin)) return;
      const data = event.data as
        | { type?: string; provider?: string; exchangeCode?: string; error?: string }
        | undefined;
      if (!data) return;

      if (data.type === 'OAUTH_AUTH_ERROR') {
        setOauthLoading(null);
        const msg = data.error || t(lang, 'فشلت عملية المصادقة عبر المنصة.', 'Platform authentication failed.');
        setError(msg);
        onToast?.({
          type: 'error',
          title: t(lang, 'فشل تسجيل الدخول عبر المنصة', 'OAuth Sign-In Failed'),
          description: msg,
        });
        return;
      }

      if (data.type === 'OAUTH_AUTH_SUCCESS' && data.exchangeCode) {
        try {
          const result = await api.oauthExchange(data.exchangeCode);
          setAuthToken(result.sessionToken);
          onToast?.({
            type: 'success',
            title: t(lang, 'تم تسجيل الدخول بنجاح', 'Signed in successfully'),
            description: result.user.name,
          });
          onAuthenticated(result.user);
        } catch (err) {
          const msg = err instanceof Error ? err.message : t(lang, 'تعذر إكمال تسجيل الدخول.', 'Failed to complete sign-in.');
          setError(msg);
          onToast?.({
            type: 'error',
            title: t(lang, 'تعذر إكمال المصادقة', 'Authentication Error'),
            description: msg,
          });
        } finally {
          setOauthLoading(null);
        }
      }
    };

    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, [lang, onAuthenticated, onToast]);

  const handleOAuth = async (provider: 'facebook' | 'tiktok') => {
    setError(null);
    setOauthLoading(provider);
    try {
      await startOAuthPopup(provider, 'login');
    } catch (err) {
      setOauthLoading(null);
      let msg = t(lang, 'تعذر بدء تسجيل الدخول عبر المنصة.', 'Could not start OAuth login.');
      if (err instanceof Error && err.message === 'POPUP_BLOCKED') {
        msg = t(
          lang,
          'تم حظر النافذة المنبثقة من المتصفح. يرجى السماح بالنوافذ المنبثقة لهذا الموقع والمحاولة مجدداً.',
          'Popup was blocked by your browser. Please allow popups for this site and try again.'
        );
      } else if (err instanceof ApiError) {
        msg = err.message;
      }
      setError(msg);
      onToast?.({
        type: 'error',
        title: `${provider === 'facebook' ? 'Facebook' : 'TikTok'} OAuth`,
        description: msg,
      });
    }
  };

  const handleGoogleFirebaseLogin = async () => {
    setError(null);
    setOauthLoading('google');
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      const idToken = await cred.user.getIdToken();
      const res = await api.firebaseLogin({ idToken, preferredLanguage: lang });
      setAuthToken(res.sessionToken);
      await syncUserProfileToFirestore(res.user).catch(() => {});
      onToast?.({
        type: 'success',
        title: t(lang, 'تم تسجيل الدخول عبر Google', 'Signed in with Google'),
        description: res.user.name,
      });
      onAuthenticated(res.user);
    } catch (err) {
      const msg =
        err instanceof Error
          ? err.message
          : t(lang, 'تعذر تسجيل الدخول عبر Google Firebase.', 'Could not sign in with Google.');
      setError(msg);
    } finally {
      setOauthLoading(null);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await api.login({ email, password });
      setAuthToken(res.sessionToken);
      onAuthenticated(res.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : t(lang, 'فشل تسجيل الدخول.', 'Sign in failed.'));
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await api.register({ name, email, password, preferredLanguage: lang });
      setAuthToken(res.sessionToken);
      setCreatedUser(res.user);
      setNewRecoveryKey(res.recoveryKey);
    } catch (err) {
      setError(err instanceof Error ? err.message : t(lang, 'تعذر إنشاء الحساب.', 'Could not create account.'));
    } finally {
      setLoading(false);
    }
  };

  const handleRequestEmailReset = async () => {
    setError(null);
    setRecoverInfo(null);
    if (!email.trim()) {
      setError(t(lang, 'يرجى إدخال بريدك الإلكتروني أولاً.', 'Please enter your email address first.'));
      return;
    }
    setLoading(true);
    try {
      const res = await api.forgotPassword(email);
      setRecoverInfo(res.message);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to request reset.');
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setRecoverInfo(null);
    setLoading(true);
    try {
      const res = await api.resetPassword({
        email,
        method: recoverMethod,
        code: recoverCode,
        newPassword: recoverNewPass,
      });
      setRecoverInfo(res.message);
      setRecoverCode('');
      setRecoverNewPass('');
      setTab('login');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to reset password.');
    } finally {
      setLoading(false);
    }
  };

  const copyRecoveryKey = async () => {
    if (!newRecoveryKey) return;
    await navigator.clipboard.writeText(newRecoveryKey);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  if (createdUser && newRecoveryKey) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-slate-50 dark:bg-[#0B0F17]">
        <div className="w-full max-w-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] rounded-2xl p-8">
          <BrandMark />
          <h1 className="mt-6 text-2xl font-bold text-slate-900 dark:text-white">
            {t(lang, 'تم إنشاء حسابك بنجاح', 'Your account is ready')}
          </h1>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            {t(
              lang,
              'احتفظ برمز الاسترداد الاحتياطي التالي في مكان آمن. يمكنك استخدامه لاستعادة كلمة المرور في أي وقت حتى دون الحاجة لبريد إلكتروني.',
              'Save this backup recovery key in a secure place. You can use it anytime to recover your password.'
            )}
          </p>

          <div className="mt-5 p-4 rounded-xl border border-amber-500/30 bg-amber-500/10 flex items-center justify-between gap-3">
            <code className="font-mono-nums text-base font-semibold text-amber-700 dark:text-amber-300 select-all">
              {newRecoveryKey}
            </code>
            <button
              type="button"
              onClick={copyRecoveryKey}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium bg-amber-600 text-white hover:bg-amber-500 transition-colors shrink-0"
            >
              {copiedKey ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copiedKey ? t(lang, 'تم النسخ', 'Copied') : t(lang, 'نسخ', 'Copy')}</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => onAuthenticated(createdUser)}
            className="mt-6 w-full py-3 px-4 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-semibold text-sm transition-colors"
          >
            {t(lang, 'الدخول إلى استوديو StoryMaster AI', 'Enter StoryMaster AI Studio')}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-[#0B0F17]">
      {/* Top utility header */}
      <header className="flex items-center justify-between gap-8 px-6 py-4 border-b border-slate-200 dark:border-slate-800/80 bg-white/80 dark:bg-[#0B0F17]/90 backdrop-blur">
        <BrandMark />
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onToggleLang}
            className="px-3 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap"
          >
            {lang === 'ar' ? 'English' : 'العربية'}
          </button>
          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={t(lang, 'تبديل المظهر', 'Toggle theme')}
            className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </header>

      <main className="flex-1 grid grid-cols-1 lg:grid-cols-12 max-w-[1440px] w-full mx-auto">
        {/* Left / Auth Form Column */}
        <section className="lg:col-span-6 flex items-center justify-center p-6 sm:p-10 lg:p-14">
          <div className="w-full max-w-md">
            <div className="mb-7">
              <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight">
                {tab === 'login' && t(lang, 'مرحباً بعودتك إلى الاستوديو', 'Welcome back to the Studio')}
                {tab === 'register' && t(lang, 'إنشاء حساب مستخدم جديد', 'Create your creator account')}
                {tab === 'recover' && t(lang, 'استعادة كلمة المرور', 'Recover your password')}
              </h1>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
                {t(
                  lang,
                  'أنشئ قصصاً مصورة ومقاطع فيديو متكاملة بالذكاء الاصطناعي وانشرها مباشرة عبر فيسبوك وتيك توك.',
                  'Write stories, craft scenes, generate voiceovers, render videos, and publish to Facebook & TikTok.'
                )}
              </p>
            </div>

            {/* Segmented Mode Tabs */}
            <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 mb-6">
              <button
                type="button"
                onClick={() => {
                  setTab('login');
                  setError(null);
                  setRecoverInfo(null);
                }}
                className={`py-2 px-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                  tab === 'login'
                    ? 'bg-white dark:bg-[#111827] text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {t(lang, 'تسجيل الدخول', 'Sign In')}
              </button>
              <button
                type="button"
                onClick={() => {
                  setTab('register');
                  setError(null);
                  setRecoverInfo(null);
                }}
                className={`py-2 px-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                  tab === 'register'
                    ? 'bg-white dark:bg-[#111827] text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {t(lang, 'حساب جديد', 'Create Account')}
              </button>
              <button
                type="button"
                onClick={() => {
                  setTab('recover');
                  setError(null);
                  setRecoverInfo(null);
                }}
                className={`py-2 px-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                  tab === 'recover'
                    ? 'bg-white dark:bg-[#111827] text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {t(lang, 'استعادة المرور', 'Reset Password')}
              </button>
            </div>

            {error && (
              <div
                role="alert"
                className="mb-5 p-3.5 rounded-xl border border-red-500/30 bg-red-500/10 text-red-700 dark:text-red-300 text-xs sm:text-sm leading-relaxed"
              >
                {error}
              </div>
            )}

            {recoverInfo && (
              <div className="mb-5 p-3.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 text-xs sm:text-sm leading-relaxed">
                {recoverInfo}
              </div>
            )}

            {tab !== 'recover' && (
              <>
                {/* Official OAuth & Google Firebase Login Buttons */}
                <div className="space-y-3 mb-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button
                      type="button"
                      disabled={oauthLoading !== null}
                      onClick={() => handleOAuth('facebook')}
                      className="flex items-center justify-center gap-2.5 py-2.5 px-4 rounded-xl bg-[#1877F2] hover:bg-[#166FE5] disabled:opacity-60 text-white text-sm font-semibold transition-colors min-h-[44px]"
                    >
                      <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                      </svg>
                      <span className="whitespace-nowrap">
                        {oauthLoading === 'facebook'
                          ? t(lang, 'جاري الفتح...', 'Opening...')
                          : t(lang, 'دخول عبر Facebook', 'Continue with Facebook')}
                      </span>
                    </button>

                    <button
                      type="button"
                      disabled={oauthLoading !== null}
                      onClick={() => handleOAuth('tiktok')}
                      className="flex items-center justify-center gap-2.5 py-2.5 px-4 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 border border-slate-700 disabled:opacity-60 text-white text-sm font-semibold transition-colors min-h-[44px]"
                    >
                      <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                        <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
                      </svg>
                      <span className="whitespace-nowrap">
                        {oauthLoading === 'tiktok'
                          ? t(lang, 'جاري الفتح...', 'Opening...')
                          : t(lang, 'دخول عبر TikTok', 'Continue with TikTok')}
                      </span>
                    </button>
                  </div>

                  <button
                    type="button"
                    disabled={oauthLoading !== null}
                    onClick={handleGoogleFirebaseLogin}
                    className="w-full flex items-center justify-center gap-2.5 py-2.5 px-4 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] hover:bg-slate-50 dark:hover:bg-slate-800/80 disabled:opacity-60 text-slate-800 dark:text-slate-100 text-sm font-semibold transition-colors min-h-[44px]"
                  >
                    <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                      <path
                        fill="#4285F4"
                        d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 24c3.3 0 6.08-1.09 8.1-2.96l-3.88-3.05c-1.09.73-2.48 1.16-4.22 1.16-3.24 0-5.99-2.19-6.97-5.13H1.04v3.14C3.05 21.14 7.21 24 12 24Z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.03 14.02A7.18 7.18 0 0 1 4.65 12c0-.7.13-1.38.38-2.02V6.84H1.04A11.98 11.98 0 0 0 0 12c0 1.94.46 3.77 1.04 5.16l3.99-3.14Z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 4.85c1.8 0 3.41.62 4.68 1.84l3.51-3.51C18.07 1.19 15.3 0 12 0 7.21 0 3.05 2.86 1.04 6.84l3.99 3.14C6.01 7.04 8.76 4.85 12 4.85Z"
                      />
                    </svg>
                    <span>
                      {oauthLoading === 'google'
                        ? t(lang, 'جاري المصادقة عبر Google...', 'Signing in with Google...')
                        : t(lang, 'تسجيل الدخول عبر Google', 'Continue with Google')}
                    </span>
                  </button>
                </div>

                {oauthStatus && (!oauthStatus.facebook.configured || !oauthStatus.tiktok.configured) && (
                  <p className="mb-5 text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    {t(
                      lang,
                      'ملاحظة: تسجيل الدخول الرسمي عبر Facebook وTikTok يفتح نافذة المنصة الرسمية عبر OAuth عند ضبط مفاتيح التطبيق في إعدادات البيئة.',
                      'Note: Official Facebook & TikTok OAuth opens the provider consent page once app keys are set in environment variables.'
                    )}
                  </p>
                )}

                <div className="relative flex items-center my-5">
                  <div className="flex-grow border-t border-slate-200 dark:border-slate-800" />
                  <span className="mx-3 text-xs text-slate-500 dark:text-slate-400">
                    {t(lang, 'أو عبر البريد الإلكتروني', 'or continue with email')}
                  </span>
                  <div className="flex-grow border-t border-slate-200 dark:border-slate-800" />
                </div>
              </>
            )}

            {tab === 'login' && (
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    {t(lang, 'البريد الإلكتروني', 'Email Address')}
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute top-3.5 start-3.5 pointer-events-none" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      dir="ltr"
                      className="w-full ps-10 pe-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
                      {t(lang, 'كلمة المرور', 'Password')}
                    </label>
                    <button
                      type="button"
                      onClick={() => setTab('recover')}
                      className="text-xs font-medium text-amber-600 dark:text-amber-400 hover:underline"
                    >
                      {t(lang, 'نسيت كلمة المرور؟', 'Forgot password?')}
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute top-3.5 start-3.5 pointer-events-none" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      dir="ltr"
                      className="w-full ps-10 pe-10 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((v) => !v)}
                      className="absolute top-2.5 end-2.5 p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                      aria-label={t(lang, 'إظهار كلمة المرور', 'Toggle password visibility')}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 px-4 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-60 text-white font-semibold text-sm transition-colors min-h-[44px]"
                >
                  {loading ? t(lang, 'جاري تسجيل الدخول...', 'Signing in...') : t(lang, 'تسجيل الدخول', 'Sign In')}
                </button>
              </form>
            )}

            {tab === 'register' && (
              <form onSubmit={handleRegister} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    {t(lang, 'الاسم الكامل', 'Full Name')}
                  </label>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-slate-400 absolute top-3.5 start-3.5 pointer-events-none" />
                    <input
                      type="text"
                      required
                      minLength={2}
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder={t(lang, 'أحمد المنصور', 'Alex Mercer')}
                      className="w-full ps-10 pe-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    {t(lang, 'البريد الإلكتروني', 'Email Address')}
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute top-3.5 start-3.5 pointer-events-none" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      dir="ltr"
                      className="w-full ps-10 pe-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    {t(lang, 'كلمة المرور (8 أحرف على الأقل)', 'Password (min 8 characters)')}
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute top-3.5 start-3.5 pointer-events-none" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      minLength={8}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      dir="ltr"
                      className="w-full ps-10 pe-10 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((v) => !v)}
                      className="absolute top-2.5 end-2.5 p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 px-4 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-60 text-white font-semibold text-sm transition-colors min-h-[44px]"
                >
                  {loading ? t(lang, 'جاري إنشاء الحساب...', 'Creating account...') : t(lang, 'إنشاء الحساب', 'Create Account')}
                </button>
              </form>
            )}

            {tab === 'recover' && (
              <form onSubmit={handleResetPassword} className="space-y-4">
                <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-slate-200/70 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => setRecoverMethod('recovery_key')}
                    className={`py-2 px-3 rounded-lg text-xs font-medium transition-colors ${
                      recoverMethod === 'recovery_key'
                        ? 'bg-white dark:bg-[#111827] text-slate-900 dark:text-white shadow-sm'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {t(lang, 'رمز الاسترداد الاحتياطي', 'Backup Recovery Key')}
                  </button>
                  <button
                    type="button"
                    onClick={() => setRecoverMethod('email_code')}
                    className={`py-2 px-3 rounded-lg text-xs font-medium transition-colors ${
                      recoverMethod === 'email_code'
                        ? 'bg-white dark:bg-[#111827] text-slate-900 dark:text-white shadow-sm'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {t(lang, 'رمز البريد الإلكتروني', 'Email Verification Code')}
                  </button>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    {t(lang, 'البريد الإلكتروني المسجل', 'Registered Email')}
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      dir="ltr"
                      className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                    {recoverMethod === 'email_code' && (
                      <button
                        type="button"
                        onClick={handleRequestEmailReset}
                        disabled={loading}
                        className="px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap"
                      >
                        {t(lang, 'إرسال الرمز', 'Send Code')}
                      </button>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    {recoverMethod === 'recovery_key'
                      ? t(lang, 'رمز الاسترداد (مثال: SM-XXXXXX-...)', 'Backup Recovery Key')
                      : t(lang, 'رمز التحقق المرسل للبريد', '6-Digit Email Code')}
                  </label>
                  <div className="relative">
                    <KeyRound className="w-4 h-4 text-slate-400 absolute top-3.5 start-3.5 pointer-events-none" />
                    <input
                      type="text"
                      required
                      value={recoverCode}
                      onChange={(e) => setRecoverCode(e.target.value)}
                      placeholder={recoverMethod === 'recovery_key' ? 'SM-XXXXXX-XXXXXX-XXXXXX' : '123456'}
                      dir="ltr"
                      className="w-full ps-10 pe-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-slate-900 dark:text-white text-sm font-mono-nums focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    {t(lang, 'كلمة المرور الجديدة', 'New Password')}
                  </label>
                  <input
                    type="password"
                    required
                    minLength={8}
                    value={recoverNewPass}
                    onChange={(e) => setRecoverNewPass(e.target.value)}
                    placeholder="••••••••"
                    dir="ltr"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 px-4 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-60 text-white font-semibold text-sm transition-colors min-h-[44px]"
                >
                  {loading ? t(lang, 'جاري التحديث...', 'Updating...') : t(lang, 'تعيين كلمة المرور الجديدة', 'Reset Password')}
                </button>
              </form>
            )}
          </div>
        </section>

        {/* Right / Editorial Studio Showcase Column */}
        <aside className="hidden lg:flex lg:col-span-6 p-8 items-stretch">
          <div className="relative w-full rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-900">
            <ResilientImage
              src="/src/assets/images/auth_cinema_backdrop_1795782742538.jpg"
              alt="StoryMaster AI Cinematic Production"
              className="w-full h-full object-cover"
              fallbackTitle="StoryMaster AI"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent flex flex-col justify-end p-10">
              <p className="text-xs font-medium text-amber-400 tracking-wide">
                {t(lang, 'استوديو الإنتاج القصصي المتكامل', 'AI STORYTELLING & PUBLISHING STUDIO')}
              </p>
              <h2 className="mt-2 text-3xl font-bold text-white leading-snug max-w-md">
                {t(
                  lang,
                  'من الفكرة الأولى إلى فيديو جاهز للنشر على فيسبوك وتيك توك.',
                  'From raw story idea to edited video ready for Facebook & TikTok.'
                )}
              </h2>
              <div className="mt-5 flex items-center gap-3 text-xs text-slate-300">
                <span>{t(lang, 'كتابة وتقسيم المشاهد', 'Story & Scenes')}</span>
                <span aria-hidden="true">·</span>
                <span>{t(lang, 'صور وتعليق صوتي Gemini', 'Gemini Images & TTS')}</span>
                <span aria-hidden="true">·</span>
                <span>{t(lang, 'نشر رسمي OAuth', 'Official OAuth Publishing')}</span>
              </div>
            </div>
          </div>
        </aside>
      </main>
    </div>
  );
}
