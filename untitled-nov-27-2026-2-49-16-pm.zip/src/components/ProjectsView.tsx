import { useState } from 'react';
import { Film, FolderOpen, Plus, Search, Trash2 } from 'lucide-react';
import { t } from '../i18n';
import { api } from '../lib/api';
import type { Lang, Project, SectionKey } from '../types';
import { ResilientImage } from './ResilientImage';

interface ProjectsViewProps {
  lang: Lang;
  projects: Project[];
  activeProjectId: string | null;
  onSelectProject: (id: string, targetSection: SectionKey) => void;
  onProjectDeleted: (id: string) => void;
  onNavigate: (section: SectionKey) => void;
}

export function ProjectsView({
  lang,
  projects,
  activeProjectId,
  onSelectProject,
  onProjectDeleted,
  onNavigate,
}: ProjectsViewProps) {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'draft' | 'ready' | 'published'>('all');
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const filtered = projects.filter((p) => {
    if (filter !== 'all' && p.status !== filter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return p.title.toLowerCase().includes(q) || p.topic.toLowerCase().includes(q);
    }
    return true;
  });

  const handleDelete = async (id: string) => {
    setError(null);
    setDeletingId(id);
    try {
      await api.deleteProject(id);
      onProjectDeleted(id);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete project');
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {t(lang, 'مشاريعي', 'My Projects')}
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {t(
              lang,
              'جميع القصص والمشاريع المحفوظة في حسابك الخاص ولا يمكن لأي مستخدم آخر الوصول إليها.',
              'All stories and video projects stored privately in your user workspace.'
            )}
          </p>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('create')}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold transition-colors whitespace-nowrap self-start"
        >
          <Plus className="w-4 h-4" />
          <span>{t(lang, 'قصة جديدة', 'New Story')}</span>
        </button>
      </div>

      {error && (
        <div role="alert" className="p-4 rounded-xl border border-red-500/30 bg-red-500/10 text-red-700 dark:text-red-300 text-sm">
          {error}
        </div>
      )}

      {/* Search & Filter Controls */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute top-3 start-3.5 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t(lang, 'ابحث في مشاريعك...', 'Search projects...')}
            className="w-full ps-10 pe-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
        </div>

        <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 self-start">
          {(['all', 'draft', 'ready', 'published'] as const).map((status) => (
            <button
              key={status}
              type="button"
              onClick={() => setFilter(status)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                filter === status
                  ? 'bg-white dark:bg-[#111827] text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {status === 'all' && t(lang, 'الكل', 'All')}
              {status === 'draft' && t(lang, 'مسودة', 'Draft')}
              {status === 'ready' && t(lang, 'جاهز', 'Ready')}
              {status === 'published' && t(lang, 'منشور', 'Published')}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="p-10 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-center">
          <FolderOpen className="w-9 h-9 text-slate-400 mx-auto mb-3" />
          <p className="text-sm font-semibold text-slate-900 dark:text-white">
            {t(lang, 'لا توجد مشاريع مطابقة', 'No matching projects found')}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            {t(lang, 'أنشئ قصة جديدة أو غيّر كلمة البحث.', 'Create a new story or adjust your filter.')}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((p) => {
            const isActive = p.id === activeProjectId;
            return (
              <div
                key={p.id}
                className={`rounded-2xl border overflow-hidden bg-white dark:bg-[#111827] flex flex-col transition-colors ${
                  isActive
                    ? 'border-amber-500'
                    : 'border-slate-200 dark:border-slate-800'
                }`}
              >
                <div className="h-40 bg-slate-900">
                  <ResilientImage
                    src={p.cover_image || '/src/assets/images/scene_sample_oasis_1795782743585.jpg'}
                    alt={p.title}
                    className="w-full h-full object-cover"
                    fallbackTitle={p.title}
                  />
                </div>
                <div className="p-5 flex-1 flex flex-col justify-between gap-4">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white line-clamp-1">{p.title}</h3>
                    <div className="mt-1.5 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span>{p.language === 'ar' ? t(lang, 'عربي', 'Arabic') : 'English'}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-nums">{p.aspect_ratio}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-nums">
                        {p.scene_count ?? 0} {t(lang, 'مشهد', 'scenes')}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {p.status === 'published'
                          ? t(lang, 'منشور', 'Published')
                          : p.status === 'ready'
                          ? t(lang, 'جاهز', 'Ready')
                          : t(lang, 'مسودة', 'Draft')}
                      </span>
                    </div>
                    <p className="mt-2.5 text-xs text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed">
                      {p.story_text || p.topic}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onSelectProject(p.id, 'create')}
                      className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                      {t(lang, 'القصة', 'Story')}
                    </button>
                    <button
                      type="button"
                      onClick={() => onSelectProject(p.id, 'images')}
                      className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                    >
                      {t(lang, 'الصور', 'Images')}
                    </button>
                    <button
                      type="button"
                      onClick={() => onSelectProject(p.id, 'editor')}
                      className="inline-flex items-center gap-1 px-3 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold ms-auto"
                    >
                      <Film className="w-3.5 h-3.5" />
                      <span>{t(lang, 'المحرر', 'Editor')}</span>
                    </button>
                    <button
                      type="button"
                      disabled={deletingId === p.id}
                      onClick={() => handleDelete(p.id)}
                      aria-label={t(lang, 'حذف المشروع', 'Delete project')}
                      className="p-2 rounded-lg text-red-500 hover:bg-red-500/10 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
