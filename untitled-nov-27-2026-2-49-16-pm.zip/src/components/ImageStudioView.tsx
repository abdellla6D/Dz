import { useState } from 'react';
import { Image as ImageIcon, Loader2, Sparkles, Upload, Wand2 } from 'lucide-react';
import { t } from '../i18n';
import { api, ApiError } from '../lib/api';
import type { Lang, Project, Scene, SectionKey } from '../types';
import { ResilientImage } from './ResilientImage';

interface ImageStudioViewProps {
  lang: Lang;
  projects: Project[];
  activeProject: Project | null;
  scenes: Scene[];
  onSelectProject: (id: string) => void;
  onSceneUpdated: (scene: Scene) => void;
  onNavigate: (section: SectionKey) => void;
}

export function ImageStudioView({
  lang,
  projects,
  activeProject,
  scenes,
  onSelectProject,
  onSceneUpdated,
  onNavigate,
}: ImageStudioViewProps) {
  const [selectedSceneId, setSelectedSceneId] = useState<string>('');
  const [customPrompt, setCustomPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<'9:16' | '16:9' | '1:1'>(
    activeProject?.aspect_ratio ?? '9:16'
  );
  const [standaloneImage, setStandaloneImage] = useState<string | null>(null);

  const [generatingId, setGeneratingId] = useState<string | null>(null);
  const [refiningId, setRefiningId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const handleRefinePrompt = async (scene: Scene) => {
    setError(null);
    setRefiningId(scene.id);
    try {
      const res = await api.refinePrompt({
        narrationText: scene.narration_text || scene.title,
      });
      const updated = await api.updateScene(scene.id, { imagePrompt: res.imagePrompt });
      onSceneUpdated(updated.scene);
      setNotice(t(lang, `تم تحسين الوصف البصري للمشهد ${scene.scene_order}`, `Refined prompt for scene ${scene.scene_order}`));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Prompt refinement failed');
    } finally {
      setRefiningId(null);
    }
  };

  const handleGenerateSceneImage = async (scene: Scene) => {
    setError(null);
    setNotice(null);
    setGeneratingId(scene.id);
    try {
      const res = await api.generateImage({
        prompt: scene.image_prompt,
        aspectRatio: activeProject?.aspect_ratio ?? aspectRatio,
        sceneId: scene.id,
      });
      onSceneUpdated({ ...scene, image_data_url: res.imageDataUrl });
      setNotice(t(lang, `تم توليد صورة المشهد ${scene.scene_order}`, `Generated image for scene ${scene.scene_order}`));
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.message);
      } else {
        setError(t(lang, 'تعذر توليد الصورة.', 'Failed to generate image.'));
      }
    } finally {
      setGeneratingId(null);
    }
  };

  const handleStandaloneGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setNotice(null);
    setGeneratingId('standalone');
    try {
      const res = await api.generateImage({
        prompt: customPrompt,
        aspectRatio,
        sceneId: selectedSceneId || undefined,
      });
      setStandaloneImage(res.imageDataUrl);
      if (selectedSceneId) {
        const sc = scenes.find((s) => s.id === selectedSceneId);
        if (sc) onSceneUpdated({ ...sc, image_data_url: res.imageDataUrl, image_prompt: customPrompt });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Image generation failed');
    } finally {
      setGeneratingId(null);
    }
  };

  const handleFileUpload = async (scene: Scene, file: File) => {
    setError(null);
    if (!file.type.startsWith('image/')) {
      setError(t(lang, 'يرجى اختيار ملف صورة صالح.', 'Please select a valid image file.'));
      return;
    }
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = typeof reader.result === 'string' ? reader.result : '';
      if (!dataUrl) return;
      try {
        const res = await api.updateScene(scene.id, { imageDataUrl: dataUrl });
        onSceneUpdated(res.scene);
        setNotice(t(lang, `تم رفع صورة المشهد ${scene.scene_order}`, `Uploaded image for scene ${scene.scene_order}`));
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Upload failed');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleUseStudioArtwork = async (scene: Scene) => {
    setError(null);
    try {
      const samplePath = '/src/assets/images/scene_sample_oasis_1795782743585.jpg';
      const res = await api.updateScene(scene.id, { imageDataUrl: samplePath });
      onSceneUpdated(res.scene);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to apply image');
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {t(lang, 'استوديو توليد صور المشاهد', 'AI Image Generation Studio')}
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {t(
              lang,
              'أنشئ صوراً سينمائية لكل مشهد عبر Gemini أو ارفع صورك الخاصة لاستخدامها في الفيديو.',
              'Generate cinematic visuals per scene with Gemini or upload custom artwork.'
            )}
          </p>
        </div>

        <div className="flex items-center gap-3">
          {projects.length > 0 && (
            <select
              value={activeProject?.id ?? ''}
              onChange={(e) => onSelectProject(e.target.value)}
              className="px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-xs font-medium text-slate-900 dark:text-white"
            >
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.title}
                </option>
              ))}
            </select>
          )}
          <button
            type="button"
            onClick={() => onNavigate('voiceover')}
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold whitespace-nowrap"
          >
            {t(lang, 'التالي: التعليق الصوتي', 'Next: Voiceover')}
          </button>
        </div>
      </div>

      {error && (
        <div role="alert" className="p-4 rounded-xl border border-red-500/30 bg-red-500/10 text-red-700 dark:text-red-300 text-sm leading-relaxed">
          {error}
        </div>
      )}
      {notice && (
        <div className="p-4 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 text-sm">
          {notice}
        </div>
      )}

      {/* Free-form prompt generator */}
      <form
        onSubmit={handleStandaloneGenerate}
        className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-4"
      >
        <h2 className="text-base font-bold text-slate-900 dark:text-white">
          {t(lang, 'توليد صورة حرة عبر وصف مخصص', 'Custom Image Prompt Generator')}
        </h2>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-end">
          <div className="lg:col-span-6">
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
              {t(lang, 'وصف الصورة (يفضل بالإنجليزية)', 'Image Prompt')}
            </label>
            <input
              type="text"
              required
              dir="ltr"
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              placeholder="Cinematic establishing shot of an ancient observatory under starry desert sky..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm text-slate-900 dark:text-white"
            />
          </div>
          <div className="lg:col-span-2">
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
              {t(lang, 'الأبعاد', 'Ratio')}
            </label>
            <select
              value={aspectRatio}
              onChange={(e) => setAspectRatio(e.target.value as '9:16' | '16:9' | '1:1')}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
            >
              <option value="9:16">9:16</option>
              <option value="16:9">16:9</option>
              <option value="1:1">1:1</option>
            </select>
          </div>
          <div className="lg:col-span-2">
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
              {t(lang, 'حفظ في مشهد', 'Assign Scene')}
            </label>
            <select
              value={selectedSceneId}
              onChange={(e) => setSelectedSceneId(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
            >
              <option value="">{t(lang, 'معاينة فقط', 'Preview only')}</option>
              {scenes.map((s) => (
                <option key={s.id} value={s.id}>
                  #{s.scene_order} {s.title}
                </option>
              ))}
            </select>
          </div>
          <div className="lg:col-span-2">
            <button
              type="submit"
              disabled={generatingId === 'standalone'}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-60 text-white text-sm font-semibold"
            >
              {generatingId === 'standalone' ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4" />}
              <span>{t(lang, 'توليد', 'Generate')}</span>
            </button>
          </div>
        </div>

        {standaloneImage && (
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
            <img
              src={standaloneImage}
              alt="Generated preview"
              className="max-h-72 rounded-xl border border-slate-200 dark:border-slate-800 object-contain"
            />
          </div>
        )}
      </form>

      {/* Scene Cards Grid */}
      {!activeProject || scenes.length === 0 ? (
        <div className="p-8 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-center">
          <p className="text-sm font-semibold text-slate-900 dark:text-white">
            {t(lang, 'اختر مشروعاً أو أنشئ قصة جديدة أولاً', 'Select a project or create a story first')}
          </p>
          <button
            type="button"
            onClick={() => onNavigate('create')}
            className="mt-4 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold"
          >
            {t(lang, 'إنشاء قصة جديدة', 'Create Story')}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {scenes.map((sc) => (
            <div
              key={sc.id}
              className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] overflow-hidden flex flex-col"
            >
              <div className="h-56 bg-slate-900 relative">
                <ResilientImage
                  src={sc.image_data_url}
                  alt={sc.title}
                  className="w-full h-full object-cover"
                  fallbackTitle={sc.title}
                />
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between gap-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      <span className="font-mono-nums text-amber-500 me-2">
                        {String(sc.scene_order).padStart(2, '0')}
                      </span>
                      {sc.title}
                    </h3>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2" dir="ltr">
                    {sc.image_prompt}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                  <button
                    type="button"
                    disabled={generatingId === sc.id}
                    onClick={() => handleGenerateSceneImage(sc)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 disabled:opacity-60 text-white text-xs font-semibold"
                  >
                    {generatingId === sc.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Wand2 className="w-3.5 h-3.5" />}
                    <span>{t(lang, 'توليد بـ Gemini', 'Generate AI')}</span>
                  </button>

                  <button
                    type="button"
                    disabled={refiningId === sc.id}
                    onClick={() => handleRefinePrompt(sc)}
                    className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                  >
                    {refiningId === sc.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                    <span>{t(lang, 'تحسين الوصف', 'Refine Prompt')}</span>
                  </button>

                  <label className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    <span>{t(lang, 'رفع صورة', 'Upload')}</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) void handleFileUpload(sc, f);
                      }}
                    />
                  </label>

                  {!sc.image_data_url && (
                    <button
                      type="button"
                      onClick={() => handleUseStudioArtwork(sc)}
                      className="text-xs font-medium text-amber-600 dark:text-amber-400 hover:underline ms-auto"
                    >
                      {t(lang, 'استخدام إطار جاهز', 'Use studio frame')}
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
