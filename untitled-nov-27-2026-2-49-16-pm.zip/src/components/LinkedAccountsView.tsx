import { useEffect, useState } from 'react';
import { Check, Copy, ExternalLink, Link2, RefreshCw, Unlink } from 'lucide-react';
import { t } from '../i18n';
import { api, ApiError } from '../lib/api';
import { isAllowedOAuthOrigin, startOAuthPopup } from '../lib/oauthPopup';
import type { FacebookPage, Lang, OAuthStatus, ToastMessage, User } from '../types';
import { ResilientImage } from './ResilientImage';

interface LinkedAccountsViewProps {
  lang: Lang;
  user: User;
  onUserUpdated: (user: User) => void;
  onToast?: (toast: Omit<ToastMessage, 'id'>) => void;
}

export function LinkedAccountsView({ lang, user, onUserUpdated, onToast }: LinkedAccountsViewProps) {
  const [status, setStatus] = useState<OAuthStatus | null>(null);
  const [fbPages, setFbPages] = useState<FacebookPage[]>([]);
  const [connecting, setConnecting] = useState<'facebook' | 'tiktok' | null>(null);
  const [disconnecting, setDisconnecting] = useState<'facebook' | 'tiktok' | null>(null);
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const fbAccount = user.linkedAccounts.find((a) => a.provider === 'facebook');
  const tkAccount = user.linkedAccounts.find((a) => a.provider === 'tiktok');

  useEffect(() => {
    api.oauthStatus().then(setStatus).catch(() => {});
  }, []);

  useEffect(() => {
    if (fbAccount) {
      const cached = (fbAccount.metadata?.pages as FacebookPage[] | undefined) || [];
      setFbPages(cached);
    } else {
      setFbPages([]);
    }
  }, [fbAccount]);

  useEffect(() => {
    const handler = async (event: MessageEvent) => {
      if (!isAllowedOAuthOrigin(event.origin)) return;
      const data = event.data as
        | { type?: string; provider?: string; exchangeCode?: string; error?: string }
        | undefined;
      if (!data) return;

      if (data.type === 'OAUTH_AUTH_ERROR') {
        setConnecting(null);
        const msg = data.error || t(lang, 'تعذر إكمال الربط.', 'OAuth connection failed.');
        setError(msg);
        onToast?.({
          type: 'error',
          title: t(lang, 'خطأ في ربط المنصة', 'Platform Connection Error'),
          description: msg,
        });
        return;
      }

      if (data.type === 'OAUTH_AUTH_SUCCESS') {
        try {
          if (data.exchangeCode) {
            await api.oauthExchange(data.exchangeCode);
          }
          const me = await api.me();
          onUserUpdated(me.user);
          const successMsg = t(
            lang,
            `تم ربط حساب ${data.provider === 'facebook' ? 'Facebook' : 'TikTok'} بنجاح.`,
            `Connected ${data.provider} account successfully.`
          );
          setNotice(successMsg);
          onToast?.({
            type: 'success',
            title: data.provider === 'facebook' ? 'Facebook OAuth' : 'TikTok OAuth',
            description: successMsg,
          });
        } catch (err) {
          const msg = err instanceof Error ? err.message : 'Failed to refresh profile';
          setError(msg);
          onToast?.({
            type: 'error',
            title: t(lang, 'تعذر تحديث بيانات الربط', 'Connection Sync Failed'),
            description: msg,
          });
        } finally {
          setConnecting(null);
        }
      }
    };

    window.addEventListener('message', handler);
    return () => window.removeEventListener('message', handler);
  }, [lang, onUserUpdated, onToast]);

  const handleConnect = async (provider: 'facebook' | 'tiktok') => {
    setError(null);
    setNotice(null);
    setConnecting(provider);
    try {
      await startOAuthPopup(provider, 'connect');
    } catch (err) {
      setConnecting(null);
      let msg = t(lang, 'فشل بدء الاتصال بالمنصة.', 'Failed to initiate OAuth flow.');
      if (err instanceof Error && err.message === 'POPUP_BLOCKED') {
        msg = t(lang, 'يرجى السماح بالنوافذ المنبثقة لإتمام الربط الرسمي.', 'Please allow popups to complete OAuth connection.');
      } else if (err instanceof ApiError) {
        msg = err.message;
      }
      setError(msg);
      onToast?.({
        type: 'error',
        title: `${provider === 'facebook' ? 'Facebook' : 'TikTok'} API`,
        description: msg,
      });
    }
  };

  const handleDisconnect = async (provider: 'facebook' | 'tiktok') => {
    setError(null);
    setNotice(null);
    setDisconnecting(provider);
    try {
      const res = await api.disconnectOAuth(provider);
      onUserUpdated(res.user);
      const msg = t(
        lang,
        `تم فصل حساب ${provider === 'facebook' ? 'Facebook' : 'TikTok'} بنجاح.`,
        `Disconnected ${provider} account.`
      );
      setNotice(msg);
      onToast?.({
        type: 'info',
        title: `${provider === 'facebook' ? 'Facebook' : 'TikTok'}`,
        description: msg,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Disconnect failed';
      setError(msg);
      onToast?.({
        type: 'error',
        title: `${provider === 'facebook' ? 'Facebook' : 'TikTok'} API`,
        description: msg,
      });
    } finally {
      setDisconnecting(null);
    }
  };

  const handleRefreshPages = async () => {
    setError(null);
    try {
      const res = await api.getFacebookPages();
      setFbPages(res.pages);
      onToast?.({
        type: 'success',
        title: 'Facebook Graph API',
        description: t(lang, `تم جلب ${res.pages.length} صفحة بنجاح.`, `Loaded ${res.pages.length} Facebook pages.`),
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to fetch pages';
      setError(msg);
      onToast?.({
        type: 'error',
        title: 'Facebook Graph API',
        description: msg,
      });
    }
  };

  const copyCallback = async (url: string) => {
    await navigator.clipboard.writeText(url);
    setCopiedUrl(url);
    setTimeout(() => setCopiedUrl(null), 2000);
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
          {t(lang, 'حساباتي المرتبطة (OAuth الرسمي)', 'Linked Accounts (Official OAuth)')}
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
          {t(
            lang,
            'اربط حساباتك الرسمية على Facebook وTikTok عبر أنظمة OAuth المعتمدة بدون إدخال كلمات مرور المنصات داخل التطبيق.',
            'Connect your official Facebook and TikTok accounts securely via provider OAuth without sharing platform passwords.'
          )}
        </p>
      </div>

      {error && (
        <div role="alert" className="p-4 rounded-xl border border-red-500/30 bg-red-500/10 text-red-700 dark:text-red-300 text-sm">
          {error}
        </div>
      )}
      {notice && (
        <div className="p-4 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 text-sm">
          {notice}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Facebook Card */}
        <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-5">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-[#1877F2] text-white flex items-center justify-center shrink-0">
                <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900 dark:text-white">Facebook Login & Pages API</h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {fbAccount
                    ? t(lang, 'الحساب مرتبط ونشط', 'Connected')
                    : status?.facebook.configured
                    ? t(lang, 'جاهز للربط عبر Facebook OAuth', 'Ready to connect')
                    : t(lang, 'يتطلب إعداد مفاتيح Meta Developer في البيئة', 'Requires Meta Developer env keys')}
                </p>
              </div>
            </div>
          </div>

          {fbAccount ? (
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#0B0F17] space-y-3">
              <div className="flex items-center gap-3">
                <ResilientImage
                  src={fbAccount.avatarUrl}
                  alt={fbAccount.displayName || 'Facebook'}
                  className="w-11 h-11 rounded-full object-cover shrink-0"
                />
                <div className="min-w-0">
                  <p className="text-sm font-bold text-slate-900 dark:text-white truncate">{fbAccount.displayName}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {fbAccount.email || `ID: ${fbAccount.providerUserId}`}
                  </p>
                </div>
              </div>

              <div className="text-xs text-slate-500 dark:text-slate-400">
                {t(lang, 'الصلاحيات:', 'Scopes:')}{' '}
                <span className="font-mono-nums">{fbAccount.scopes.join(', ') || 'public_profile'}</span>
              </div>

              <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    {t(lang, `صفحات فيسبوك المتاحة (${fbPages.length})`, `Managed Pages (${fbPages.length})`)}
                  </span>
                  <button
                    type="button"
                    onClick={handleRefreshPages}
                    className="inline-flex items-center gap-1 text-xs text-amber-600 dark:text-amber-400 hover:underline"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>{t(lang, 'تحديث', 'Refresh')}</span>
                  </button>
                </div>
                {fbPages.length > 0 && (
                  <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-400">
                    {fbPages.map((pg) => (
                      <li key={pg.id} className="flex items-center justify-between">
                        <span>{pg.name}</span>
                        <span className="font-mono-nums opacity-70">{pg.id}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          ) : null}

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              disabled={connecting === 'facebook'}
              onClick={() => handleConnect('facebook')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#1877F2] hover:bg-[#166FE5] disabled:opacity-60 text-white text-xs font-semibold"
            >
              <Link2 className="w-4 h-4" />
              <span>
                {fbAccount
                  ? t(lang, 'تحديث الصلاحيات / إعادة الربط', 'Reconnect / Refresh Scopes')
                  : t(lang, 'ربط حساب Facebook الرسمي', 'Connect Official Facebook')}
              </span>
            </button>

            {fbAccount && (
              <button
                type="button"
                disabled={disconnecting === 'facebook'}
                onClick={() => handleDisconnect('facebook')}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-red-500/30 text-red-600 dark:text-red-400 hover:bg-red-500/10 text-xs font-semibold"
              >
                <Unlink className="w-4 h-4" />
                <span>{t(lang, 'فصل الحساب', 'Disconnect')}</span>
              </button>
            )}
          </div>

          {status && (
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
              <p className="text-xs font-medium text-slate-600 dark:text-slate-400">
                {t(lang, 'رابط Callback المسجل في Meta:', 'Meta OAuth Redirect URI:')}
              </p>
              <div className="flex items-center gap-2">
                <code className="flex-1 text-xs font-mono-nums px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-[#0B0F17] text-slate-700 dark:text-slate-300 truncate" dir="ltr">
                  {status.facebook.callbackUrl}
                </code>
                <button
                  type="button"
                  onClick={() => copyCallback(status.facebook.callbackUrl)}
                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300"
                >
                  {copiedUrl === status.facebook.callbackUrl ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* TikTok Card */}
        <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-5">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-slate-900 dark:bg-slate-800 border border-slate-700 text-white flex items-center justify-center shrink-0">
                <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
                </svg>
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900 dark:text-white">TikTok Login Kit & Content API</h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {tkAccount
                    ? t(lang, 'الحساب مرتبط ونشط', 'Connected')
                    : status?.tiktok.configured
                    ? t(lang, 'جاهز للربط عبر TikTok OAuth v2', 'Ready to connect')
                    : t(lang, 'يتطلب إعداد مفاتيح TikTok Developer في البيئة', 'Requires TikTok Developer env keys')}
                </p>
              </div>
            </div>
          </div>

          {tkAccount ? (
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#0B0F17] space-y-3">
              <div className="flex items-center gap-3">
                <ResilientImage
                  src={tkAccount.avatarUrl}
                  alt={tkAccount.displayName || 'TikTok'}
                  className="w-11 h-11 rounded-full object-cover shrink-0"
                />
                <div className="min-w-0">
                  <p className="text-sm font-bold text-slate-900 dark:text-white truncate">{tkAccount.displayName}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {tkAccount.username ? `@${tkAccount.username}` : tkAccount.providerUserId}
                  </p>
                </div>
              </div>

              <div className="text-xs text-slate-500 dark:text-slate-400">
                {t(lang, 'الصلاحيات:', 'Scopes:')}{' '}
                <span className="font-mono-nums">{tkAccount.scopes.join(', ') || 'user.info.basic'}</span>
              </div>
            </div>
          ) : null}

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              disabled={connecting === 'tiktok'}
              onClick={() => handleConnect('tiktok')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 border border-slate-700 disabled:opacity-60 text-white text-xs font-semibold"
            >
              <ExternalLink className="w-4 h-4" />
              <span>
                {tkAccount
                  ? t(lang, 'تحديث الصلاحيات / إعادة الربط', 'Reconnect / Refresh Scopes')
                  : t(lang, 'ربط حساب TikTok الرسمي', 'Connect Official TikTok')}
              </span>
            </button>

            {tkAccount && (
              <button
                type="button"
                disabled={disconnecting === 'tiktok'}
                onClick={() => handleDisconnect('tiktok')}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-red-500/30 text-red-600 dark:text-red-400 hover:bg-red-500/10 text-xs font-semibold"
              >
                <Unlink className="w-4 h-4" />
                <span>{t(lang, 'فصل الحساب', 'Disconnect')}</span>
              </button>
            )}
          </div>

          {status && (
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
              <p className="text-xs font-medium text-slate-600 dark:text-slate-400">
                {t(lang, 'رابط Redirect URI المسجل في TikTok:', 'TikTok OAuth Redirect URI:')}
              </p>
              <div className="flex items-center gap-2">
                <code className="flex-1 text-xs font-mono-nums px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-[#0B0F17] text-slate-700 dark:text-slate-300 truncate" dir="ltr">
                  {status.tiktok.callbackUrl}
                </code>
                <button
                  type="button"
                  onClick={() => copyCallback(status.tiktok.callbackUrl)}
                  className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300"
                >
                  {copiedUrl === status.tiktok.callbackUrl ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
