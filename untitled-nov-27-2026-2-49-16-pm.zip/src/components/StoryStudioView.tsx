import { useEffect, useState } from 'react';
import { Loader2, Plus, RefreshCw, Save, Trash2, Wand2 } from 'lucide-react';
import { GENRE_OPTIONS, VOICE_OPTIONS, t } from '../i18n';
import { api } from '../lib/api';
import type { Lang, Project, Scene, SectionKey } from '../types';

interface StoryStudioViewProps {
  lang: Lang;
  activeProject: Project | null;
  scenes: Scene[];
  onProjectCreatedOrUpdated: (project: Project, scenes: Scene[]) => void;
  onSceneUpdated: (scene: Scene) => void;
  onSceneDeleted: (sceneId: string) => void;
  onNavigate: (section: SectionKey) => void;
}

export function StoryStudioView({
  lang,
  activeProject,
  scenes,
  onProjectCreatedOrUpdated,
  onSceneUpdated,
  onSceneDeleted,
  onNavigate,
}: StoryStudioViewProps) {
  const [topic, setTopic] = useState('');
  const [storyLang, setStoryLang] = useState<Lang>(lang);
  const [genre, setGenre] = useState('cinematic');
  const [aspectRatio, setAspectRatio] = useState<'9:16' | '16:9' | '1:1'>('9:16');
  const [sceneCount, setSceneCount] = useState(5);
  const [voiceName, setVoiceName] = useState<'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr'>('Kore');

  const [editTitle, setEditTitle] = useState('');
  const [editStory, setEditStory] = useState('');
  const [regenCount, setRegenCount] = useState(5);

  const [generating, setGenerating] = useState(false);
  const [regenerating, setRegenerating] = useState(false);
  const [savingStory, setSavingStory] = useState(false);
  const [savingSceneId, setSavingSceneId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [localScenes, setLocalScenes] = useState<Scene[]>(scenes);

  useEffect(() => {
    setLocalScenes(scenes);
  }, [scenes]);

  useEffect(() => {
    if (activeProject) {
      setEditTitle(activeProject.title);
      setEditStory(activeProject.story_text);
      setRegenCount(Math.max(3, Math.min(12, scenes.length || 5)));
    }
  }, [activeProject, scenes.length]);

  const handleGenerateStory = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setNotice(null);
    setGenerating(true);
    try {
      const res = await api.generateStory({
        topic,
        language: storyLang,
        genre,
        aspectRatio,
        sceneCount,
        voiceName,
      });
      onProjectCreatedOrUpdated(res.project, res.scenes);
      setNotice(
        t(
          lang,
          'تم تأليف القصة وتقسيمها إلى مشاهد وحفظها في مشاريعك.',
          'Story generated, split into scenes, and saved to your projects.'
        )
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : t(lang, 'تعذر توليد القصة.', 'Failed to generate story.'));
    } finally {
      setGenerating(false);
    }
  };

  const handleSaveStoryOnly = async () => {
    if (!activeProject) return;
    setError(null);
    setNotice(null);
    setSavingStory(true);
    try {
      const res = await api.updateProject(activeProject.id, {
        title: editTitle,
        storyText: editStory,
      });
      onProjectCreatedOrUpdated(res.project, localScenes);
      setNotice(t(lang, 'تم حفظ تعديلات القصة.', 'Story changes saved.'));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Save failed');
    } finally {
      setSavingStory(false);
    }
  };

  const handleRegenerateScenes = async () => {
    if (!activeProject) return;
    setError(null);
    setNotice(null);
    setRegenerating(true);
    try {
      const res = await api.regenerateScenes({
        projectId: activeProject.id,
        title: editTitle,
        storyText: editStory,
        sceneCount: regenCount,
        language: activeProject.language,
      });
      onProjectCreatedOrUpdated(res.project, res.scenes);
      setNotice(t(lang, 'تمت إعادة تقسيم القصة إلى مشاهد جديدة.', 'Scenes regenerated from edited story.'));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Regeneration failed');
    } finally {
      setRegenerating(false);
    }
  };

  const handleSceneFieldChange = (id: string, field: keyof Scene, value: string | number) => {
    setLocalScenes((prev) => prev.map((s) => (s.id === id ? { ...s, [field]: value } : s)));
  };

  const handleSaveScene = async (sc: Scene) => {
    setSavingSceneId(sc.id);
    setError(null);
    try {
      const res = await api.updateScene(sc.id, {
        title: sc.title,
        narrationText: sc.narration_text,
        imagePrompt: sc.image_prompt,
        durationSec: Number(sc.duration_sec) || 6,
      });
      onSceneUpdated(res.scene);
      setNotice(t(lang, `تم حفظ المشهد ${sc.scene_order}`, `Saved scene ${sc.scene_order}`));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Scene update failed');
    } finally {
      setSavingSceneId(null);
    }
  };

  const handleAddScene = async () => {
    if (!activeProject) return;
    setError(null);
    try {
      const res = await api.addScene(activeProject.id, {
        title: t(lang, `مشهد جديد ${localScenes.length + 1}`, `New Scene ${localScenes.length + 1}`),
        narrationText: '',
        imagePrompt: 'Cinematic wide establishing shot, warm dramatic lighting, 8k film still',
        durationSec: 6,
      });
      onProjectCreatedOrUpdated(activeProject, [...localScenes, res.scene]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to add scene');
    }
  };

  const handleDeleteScene = async (sceneId: string) => {
    setError(null);
    try {
      await api.deleteScene(sceneId);
      onSceneDeleted(sceneId);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete scene');
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {t(lang, 'استوديو كتابة القصص والمشاهد', 'Story & Scene Studio')}
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {t(
              lang,
              'أنشئ قصصاً طويلة بالعربية أو الإنجليزية عبر Google Gemini وقسّمها إلى مشاهد جاهزة للإنتاج.',
              'Generate long-form stories in Arabic or English via Google Gemini and split them into production scenes.'
            )}
          </p>
        </div>
        {activeProject && (
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => onNavigate('images')}
              className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors whitespace-nowrap"
            >
              {t(lang, 'الانتقال لتوليد الصور', 'Next: Images')}
            </button>
            <button
              type="button"
              onClick={() => onNavigate('voiceover')}
              className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold transition-colors whitespace-nowrap"
            >
              {t(lang, 'التعليق الصوتي', 'Voiceover')}
            </button>
          </div>
        )}
      </div>

      {error && (
        <div role="alert" className="p-4 rounded-xl border border-red-500/30 bg-red-500/10 text-red-700 dark:text-red-300 text-sm">
          {error}
        </div>
      )}
      {notice && (
        <div className="p-4 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 text-sm">
          {notice}
        </div>
      )}

      {/* New Story Generator Form */}
      <form
        onSubmit={handleGenerateStory}
        className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-5"
      >
        <h2 className="text-base font-bold text-slate-900 dark:text-white">
          {t(lang, 'إنشاء قصة جديدة بالذكاء الاصطناعي', 'Create a New AI Story')}
        </h2>

        <div>
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-2">
            {t(lang, 'فكرة القصة أو موضوع الفيديو', 'Story Idea or Topic')}
          </label>
          <textarea
            required
            rows={3}
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder={t(
              lang,
              'مثال: رحلة ملاح أندلسي شاب يكتشف مكتبة مفقودة تحت رمال الصحراء وتكشف له سر النجوم...',
              'Example: A young astronomer uncovers an ancient desert observatory holding forgotten star maps...'
            )}
            className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t(lang, 'لغة القصة', 'Language')}
            </label>
            <select
              value={storyLang}
              onChange={(e) => setStoryLang(e.target.value as Lang)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-slate-900 dark:text-white text-sm"
            >
              <option value="ar">العربية (Arabic)</option>
              <option value="en">English</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t(lang, 'النوع والأسلوب', 'Genre')}
            </label>
            <select
              value={genre}
              onChange={(e) => setGenre(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-slate-900 dark:text-white text-sm"
            >
              {GENRE_OPTIONS.map((g) => (
                <option key={g.id} value={g.id}>
                  {lang === 'ar' ? g.ar : g.en}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t(lang, 'أبعاد الفيديو', 'Aspect Ratio')}
            </label>
            <select
              value={aspectRatio}
              onChange={(e) => setAspectRatio(e.target.value as '9:16' | '16:9' | '1:1')}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-slate-900 dark:text-white text-sm"
            >
              <option value="9:16">9:16 (TikTok / Reels)</option>
              <option value="16:9">16:9 (YouTube / Facebook)</option>
              <option value="1:1">1:1 (Square Post)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t(lang, 'عدد المشاهد', 'Scene Count')}
            </label>
            <input
              type="number"
              min={3}
              max={12}
              value={sceneCount}
              onChange={(e) => setSceneCount(Number(e.target.value))}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-slate-900 dark:text-white text-sm font-mono-nums"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t(lang, 'صوت الراوي', 'Narrator Voice')}
            </label>
            <select
              value={voiceName}
              onChange={(e) => setVoiceName(e.target.value as typeof voiceName)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-slate-900 dark:text-white text-sm"
            >
              {VOICE_OPTIONS.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.id}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={generating}
            className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-60 text-white text-sm font-semibold transition-colors"
          >
            {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
            <span>
              {generating
                ? t(lang, 'جاري كتابة القصة وتقسيم المشاهد...', 'Writing story & scenes...')
                : t(lang, 'تأليف القصة وتوليد المشاهد', 'Generate Story & Scenes')}
            </span>
          </button>
        </div>
      </form>

      {/* Active Project Story Editor & Scenes */}
      {activeProject && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {t(lang, 'نص القصة الكامل وإعادة توليد المشاهد', 'Full Story & Scene Re-splitting')}
              </h2>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleSaveStoryOnly}
                  disabled={savingStory}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  {savingStory ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                  <span>{t(lang, 'حفظ التعديلات', 'Save Story')}</span>
                </button>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min={3}
                    max={12}
                    value={regenCount}
                    onChange={(e) => setRegenCount(Number(e.target.value))}
                    aria-label={t(lang, 'عدد المشاهد عند إعادة التوليد', 'Scene count for regeneration')}
                    className="w-16 px-2.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-xs font-mono-nums text-center"
                  />
                  <button
                    type="button"
                    onClick={handleRegenerateScenes}
                    disabled={regenerating}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-60 text-white text-xs font-semibold transition-colors whitespace-nowrap"
                  >
                    {regenerating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                    <span>{t(lang, 'إعادة توليد المشاهد من النص', 'Regenerate Scenes')}</span>
                  </button>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                {t(lang, 'عنوان القصة', 'Story Title')}
              </label>
              <input
                type="text"
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-slate-900 dark:text-white text-sm font-semibold"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                {t(lang, 'نص القصة (يمكنك تعديله بحرية ثم إعادة تقسيم المشاهد)', 'Full Narrative Prose')}
              </label>
              <textarea
                rows={7}
                value={editStory}
                onChange={(e) => setEditStory(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-slate-900 dark:text-white text-sm leading-relaxed"
              />
            </div>
          </div>

          {/* Scenes List */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {t(lang, `المشاهد (${localScenes.length})`, `Scenes (${localScenes.length})`)}
              </h2>
              <button
                type="button"
                onClick={handleAddScene}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{t(lang, 'إضافة مشهد', 'Add Scene')}</span>
              </button>
            </div>

            <div className="space-y-4">
              {localScenes.map((sc) => (
                <div
                  key={sc.id}
                  className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-4"
                >
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3 flex-1 min-w-[200px]">
                      <span className="font-mono-nums text-xs font-bold text-amber-600 dark:text-amber-400">
                        {String(sc.scene_order).padStart(2, '0')}
                      </span>
                      <input
                        type="text"
                        value={sc.title}
                        onChange={(e) => handleSceneFieldChange(sc.id, 'title', e.target.value)}
                        className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm font-semibold text-slate-900 dark:text-white"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <label className="text-xs text-slate-500 dark:text-slate-400">
                        {t(lang, 'المدة (ث)', 'Sec')}
                      </label>
                      <input
                        type="number"
                        min={2}
                        max={60}
                        value={sc.duration_sec}
                        onChange={(e) => handleSceneFieldChange(sc.id, 'duration_sec', Number(e.target.value))}
                        className="w-16 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-xs font-mono-nums text-center"
                      />
                      <button
                        type="button"
                        onClick={() => handleSaveScene(sc)}
                        disabled={savingSceneId === sc.id}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white text-xs font-medium"
                      >
                        {savingSceneId === sc.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                        <span>{t(lang, 'حفظ', 'Save')}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteScene(sc.id)}
                        aria-label={t(lang, 'حذف المشهد', 'Delete scene')}
                        className="p-1.5 rounded-lg text-red-500 hover:bg-red-500/10 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                        {t(lang, 'نص التعليق الصوتي والترجمة', 'Narration & Subtitle Text')}
                      </label>
                      <textarea
                        rows={3}
                        value={sc.narration_text}
                        onChange={(e) => handleSceneFieldChange(sc.id, 'narration_text', e.target.value)}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-xs sm:text-sm text-slate-900 dark:text-white leading-relaxed"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                        {t(lang, 'وصف الصورة البصري (English Prompt)', 'Image Generation Prompt')}
                      </label>
                      <textarea
                        rows={3}
                        dir="ltr"
                        value={sc.image_prompt}
                        onChange={(e) => handleSceneFieldChange(sc.id, 'image_prompt', e.target.value)}
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-xs sm:text-sm text-slate-900 dark:text-white leading-relaxed"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
