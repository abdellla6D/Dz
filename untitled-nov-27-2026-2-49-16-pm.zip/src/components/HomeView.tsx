import { ArrowLeft, ArrowRight, Film, FolderOpen, Image as ImageIcon, Link2, Mic, PenTool } from 'lucide-react';
import { t } from '../i18n';
import type { Lang, Project, PublishJob, SectionKey, User } from '../types';
import { ResilientImage } from './ResilientImage';

interface HomeViewProps {
  lang: Lang;
  user: User;
  projects: Project[];
  publishJobs: PublishJob[];
  onNavigate: (section: SectionKey) => void;
  onSelectProject: (projectId: string, section?: SectionKey) => void;
}

export function HomeView({
  lang,
  user,
  projects,
  publishJobs,
  onNavigate,
  onSelectProject,
}: HomeViewProps) {
  const ArrowIcon = lang === 'ar' ? ArrowLeft : ArrowRight;
  const fbLinked = user.linkedAccounts.find((a) => a.provider === 'facebook');
  const tkLinked = user.linkedAccounts.find((a) => a.provider === 'tiktok');
  const publishedCount = publishJobs.filter((j) => j.status === 'published').length;

  return (
    <div className="space-y-8">
      {/* Studio Hero Banner */}
      <section className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-900 min-h-[260px] flex items-end">
        <ResilientImage
          src="/src/assets/images/hero_storymaster_studio_1795782742479.jpg"
          alt="StoryMaster AI Production Desk"
          className="absolute inset-0 w-full h-full object-cover"
          fallbackTitle="StoryMaster AI Studio"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0F17] via-[#0B0F17]/75 to-[#0B0F17]/20" />
        <div className="relative z-10 w-full p-6 sm:p-8 flex flex-col lg:flex-row lg:items-end justify-between gap-6">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-amber-400">
              {t(lang, `أهلاً بك، ${user.name}`, `Welcome back, ${user.name}`)}
            </p>
            <h1 className="mt-2 text-2xl sm:text-3xl font-bold text-white leading-tight">
              {t(
                lang,
                'اصنع قصصك بالذكاء الاصطناعي وانشرها كفيديوهات احترافية',
                'Craft AI-powered stories and publish studio-ready videos'
              )}
            </h1>
            <p className="mt-2 text-sm text-slate-300 leading-relaxed">
              {t(
                lang,
                'اكتب القصة، قسّمها إلى مشاهد، أنشئ الصور والتعليق الصوتي عبر Google Gemini، ثم صدّر الفيديو وانشره على صفحاتك.',
                'Write long narratives, split scenes, generate visuals & voiceovers with Google Gemini, edit on the timeline, and publish.'
              )}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => onNavigate('create')}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-sm font-semibold transition-colors whitespace-nowrap"
            >
              <PenTool className="w-4 h-4" />
              <span>{t(lang, 'إنشاء قصة جديدة', 'Create New Story')}</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('accounts')}
              className="inline-flex items-center gap-2 px-4 py-3 rounded-xl border border-slate-600 bg-slate-900/70 hover:bg-slate-800 text-slate-100 text-sm font-medium transition-colors whitespace-nowrap"
            >
              <Link2 className="w-4 h-4" />
              <span>{t(lang, 'حساباتي المرتبطة', 'Linked Accounts')}</span>
            </button>
          </div>
        </div>
      </section>

      {/* Studio Metrics Strip (Tabular Numerals) */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827]">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {t(lang, 'مشاريعك المحفوظة', 'Saved Projects')}
          </p>
          <p className="mt-2 text-2xl font-bold font-mono-nums text-slate-900 dark:text-white">
            {projects.length}
          </p>
        </div>

        <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827]">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {t(lang, 'عمليات النشر المكتملة', 'Published Videos')}
          </p>
          <p className="mt-2 text-2xl font-bold font-mono-nums text-slate-900 dark:text-white">
            {publishedCount}
          </p>
        </div>

        <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827]">
          <p className="text-xs text-slate-500 dark:text-slate-400">Facebook</p>
          <p className="mt-2 text-sm font-semibold text-slate-900 dark:text-white truncate">
            {fbLinked ? fbLinked.displayName || t(lang, 'متصل', 'Connected') : t(lang, 'غير مرتبط', 'Not connected')}
          </p>
        </div>

        <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827]">
          <p className="text-xs text-slate-500 dark:text-slate-400">TikTok</p>
          <p className="mt-2 text-sm font-semibold text-slate-900 dark:text-white truncate">
            {tkLinked ? tkLinked.displayName || tkLinked.username || t(lang, 'متصل', 'Connected') : t(lang, 'غير مرتبط', 'Not connected')}
          </p>
        </div>
      </section>

      {/* Studio Pipeline Tools */}
      <section>
        <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4">
          {t(lang, 'أدوات الإنتاج والنشر', 'Production Pipeline')}
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              key: 'create' as SectionKey,
              icon: PenTool,
              title: t(lang, '01. كتابة وتقسيم القصة', '01. Story & Scenes'),
              desc: t(lang, 'تأليف القصص الطويلة وتقسيمها تلقائياً إلى مشاهد.', 'Write long narratives and auto-split into scenes.'),
            },
            {
              key: 'images' as SectionKey,
              icon: ImageIcon,
              title: t(lang, '02. توليد مشاهد الصور', '02. Scene Visuals'),
              desc: t(lang, 'توليد صور المشاهد عبر Gemini أو رفع صورك.', 'Generate scene art with Gemini or upload your own.'),
            },
            {
              key: 'voiceover' as SectionKey,
              icon: Mic,
              title: t(lang, '03. التعليق الصوتي', '03. Voiceover Studio'),
              desc: t(lang, 'توليد تعليق صوتي واقعي بالعربية والإنجليزية.', 'Generate Arabic & English WAV narration via Gemini TTS.'),
            },
            {
              key: 'editor' as SectionKey,
              icon: Film,
              title: t(lang, '04. محرر الفيديو والنشر', '04. Video & Publish'),
              desc: t(lang, 'دمج المشاهد والصوت وتصدير الفيديو ونشره.', 'Assemble timeline, export video, and publish live.'),
            },
          ].map((tool) => {
            const Icon = tool.icon;
            return (
              <button
                key={tool.key}
                type="button"
                onClick={() => onNavigate(tool.key)}
                className="text-start p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] hover:border-amber-500/60 transition-colors flex flex-col justify-between gap-4"
              >
                <div>
                  <Icon className="w-5 h-5 text-amber-500 mb-3" />
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">{tool.title}</h3>
                  <p className="mt-1.5 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">{tool.desc}</p>
                </div>
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-600 dark:text-amber-400">
                  <span>{t(lang, 'فتح الأداة', 'Open tool')}</span>
                  <ArrowIcon className="w-3.5 h-3.5" />
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* Recent Projects */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            {t(lang, 'أحدث مشاريعك', 'Recent Projects')}
          </h2>
          <button
            type="button"
            onClick={() => onNavigate('projects')}
            className="text-xs font-semibold text-amber-600 dark:text-amber-400 hover:underline"
          >
            {t(lang, 'عرض الكل', 'View all')}
          </button>
        </div>

        {projects.length === 0 ? (
          <div className="p-8 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-center">
            <FolderOpen className="w-8 h-8 text-slate-400 mx-auto mb-3" />
            <p className="text-sm font-semibold text-slate-900 dark:text-white">
              {t(lang, 'لا توجد مشاريع بعد', 'No projects yet')}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              {t(
                lang,
                'ابدأ بإنشاء قصتك الأولى بالذكاء الاصطناعي وسيتم حفظ جميع مشاهدها في حسابك الخاص.',
                'Start by creating your first AI story; all scenes and media will be saved privately to your account.'
              )}
            </p>
            <button
              type="button"
              onClick={() => onNavigate('create')}
              className="mt-4 inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold transition-colors"
            >
              {t(lang, 'ابدأ قصة جديدة', 'Start New Story')}
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {projects.slice(0, 6).map((p) => (
              <div
                key={p.id}
                className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] overflow-hidden flex flex-col"
              >
                <div className="h-36 bg-slate-900 relative">
                  <ResilientImage
                    src={p.cover_image || '/src/assets/images/scene_sample_oasis_1795782743585.jpg'}
                    alt={p.title}
                    className="w-full h-full object-cover"
                    fallbackTitle={p.title}
                  />
                </div>
                <div className="p-4 flex-1 flex flex-col justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white line-clamp-1">{p.title}</h3>
                    <div className="mt-1 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span>{p.language === 'ar' ? t(lang, 'عربي', 'Arabic') : 'English'}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-nums">{p.aspect_ratio}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-nums">
                        {p.scene_count ?? 0} {t(lang, 'مشهد', 'scenes')}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <button
                      type="button"
                      onClick={() => onSelectProject(p.id, 'create')}
                      className="flex-1 py-2 px-3 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                    >
                      {t(lang, 'تعديل القصة', 'Edit Story')}
                    </button>
                    <button
                      type="button"
                      onClick={() => onSelectProject(p.id, 'editor')}
                      className="flex-1 py-2 px-3 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold transition-colors"
                    >
                      {t(lang, 'المحرر', 'Editor')}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
