import { useState } from 'react';
import { Check, Copy, KeyRound, LogOut, Save, Trash2 } from 'lucide-react';
import { t } from '../i18n';
import { api } from '../lib/api';
import type { Lang, User } from '../types';
import { ResilientImage } from './ResilientImage';

interface AccountSettingsViewProps {
  lang: Lang;
  user: User;
  onUserUpdated: (user: User) => void;
  onLoggedOut: () => void;
}

export function AccountSettingsView({
  lang,
  user,
  onUserUpdated,
  onLoggedOut,
}: AccountSettingsViewProps) {
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email || '');
  const [bio, setBio] = useState(user.bio || '');
  const [preferredLanguage, setPreferredLanguage] = useState<Lang>(user.preferredLanguage);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [recoveryKey, setRecoveryKey] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState(false);

  const [confirmDelete, setConfirmDelete] = useState(false);
  const [savingProfile, setSavingProfile] = useState(false);
  const [savingPass, setSavingPass] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setNotice(null);
    setSavingProfile(true);
    try {
      const res = await api.updateProfile({
        name,
        email: email.trim() || undefined,
        bio,
        preferredLanguage,
      });
      onUserUpdated(res.user);
      setNotice(t(lang, 'تم تحديث الملف الشخصي بنجاح.', 'Profile updated successfully.'));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update profile');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setNotice(null);
    setSavingPass(true);
    try {
      const res = await api.changePassword({
        currentPassword: user.hasPassword ? currentPassword : undefined,
        newPassword,
      });
      onUserUpdated(res.user);
      setCurrentPassword('');
      setNewPassword('');
      setNotice(t(lang, 'تم حفظ كلمة المرور الجديدة.', 'Password updated.'));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Password change failed');
    } finally {
      setSavingPass(false);
    }
  };

  const handleRegenerateKey = async () => {
    setError(null);
    setNotice(null);
    try {
      const res = await api.regenerateRecoveryKey();
      setRecoveryKey(res.recoveryKey);
      onUserUpdated(res.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate recovery key');
    }
  };

  const handleLogout = async () => {
    try {
      await api.logout();
    } finally {
      onLoggedOut();
    }
  };

  const handleDeleteAccount = async () => {
    setError(null);
    setDeleting(true);
    try {
      await api.deleteAccount();
      onLoggedOut();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete account');
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-8 max-w-4xl">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {t(lang, 'الملف الشخصي وإعدادات الحساب', 'Profile & Account Settings')}
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {t(
              lang,
              'إدارة بياناتك الشخصية، حالة الجلسة، كلمة المرور، وحذف الحساب.',
              'Manage your profile details, session status, password security, and account deletion.'
            )}
          </p>
        </div>

        <button
          type="button"
          onClick={handleLogout}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <LogOut className="w-4 h-4" />
          <span>{t(lang, 'تسجيل الخروج', 'Sign Out')}</span>
        </button>
      </div>

      {error && (
        <div role="alert" className="p-4 rounded-xl border border-red-500/30 bg-red-500/10 text-red-700 dark:text-red-300 text-sm">
          {error}
        </div>
      )}
      {notice && (
        <div className="p-4 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 text-sm">
          {notice}
        </div>
      )}

      {/* Profile Header & Login Status */}
      <section className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] flex flex-col sm:flex-row sm:items-center justify-between gap-5">
        <div className="flex items-center gap-4">
          <ResilientImage
            src={user.avatarUrl || '/src/assets/images/studio_creator_avatar_1795782744107.jpg'}
            alt={user.name}
            className="w-16 h-16 rounded-2xl object-cover border border-slate-200 dark:border-slate-700 shrink-0"
          />
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">{user.name}</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {user.email || t(lang, 'مسجل عبر منصة خارجية', 'Authenticated via OAuth')}
            </p>
            <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
              <span>{t(lang, 'حالة الجلسة: مسجل الدخول', 'Session: Signed In')}</span>
              <span aria-hidden="true">·</span>
              <span>
                {t(lang, 'الحسابات المرتبطة:', 'Linked:')}{' '}
                {user.linkedAccounts.length > 0
                  ? user.linkedAccounts.map((a) => (a.provider === 'facebook' ? 'Facebook' : 'TikTok')).join(' · ')
                  : t(lang, 'لا يوجد', 'None')}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Edit Profile Form */}
      <form
        onSubmit={handleSaveProfile}
        className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-4"
      >
        <h2 className="text-base font-bold text-slate-900 dark:text-white">
          {t(lang, 'تعديل بيانات الملف الشخصي', 'Edit Profile Information')}
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t(lang, 'الاسم الكامل', 'Full Name')}
            </label>
            <input
              type="text"
              required
              minLength={2}
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t(lang, 'البريد الإلكتروني', 'Email Address')}
            </label>
            <input
              type="email"
              dir="ltr"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="creator@example.com"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="sm:col-span-2">
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t(lang, 'نبذة تعريفية', 'Creator Bio')}
            </label>
            <input
              type="text"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder={t(lang, 'صانع محتوى قصصي وفيديوهات قصيرة...', 'Digital storyteller & creator...')}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t(lang, 'اللغة المفضلة', 'Preferred Language')}
            </label>
            <select
              value={preferredLanguage}
              onChange={(e) => setPreferredLanguage(e.target.value as Lang)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
            >
              <option value="ar">العربية</option>
              <option value="en">English</option>
            </select>
          </div>
        </div>

        <button
          type="submit"
          disabled={savingProfile}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-60 text-white text-xs font-semibold"
        >
          <Save className="w-4 h-4" />
          <span>{savingProfile ? t(lang, 'جاري الحفظ...', 'Saving...') : t(lang, 'حفظ التعديلات', 'Save Changes')}</span>
        </button>
      </form>

      {/* Password & Recovery Key */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <form
          onSubmit={handleChangePassword}
          className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-4"
        >
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            {user.hasPassword
              ? t(lang, 'تغيير كلمة المرور', 'Change Password')
              : t(lang, 'تعيين كلمة مرور للحساب', 'Set Account Password')}
          </h2>

          {user.hasPassword && (
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                {t(lang, 'كلمة المرور الحالية', 'Current Password')}
              </label>
              <input
                type="password"
                required
                dir="ltr"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t(lang, 'كلمة المرور الجديدة (8 أحرف على الأقل)', 'New Password (min 8 chars)')}
            </label>
            <input
              type="password"
              required
              minLength={8}
              dir="ltr"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
            />
          </div>

          <button
            type="submit"
            disabled={savingPass}
            className="px-4 py-2.5 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white text-xs font-semibold"
          >
            {savingPass ? t(lang, 'جاري التحديث...', 'Updating...') : t(lang, 'حفظ كلمة المرور', 'Update Password')}
          </button>
        </form>

        <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-4">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            {t(lang, 'رمز الاسترداد الاحتياطي', 'Backup Recovery Key')}
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            {t(
              lang,
              'يمكنك توليد رمز استرداد جديد لاستخدامه في استعادة كلمة المرور دون الحاجة لخدمة بريد خارجية.',
              'Generate a fresh backup recovery key to regain access to your account anytime.'
            )}
          </p>

          {recoveryKey && (
            <div className="p-3 rounded-xl border border-amber-500/30 bg-amber-500/10 flex items-center justify-between gap-2">
              <code className="font-mono-nums text-xs font-semibold text-amber-700 dark:text-amber-300">
                {recoveryKey}
              </code>
              <button
                type="button"
                onClick={async () => {
                  await navigator.clipboard.writeText(recoveryKey);
                  setCopiedKey(true);
                  setTimeout(() => setCopiedKey(false), 2000);
                }}
                className="p-1.5 rounded-lg bg-amber-600 text-white"
              >
                {copiedKey ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          )}

          <button
            type="button"
            onClick={handleRegenerateKey}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <KeyRound className="w-4 h-4" />
            <span>{t(lang, 'توليد رمز استرداد جديد', 'Generate New Recovery Key')}</span>
          </button>
        </div>
      </div>

      {/* Delete Account Zone */}
      <section className="p-6 rounded-2xl border border-red-500/30 bg-red-500/5 space-y-4">
        <h2 className="text-base font-bold text-red-700 dark:text-red-400">
          {t(lang, 'حذف الحساب نهائياً', 'Delete Account')}
        </h2>
        <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
          {t(
            lang,
            'سيؤدي حذف الحساب إلى مسح جميع مشاريعك وقصصك ومشاهدك وارتباطات المنصات بشكل نهائي ولا يمكن التراجع عنه.',
            'Deleting your account permanently removes all your projects, scenes, sessions, and linked platform tokens.'
          )}
        </p>

        {!confirmDelete ? (
          <button
            type="button"
            onClick={() => setConfirmDelete(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-red-500/40 text-red-600 dark:text-red-400 hover:bg-red-500/10 text-xs font-semibold"
          >
            <Trash2 className="w-4 h-4" />
            <span>{t(lang, 'حذف حسابي', 'Delete My Account')}</span>
          </button>
        ) : (
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              disabled={deleting}
              onClick={handleDeleteAccount}
              className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold"
            >
              {deleting ? t(lang, 'جاري الحذف...', 'Deleting...') : t(lang, 'تأكيد الحذف النهائي', 'Confirm Permanent Deletion')}
            </button>
            <button
              type="button"
              onClick={() => setConfirmDelete(false)}
              className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-medium"
            >
              {t(lang, 'إلغاء', 'Cancel')}
            </button>
          </div>
        )}
      </section>
    </div>
  );
}
