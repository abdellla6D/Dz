import { useEffect, useRef, useState } from 'react';
import {
  Check,
  Copy,
  Download,
  FileAudio,
  Loader2,
  Mic,
  MicOff,
  PhoneCall,
  PhoneOff,
  Sparkles,
  Upload,
  Volume2,
} from 'lucide-react';
import { VOICE_OPTIONS, t } from '../i18n';
import { api, getAuthToken } from '../lib/api';
import type { Lang, Project, Scene, SectionKey, ToastMessage } from '../types';

interface VoiceoverStudioViewProps {
  lang: Lang;
  projects: Project[];
  activeProject: Project | null;
  scenes: Scene[];
  onSelectProject: (id: string) => void;
  onSceneUpdated: (scene: Scene) => void;
  onNavigate: (section: SectionKey) => void;
  onToast?: (toast: Omit<ToastMessage, 'id'>) => void;
}

interface LiveTranscriptItem {
  id: string;
  role: 'user' | 'assistant';
  text: string;
}

function float32ToPcm16Base64(input: Float32Array): string {
  const buffer = new ArrayBuffer(input.length * 2);
  const view = new DataView(buffer);
  for (let i = 0; i < input.length; i++) {
    const sample = Math.max(-1, Math.min(1, input[i]));
    view.setInt16(i * 2, sample < 0 ? sample * 0x8000 : sample * 0x7fff, true);
  }
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function pcm16Base64ToFloat32(base64: string): Float32Array {
  const binary = atob(base64);
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  const view = new DataView(bytes.buffer);
  const samples = new Float32Array(Math.floor(len / 2));
  for (let i = 0; i < samples.length; i++) {
    samples[i] = view.getInt16(i * 2, true) / 32768;
  }
  return samples;
}

function fileToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('Failed to read audio file'));
    reader.readAsDataURL(blob);
  });
}

export function VoiceoverStudioView({
  lang,
  projects,
  activeProject,
  scenes,
  onSelectProject,
  onSceneUpdated,
  onNavigate,
  onToast,
}: VoiceoverStudioViewProps) {
  const [voiceName, setVoiceName] = useState<'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr'>(
    activeProject?.voice_name ?? 'Kore'
  );
  const [styleHint, setStyleHint] = useState('');
  const [customText, setCustomText] = useState('');
  const [customAudio, setCustomAudio] = useState<string | null>(null);
  const [ttsLang, setTtsLang] = useState<Lang>(activeProject?.language ?? lang);

  const [generatingId, setGeneratingId] = useState<string | null>(null);
  const [batchRunning, setBatchRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // Live API Voice Conversation refs & state
  const wsRef = useRef<WebSocket | null>(null);
  const liveActiveRef = useRef(false);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const nextStartTimeRef = useRef(0);
  const activeSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const [liveStatus, setLiveStatus] = useState<'idle' | 'connecting' | 'connected'>('idle');
  const [liveTranscripts, setLiveTranscripts] = useState<LiveTranscriptItem[]>([]);

  // Audio Transcription (gemini-3.5-transcribe) state
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [transcriptText, setTranscriptText] = useState('');
  const [copiedTranscript, setCopiedTranscript] = useState(false);

  const stopLiveSession = () => {
    liveActiveRef.current = false;
    setLiveStatus('idle');

    for (const src of activeSourcesRef.current) {
      try {
        src.stop();
      } catch {
        // ignore
      }
    }
    activeSourcesRef.current.clear();
    nextStartTimeRef.current = 0;

    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current.onaudioprocess = null;
      processorRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((tr) => tr.stop());
      mediaStreamRef.current = null;
    }
    if (inputAudioCtxRef.current) {
      void inputAudioCtxRef.current.close().catch(() => {});
      inputAudioCtxRef.current = null;
    }
    if (outputAudioCtxRef.current) {
      void outputAudioCtxRef.current.close().catch(() => {});
      outputAudioCtxRef.current = null;
    }
    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch {
        // ignore
      }
      wsRef.current = null;
    }
  };

  useEffect(() => {
    return () => {
      stopLiveSession();
    };
  }, []);

  const appendLiveTranscript = (role: 'user' | 'assistant', chunk: string) => {
    const clean = chunk.trim();
    if (!clean) return;
    setLiveTranscripts((prev) => {
      const last = prev[prev.length - 1];
      if (last && last.role === role) {
        return [...prev.slice(0, -1), { ...last, text: `${last.text} ${clean}` }];
      }
      return [...prev, { id: `${Date.now()}-${Math.random()}`, role, text: clean }];
    });
  };

  const playPcm24kChunk = (base64Audio: string) => {
    const ctx = outputAudioCtxRef.current;
    if (!ctx) return;

    const samples = pcm16Base64ToFloat32(base64Audio);
    if (samples.length === 0) return;

    const audioBuffer = ctx.createBuffer(1, samples.length, 24000);
    audioBuffer.copyToChannel(new Float32Array(samples), 0);

    const src = ctx.createBufferSource();
    src.buffer = audioBuffer;
    src.connect(ctx.destination);

    const now = ctx.currentTime;
    const startAt = Math.max(now, nextStartTimeRef.current);
    src.start(startAt);
    nextStartTimeRef.current = startAt + audioBuffer.duration;

    activeSourcesRef.current.add(src);
    src.onended = () => {
      activeSourcesRef.current.delete(src);
    };
  };

  const handleStartLiveSession = async () => {
    if (liveStatus !== 'idle') return;
    setError(null);
    setLiveStatus('connecting');

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;

      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;

      const inputCtx = new AudioCtx({ sampleRate: 16000 });
      const outputCtx = new AudioCtx({ sampleRate: 24000 });
      inputAudioCtxRef.current = inputCtx;
      outputAudioCtxRef.current = outputCtx;
      nextStartTimeRef.current = 0;

      const wsProto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const token = getAuthToken();
      const params = new URLSearchParams({
        voiceName,
        lang: ttsLang,
      });
      if (token) params.set('token', token);

      const ws = new WebSocket(`${wsProto}//${window.location.host}/api/live?${params.toString()}`);
      wsRef.current = ws;

      ws.onopen = () => {
        liveActiveRef.current = true;
        setLiveStatus('connected');

        const source = inputCtx.createMediaStreamSource(stream);
        const processor = inputCtx.createScriptProcessor(4096, 1, 1);
        processorRef.current = processor;

        processor.onaudioprocess = (ev) => {
          if (!liveActiveRef.current || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
            return;
          }
          const pcmBase64 = float32ToPcm16Base64(ev.inputBuffer.getChannelData(0));
          wsRef.current.send(JSON.stringify({ audio: pcmBase64 }));
        };

        source.connect(processor);
        processor.connect(inputCtx.destination);
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(String(event.data)) as {
            audio?: string;
            inputTranscript?: string;
            outputTranscript?: string;
            interrupted?: boolean;
            error?: string;
          };
          if (msg.error) {
            setError(msg.error);
            onToast?.({
              type: 'error',
              title: 'Gemini Live API',
              description: msg.error,
            });
            stopLiveSession();
            return;
          }
          if (msg.interrupted) {
            for (const src of activeSourcesRef.current) {
              try {
                src.stop();
              } catch {
                // ignore
              }
            }
            activeSourcesRef.current.clear();
            nextStartTimeRef.current = 0;
          }
          if (msg.inputTranscript) appendLiveTranscript('user', msg.inputTranscript);
          if (msg.outputTranscript) appendLiveTranscript('assistant', msg.outputTranscript);
          if (msg.audio) playPcm24kChunk(msg.audio);
        } catch {
          // ignore
        }
      };

      ws.onerror = () => {
        setError(t(lang, 'تعذر الاتصال بخدمة المحادثة الصوتية الفورية.', 'Live voice connection error.'));
        stopLiveSession();
      };

      ws.onclose = () => {
        if (liveActiveRef.current) {
          stopLiveSession();
        }
      };
    } catch (err) {
      stopLiveSession();
      setError(
        err instanceof Error
          ? err.message
          : t(lang, 'يرجى السماح بالوصول إلى الميكروفون للمحادثة الفورية.', 'Microphone permission is required.')
      );
    }
  };

  const runTranscribeBlob = async (blob: Blob) => {
    setError(null);
    setTranscribing(true);
    try {
      const dataUrl = await fileToDataUrl(blob);
      const res = await api.transcribeAudio({
        audioBase64: dataUrl,
        mimeType: blob.type || 'audio/webm',
        language: ttsLang,
      });
      setTranscriptText(res.transcript);
      onToast?.({
        type: 'success',
        title: t(lang, 'تم تفريغ الصوت بنجاح', 'Audio Transcribed'),
        description: t(lang, 'يمكنك الآن استخدام النص في التعليق الصوتي.', 'Transcript is ready to use.'),
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : t(lang, 'فشل تفريغ الصوت.', 'Transcription failed.');
      setError(msg);
      onToast?.({
        type: 'error',
        title: 'Gemini Transcribe',
        description: msg,
      });
    } finally {
      setTranscribing(false);
    }
  };

  const handleToggleMicRecord = async () => {
    if (isRecording && mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      return;
    }

    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      recordedChunksRef.current = [];
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) recordedChunksRef.current.push(ev.data);
      };

      recorder.onstop = () => {
        stream.getTracks().forEach((tr) => tr.stop());
        const blob = new Blob(recordedChunksRef.current, { type: recorder.mimeType || 'audio/webm' });
        void runTranscribeBlob(blob);
      };

      recorder.start();
      setIsRecording(true);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : t(lang, 'تعذر الوصول إلى الميكروفون للتسجيل.', 'Could not access microphone for recording.')
      );
    }
  };

  const handleGenerateSceneAudio = async (scene: Scene) => {
    setError(null);
    setNotice(null);
    setGeneratingId(scene.id);
    try {
      const res = await api.generateVoiceover({
        text: scene.narration_text || scene.title,
        voiceName,
        style: styleHint,
        language: activeProject?.language ?? ttsLang,
        sceneId: scene.id,
      });
      onSceneUpdated({ ...scene, audio_data_url: res.audioDataUrl });
      setNotice(t(lang, `تم توليد الصوت للمشهد ${scene.scene_order}`, `Generated voiceover for scene ${scene.scene_order}`));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Voiceover generation failed');
    } finally {
      setGeneratingId(null);
    }
  };

  const handleBatchGenerate = async () => {
    if (scenes.length === 0) return;
    setError(null);
    setNotice(null);
    setBatchRunning(true);
    try {
      for (const sc of scenes) {
        if (!sc.narration_text.trim()) continue;
        setGeneratingId(sc.id);
        const res = await api.generateVoiceover({
          text: sc.narration_text,
          voiceName,
          style: styleHint,
          language: activeProject?.language ?? ttsLang,
          sceneId: sc.id,
        });
        onSceneUpdated({ ...sc, audio_data_url: res.audioDataUrl });
      }
      setNotice(t(lang, 'تم توليد التعليق الصوتي لجميع المشاهد بنجاح.', 'Generated voiceovers for all scenes.'));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Batch voiceover generation failed');
    } finally {
      setGeneratingId(null);
      setBatchRunning(false);
    }
  };

  const handleCustomVoiceover = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setGeneratingId('custom');
    try {
      const res = await api.generateVoiceover({
        text: customText,
        voiceName,
        style: styleHint,
        language: ttsLang,
      });
      setCustomAudio(res.audioDataUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate audio');
    } finally {
      setGeneratingId(null);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {t(lang, 'استوديو التعليق الصوتي', 'AI Voiceover Studio')}
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {t(
              lang,
              'حوّل نصوص المشاهد إلى تعليق صوتي عالي الجودة (WAV) باللغة العربية أو الإنجليزية عبر Gemini TTS.',
              'Convert scene narration into natural Arabic or English WAV audio with Gemini TTS.'
            )}
          </p>
        </div>

        <div className="flex items-center gap-3">
          {projects.length > 0 && (
            <select
              value={activeProject?.id ?? ''}
              onChange={(e) => onSelectProject(e.target.value)}
              className="px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-xs font-medium text-slate-900 dark:text-white"
            >
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.title}
                </option>
              ))}
            </select>
          )}
          <button
            type="button"
            onClick={() => onNavigate('editor')}
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold whitespace-nowrap"
          >
            {t(lang, 'التالي: محرر الفيديو', 'Next: Video Editor')}
          </button>
        </div>
      </div>

      {error && (
        <div role="alert" className="p-4 rounded-xl border border-red-500/30 bg-red-500/10 text-red-700 dark:text-red-300 text-sm">
          {error}
        </div>
      )}
      {notice && (
        <div className="p-4 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 text-sm">
          {notice}
        </div>
      )}

      {/* Voice Settings + Standalone TTS */}
      <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
              {t(lang, 'اختيار الصوت', 'Narrator Voice')}
            </label>
            <select
              value={voiceName}
              onChange={(e) => setVoiceName(e.target.value as typeof voiceName)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
            >
              {VOICE_OPTIONS.map((v) => (
                <option key={v.id} value={v.id}>
                  {lang === 'ar' ? v.ar : v.en}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
              {t(lang, 'نبرة الأداء (اختياري)', 'Vocal Direction (Optional)')}
            </label>
            <input
              type="text"
              value={styleHint}
              onChange={(e) => setStyleHint(e.target.value)}
              placeholder={t(lang, 'مثال: نبرة وثائقية هادئة ومؤثرة', 'e.g. Warm documentary storyteller')}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
              {t(lang, 'اللغة', 'Language')}
            </label>
            <select
              value={ttsLang}
              onChange={(e) => setTtsLang(e.target.value as Lang)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
            >
              <option value="ar">العربية</option>
              <option value="en">English</option>
            </select>
          </div>
        </div>

        <form onSubmit={handleCustomVoiceover} className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
          <label className="block text-xs font-medium text-slate-700 dark:text-slate-300">
            {t(lang, 'تجربة نص تعليق صوتي حر', 'Test Custom Voiceover Script')}
          </label>
          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              required
              value={customText}
              onChange={(e) => setCustomText(e.target.value)}
              placeholder={t(lang, 'اكتب أي جملة عربية أو إنجليزية لتوليد صوتها...', 'Type any Arabic or English text to synthesize...')}
              className="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
            />
            <button
              type="submit"
              disabled={generatingId === 'custom'}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white text-sm font-semibold whitespace-nowrap"
            >
              {generatingId === 'custom' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mic className="w-4 h-4" />}
              <span>{t(lang, 'توليد الصوت', 'Generate Audio')}</span>
            </button>
          </div>
          {customAudio && (
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <audio controls src={customAudio} className="h-10 flex-1 min-w-[240px]" />
              <a
                href={customAudio}
                download="storymaster-voiceover.wav"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <Download className="w-3.5 h-3.5" />
                <span>WAV</span>
              </a>
            </div>
          )}
        </form>
      </div>

      {/* Live Voice Conversation & Audio Transcription Studio */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Gemini Live API (gemini-3.8-live) */}
        <section className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>{t(lang, 'محادثة صوتية فورية مع المخرج الذكي (Gemini Live)', 'Real-Time Voice Director (Gemini Live)')}</span>
              </h2>
              <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                {t(
                  lang,
                  'تحدث مباشرة عبر الميكروفون لتطوير أفكار القصص وصياغة نصوص التعليق الصوتي بصوت تفاعلي فوري.',
                  'Speak live with Gemini to brainstorm story ideas and refine narration scripts in real time.'
                )}
              </p>
            </div>
            {liveStatus === 'idle' ? (
              <button
                type="button"
                onClick={handleStartLiveSession}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold shrink-0"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>{t(lang, 'بدء المحادثة', 'Start Live')}</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={stopLiveSession}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold shrink-0"
              >
                <PhoneOff className="w-3.5 h-3.5" />
                <span>
                  {liveStatus === 'connecting'
                    ? t(lang, 'جاري الاتصال...', 'Connecting...')
                    : t(lang, 'إنهاء المحادثة', 'End Call')}
                </span>
              </button>
            )}
          </div>

          <div className="h-44 overflow-y-auto p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#0B0F17] space-y-2.5 text-xs">
            {liveTranscripts.length === 0 ? (
              <p className="text-slate-500 dark:text-slate-400">
                {liveStatus === 'connected'
                  ? t(lang, 'المحادثة مفتوحة الآن — تحدث في الميكروفون...', 'Connected — speak into your microphone...')
                  : t(lang, 'اضغط "بدء المحادثة" للتحدث صوتياً مع Gemini.', 'Click "Start Live" to talk with Gemini.')}
              </p>
            ) : (
              liveTranscripts.map((item) => (
                <div
                  key={item.id}
                  className={`p-2.5 rounded-lg ${
                    item.role === 'user'
                      ? 'bg-white dark:bg-[#111827] border border-slate-200 dark:border-slate-800'
                      : 'bg-amber-500/10 border border-amber-500/20'
                  }`}
                >
                  <span className="font-bold text-[11px] text-amber-600 dark:text-amber-400 block mb-0.5">
                    {item.role === 'user' ? t(lang, 'أنت', 'You') : 'Gemini Live'}
                  </span>
                  <p className="text-slate-800 dark:text-slate-200 leading-relaxed">{item.text}</p>
                </div>
              ))
            )}
          </div>
        </section>

        {/* Audio Transcription (gemini-3.5-transcribe) */}
        <section className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <FileAudio className="w-4 h-4 text-amber-500" />
              <span>{t(lang, 'تفريغ الصوت إلى نص (Transcribe Audio)', 'Transcribe Audio to Text')}</span>
            </h2>
            <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              {t(
                lang,
                'سجّل صوتك أو ارفع ملفاً صوتياً لتحويله بدقة إلى نص عربي أو إنجليزي عبر Gemini 3.5 Transcribe.',
                'Record your voice or upload an audio clip to transcribe speech accurately into text.'
              )}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              disabled={transcribing}
              onClick={handleToggleMicRecord}
              className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold text-white ${
                isRecording ? 'bg-red-600 hover:bg-red-500' : 'bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700'
              }`}
            >
              {isRecording ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
              <span>
                {isRecording ? t(lang, 'إيقاف وتفريغ التسجيل', 'Stop & Transcribe') : t(lang, 'تسجيل من الميكروفون', 'Record Mic')}
              </span>
            </button>

            <label className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800">
              <Upload className="w-3.5 h-3.5" />
              <span>{t(lang, 'رفع ملف صوتي', 'Upload Audio')}</span>
              <input
                type="file"
                accept="audio/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) void runTranscribeBlob(file);
                }}
              />
            </label>

            {transcribing && (
              <span className="inline-flex items-center gap-1.5 text-xs text-amber-600 dark:text-amber-400">
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>{t(lang, 'جاري التفريغ...', 'Transcribing...')}</span>
              </span>
            )}
          </div>

          <textarea
            rows={4}
            value={transcriptText}
            onChange={(e) => setTranscriptText(e.target.value)}
            placeholder={t(lang, 'سيظهر النص المفرّغ هنا...', 'Transcribed text will appear here...')}
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-xs sm:text-sm leading-relaxed"
          />

          {transcriptText.trim() && (
            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={() => setCustomText(transcriptText)}
                className="px-3.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold"
              >
                {t(lang, 'إرسال إلى نص التعليق الصوتي', 'Use in Voiceover Script')}
              </button>
              <button
                type="button"
                onClick={async () => {
                  await navigator.clipboard.writeText(transcriptText);
                  setCopiedTranscript(true);
                  setTimeout(() => setCopiedTranscript(false), 2000);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold"
              >
                {copiedTranscript ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedTranscript ? t(lang, 'تم النسخ', 'Copied') : t(lang, 'نسخ النص', 'Copy')}</span>
              </button>
            </div>
          )}
        </section>
      </div>

      {/* Project Scenes Audio List */}
      {activeProject && scenes.length > 0 && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {t(lang, 'التعليق الصوتي لمشاهد المشروع', 'Project Scene Voiceovers')}
            </h2>
            <button
              type="button"
              disabled={batchRunning}
              onClick={handleBatchGenerate}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-60 text-white text-xs font-semibold"
            >
              {batchRunning ? <Loader2 className="w-4 h-4 animate-spin" /> : <Volume2 className="w-4 h-4" />}
              <span>{t(lang, 'توليد الصوت لكل المشاهد', 'Generate All Scenes')}</span>
            </button>
          </div>

          <div className="space-y-3">
            {scenes.map((sc) => (
              <div
                key={sc.id}
                className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] flex flex-col lg:flex-row lg:items-center justify-between gap-4"
              >
                <div className="flex-1 space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono-nums text-xs font-bold text-amber-500">
                      {String(sc.scene_order).padStart(2, '0')}
                    </span>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">{sc.title}</h3>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                    {sc.narration_text}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-3 shrink-0">
                  {sc.audio_data_url && (
                    <audio controls src={sc.audio_data_url} className="h-9 max-w-[240px]" />
                  )}
                  <button
                    type="button"
                    disabled={generatingId === sc.id}
                    onClick={() => handleGenerateSceneAudio(sc)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-60 text-white text-xs font-semibold whitespace-nowrap"
                  >
                    {generatingId === sc.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Mic className="w-3.5 h-3.5" />}
                    <span>
                      {sc.audio_data_url
                        ? t(lang, 'إعادة التوليد', 'Regenerate')
                        : t(lang, 'توليد الصوت', 'Generate')}
                    </span>
                  </button>
                  {sc.audio_data_url && (
                    <a
                      href={sc.audio_data_url}
                      download={`scene-${sc.scene_order}.wav`}
                      className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                      aria-label={t(lang, 'تنزيل الصوت', 'Download audio')}
                    >
                      <Download className="w-4 h-4" />
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
