export function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="inline-flex items-center gap-2.5 shrink-0 select-none">
      <svg
        width="32"
        height="32"
        viewBox="0 0 36 36"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
        className="shrink-0"
      >
        <rect width="36" height="36" rx="9" fill="#D97706" />
        <rect x="6" y="8" width="24" height="20" rx="3" stroke="#0B0F17" strokeWidth="2.2" />
        <path d="M15 14L23 18L15 22V14Z" fill="#0B0F17" />
        <path d="M10 8V12M26 8V12M10 24V28M26 24V28" stroke="#0B0F17" strokeWidth="2" strokeLinecap="round" />
      </svg>
      {!compact && (
        <span className="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-slate-50 whitespace-nowrap">
          StoryMaster AI
        </span>
      )}
    </div>
  );
}
