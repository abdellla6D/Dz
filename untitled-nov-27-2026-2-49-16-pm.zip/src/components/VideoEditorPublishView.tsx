import { useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  Download,
  Film,
  Loader2,
  Pause,
  Play,
  Send,
  Sparkles,
  Square,
  Upload,
  XCircle,
} from 'lucide-react';
import { t } from '../i18n';
import { api, ApiError } from '../lib/api';
import type {
  FacebookPage,
  Lang,
  Project,
  PublishJob,
  Scene,
  SectionKey,
  ToastMessage,
  User,
} from '../types';

interface VideoEditorPublishViewProps {
  lang: Lang;
  user: User;
  projects: Project[];
  activeProject: Project | null;
  scenes: Scene[];
  publishJobs: PublishJob[];
  onSelectProject: (id: string) => void;
  onSceneUpdated: (scene: Scene) => void;
  onJobCreated: (job: PublishJob) => void;
  onNavigate: (section: SectionKey) => void;
  onToast?: (toast: Omit<ToastMessage, 'id'>) => void;
}

function getCanvasDimensions(ratio: '9:16' | '16:9' | '1:1'): { width: number; height: number } {
  if (ratio === '16:9') return { width: 1280, height: 720 };
  if (ratio === '1:1') return { width: 1080, height: 1080 };
  return { width: 720, height: 1280 };
}

function wrapTextLines(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
  const words = text.trim().split(/\s+/);
  const lines: string[] = [];
  let current = '';
  for (const word of words) {
    const test = current ? `${current} ${word}` : word;
    if (ctx.measureText(test).width > maxWidth && current) {
      lines.push(current);
      current = word;
    } else {
      current = test;
    }
  }
  if (current) lines.push(current);
  return lines.slice(0, 4);
}

function loadImage(src: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('Failed to read video file'));
    reader.readAsDataURL(blob);
  });
}

export function VideoEditorPublishView({
  lang,
  user,
  projects,
  activeProject,
  scenes,
  publishJobs,
  onSelectProject,
  onSceneUpdated,
  onJobCreated,
  onNavigate,
  onToast,
}: VideoEditorPublishViewProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const loadedImagesRef = useRef<Map<string, HTMLImageElement | null>>(new Map());
  const audioElRef = useRef<HTMLAudioElement | null>(null);
  const rafRef = useRef<number | null>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [exportedVideoUrl, setExportedVideoUrl] = useState<string | null>(null);
  const [exportedBlob, setExportedBlob] = useState<Blob | null>(null);

  // AI Text-to-Video (gemini-omni-1.2-flash) state
  const [aiVideoPrompt, setAiVideoPrompt] = useState('');
  const [aiVideoRatio, setAiVideoRatio] = useState<'16:9' | '9:16'>('16:9');
  const [aiVideoDuration, setAiVideoDuration] = useState<'5s' | '8s' | '10s'>('5s');
  const [generatingAiVideo, setGeneratingAiVideo] = useState(false);
  const [aiVideoUrl, setAiVideoUrl] = useState<string | null>(null);

  // Publishing state
  const [pubPlatform, setPubPlatform] = useState<'tiktok' | 'facebook'>('facebook');
  const [pubTitle, setPubTitle] = useState(activeProject?.title ?? '');
  const [pubDesc, setPubDesc] = useState('');
  const [fbPages, setFbPages] = useState<FacebookPage[]>([]);
  const [selectedPageId, setSelectedPageId] = useState('');
  const [fbMediaType, setFbMediaType] = useState<'video' | 'photo' | 'text'>('video');
  const [tkPrivacy, setTkPrivacy] = useState<
    'SELF_ONLY' | 'PUBLIC_TO_EVERYONE' | 'MUTUAL_FOLLOW_FRIENDS' | 'FOLLOWER_OF_CREATOR'
  >('SELF_ONLY');
  const [tkDisableComment, setTkDisableComment] = useState(false);
  const [tkDisableDuet, setTkDisableDuet] = useState(false);
  const [tkDisableStitch, setTkDisableStitch] = useState(false);
  const [customUploadBlob, setCustomUploadBlob] = useState<Blob | null>(null);
  const [customUploadName, setCustomUploadName] = useState<string | null>(null);

  const [loadingPages, setLoadingPages] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pubSuccess, setPubSuccess] = useState<string | null>(null);

  const aspectRatio = activeProject?.aspect_ratio ?? '9:16';
  const dims = useMemo(() => getCanvasDimensions(aspectRatio), [aspectRatio]);

  const timeline = useMemo(() => {
    let cursor = 0;
    return scenes.map((sc) => {
      const start = cursor;
      const dur = Math.max(2, Number(sc.duration_sec) || 6);
      cursor += dur;
      return { scene: sc, start, end: cursor, duration: dur };
    });
  }, [scenes]);

  const totalDuration = timeline.length > 0 ? timeline[timeline.length - 1].end : 0;

  useEffect(() => {
    if (activeProject) {
      setPubTitle(activeProject.title);
      setPubDesc(activeProject.story_text.slice(0, 400));
    }
  }, [activeProject]);

  // Preload scene images for smooth canvas rendering
  useEffect(() => {
    let cancelled = false;
    const loadAll = async () => {
      for (const sc of scenes) {
        const src = sc.image_data_url || '/src/assets/images/scene_sample_oasis_1795782743585.jpg';
        if (!loadedImagesRef.current.has(src)) {
          const img = await loadImage(src);
          if (!cancelled) loadedImagesRef.current.set(src, img);
        }
      }
      renderFrameAt(currentTime);
    };
    void loadAll();
    return () => {
      cancelled = true;
    };
  }, [scenes, dims.width, dims.height]);

  const fbAccount = user.linkedAccounts.find((a) => a.provider === 'facebook');
  const tkAccount = user.linkedAccounts.find((a) => a.provider === 'tiktok');

  useEffect(() => {
    if (fbAccount) {
      const metaPages = (fbAccount.metadata?.pages as FacebookPage[] | undefined) || [];
      if (metaPages.length > 0) {
        setFbPages(metaPages);
        setSelectedPageId(metaPages[0].id);
      }
    }
  }, [fbAccount]);

  const renderFrameAt = (timeSec: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { width, height } = dims;
    ctx.fillStyle = '#0B0F17';
    ctx.fillRect(0, 0, width, height);

    if (timeline.length === 0) {
      ctx.fillStyle = '#94A3B8';
      ctx.font = '600 28px "IBM Plex Sans Arabic", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(t(lang, 'اختر مشروعاً لعرض المشاهد', 'Select a project to preview'), width / 2, height / 2);
      return;
    }

    const activeItem =
      timeline.find((item) => timeSec >= item.start && timeSec < item.end) || timeline[timeline.length - 1];
    const sc = activeItem.scene;
    const localElapsed = Math.max(0, timeSec - activeItem.start);
    const progress = Math.min(1, localElapsed / activeItem.duration);

    const imgSrc = sc.image_data_url || '/src/assets/images/scene_sample_oasis_1795782743585.jpg';
    const img = loadedImagesRef.current.get(imgSrc);

    ctx.save();
    // Transitions & Ken Burns
    let alpha = 1;
    if (sc.transition === 'fade' && localElapsed < 0.5) {
      alpha = localElapsed / 0.5;
    }
    ctx.globalAlpha = Math.max(0.05, Math.min(1, alpha));

    let scale = 1.0 + progress * 0.08;
    let offsetX = 0;
    if (sc.transition === 'zoom') {
      scale = 1.04 + progress * 0.14;
    } else if (sc.transition === 'slide' && localElapsed < 0.45) {
      offsetX = (1 - localElapsed / 0.45) * 60;
    }

    if (img) {
      const imgRatio = img.width / img.height;
      const canvasRatio = width / height;
      let drawW = width;
      let drawH = height;
      if (imgRatio > canvasRatio) {
        drawH = height * scale;
        drawW = drawH * imgRatio;
      } else {
        drawW = width * scale;
        drawH = drawW / imgRatio;
      }
      const dx = (width - drawW) / 2 + offsetX;
      const dy = (height - drawH) / 2;
      ctx.drawImage(img, dx, dy, drawW, drawH);
    } else {
      const grad = ctx.createLinearGradient(0, 0, width, height);
      grad.addColorStop(0, '#1E293B');
      grad.addColorStop(1, '#0F172A');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
    }
    ctx.restore();

    // Bottom contrast scrim & subtitles
    if (sc.subtitle_enabled && sc.narration_text.trim()) {
      const scrimGrad = ctx.createLinearGradient(0, height * 0.62, 0, height);
      scrimGrad.addColorStop(0, 'rgba(0,0,0,0)');
      scrimGrad.addColorStop(1, 'rgba(0,0,0,0.85)');
      ctx.fillStyle = scrimGrad;
      ctx.fillRect(0, height * 0.62, width, height * 0.38);

      const fontSize = aspectRatio === '16:9' ? 32 : 28;
      ctx.font = `600 ${fontSize}px "IBM Plex Sans Arabic", "Outfit", sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.direction = activeProject?.language === 'ar' ? 'rtl' : 'ltr';

      const lines = wrapTextLines(ctx, sc.narration_text, width * 0.84);
      const lineHeight = fontSize * 1.45;
      const startY = height - Math.max(80, lines.length * lineHeight + 36);

      lines.forEach((line, idx) => {
        const y = startY + idx * lineHeight;
        ctx.fillStyle = 'rgba(0,0,0,0.75)';
        ctx.fillText(line, width / 2 + 2, y + 2);
        ctx.fillStyle = '#F8FAFC';
        ctx.fillText(line, width / 2, y);
      });
    }
  };

  useEffect(() => {
    renderFrameAt(currentTime);
  }, [currentTime, timeline, dims]);

  useEffect(() => {
    if (!isPlaying) {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      if (audioElRef.current) {
        audioElRef.current.pause();
      }
      return;
    }

    let lastTs = performance.now();
    let activeAudioSceneId: string | null = null;

    const tick = (now: number) => {
      const dt = (now - lastTs) / 1000;
      lastTs = now;

      setCurrentTime((prev) => {
        const next = prev + dt;
        if (next >= totalDuration) {
          setIsPlaying(false);
          return 0;
        }

        const item = timeline.find((it) => next >= it.start && next < it.end);
        if (item && item.scene.id !== activeAudioSceneId) {
          activeAudioSceneId = item.scene.id;
          if (audioElRef.current) {
            audioElRef.current.pause();
            if (item.scene.audio_data_url) {
              audioElRef.current.src = item.scene.audio_data_url;
              audioElRef.current.currentTime = Math.max(0, next - item.start);
              void audioElRef.current.play().catch(() => {});
            }
          }
        }
        return next;
      });

      rafRef.current = requestAnimationFrame(tick);
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [isPlaying, totalDuration, timeline]);

  const handleStop = () => {
    setIsPlaying(false);
    setCurrentTime(0);
    if (audioElRef.current) {
      audioElRef.current.pause();
      audioElRef.current.currentTime = 0;
    }
  };

  const handleExportVideo = async () => {
    if (timeline.length === 0 || !canvasRef.current) return;
    setError(null);
    setIsPlaying(false);
    setIsExporting(true);
    setExportProgress(0);

    try {
      const canvas = canvasRef.current;
      const stream = canvas.captureStream(30);

      // Build mixed audio track using Web Audio API
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const audioCtx = new AudioCtx();
      const dest = audioCtx.createMediaStreamDestination();

      for (const item of timeline) {
        if (item.scene.audio_data_url) {
          try {
            const resp = await fetch(item.scene.audio_data_url);
            const arr = await resp.arrayBuffer();
            const decoded = await audioCtx.decodeAudioData(arr);
            const src = audioCtx.createBufferSource();
            src.buffer = decoded;
            src.connect(dest);
            src.start(audioCtx.currentTime + item.start);
          } catch {
            // Skip invalid audio buffer gracefully
          }
        }
      }

      const combinedStream = new MediaStream([
        ...stream.getVideoTracks(),
        ...dest.stream.getAudioTracks(),
      ]);

      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')
        ? 'video/webm;codecs=vp9,opus'
        : 'video/webm';

      const recorder = new MediaRecorder(combinedStream, { mimeType, videoBitsPerSecond: 3_500_000 });
      const chunks: Blob[] = [];
      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunks.push(ev.data);
      };

      const donePromise = new Promise<Blob>((resolve) => {
        recorder.onstop = () => {
          resolve(new Blob(chunks, { type: 'video/webm' }));
        };
      });

      recorder.start(250);
      const startTime = performance.now();

      await new Promise<void>((resolve) => {
        const step = () => {
          const elapsed = (performance.now() - startTime) / 1000;
          renderFrameAt(Math.min(elapsed, totalDuration));
          setExportProgress(Math.min(99, Math.round((elapsed / Math.max(0.1, totalDuration)) * 100)));
          if (elapsed >= totalDuration) {
            resolve();
          } else {
            requestAnimationFrame(step);
          }
        };
        requestAnimationFrame(step);
      });

      recorder.stop();
      const finalBlob = await donePromise;
      await audioCtx.close();

      if (exportedVideoUrl) URL.revokeObjectURL(exportedVideoUrl);
      const url = URL.createObjectURL(finalBlob);
      setExportedBlob(finalBlob);
      setExportedVideoUrl(url);
      setExportProgress(100);
    } catch (err) {
      setError(err instanceof Error ? err.message : t(lang, 'فشل تصدير الفيديو.', 'Video export failed.'));
    } finally {
      setIsExporting(false);
    }
  };

  const handleGenerateAiVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiVideoPrompt.trim()) return;
    setError(null);
    setGeneratingAiVideo(true);
    try {
      const res = await api.generateVideo({
        prompt: aiVideoPrompt.trim(),
        aspectRatio: aiVideoRatio,
        duration: aiVideoDuration,
      });
      const sourceUrl = res.videoDataUrl || res.videoUri;
      if (!sourceUrl) {
        throw new Error(t(lang, 'لم يتم إرجاع رابط فيديو صالح.', 'No video asset returned.'));
      }
      setAiVideoUrl(sourceUrl);
      onToast?.({
        type: 'success',
        title: t(lang, 'تم توليد الفيديو بالذكاء الاصطناعي', 'AI Video Generated'),
        description: t(lang, 'يمكنك معاينته أو استخدامه مباشرة في النشر.', 'Preview it below or select it for publishing.'),
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : t(lang, 'فشل توليد الفيديو.', 'Video generation failed.');
      setError(msg);
      onToast?.({
        type: 'error',
        title: t(lang, 'تعذر توليد الفيديو', 'AI Video Generation Error'),
        description: msg,
      });
    } finally {
      setGeneratingAiVideo(false);
    }
  };

  const handleUseAiVideoForPublish = async () => {
    if (!aiVideoUrl) return;
    try {
      const resp = await fetch(aiVideoUrl);
      const blob = await resp.blob();
      setCustomUploadBlob(blob);
      setCustomUploadName('gemini-omni-video.mp4');
      onToast?.({
        type: 'info',
        title: t(lang, 'تم تحديد فيديو Gemini للنشر', 'AI Video Selected'),
        description: t(lang, 'الفيديو جاهز الآن للنشر على Facebook أو TikTok.', 'Ready to publish to Facebook or TikTok.'),
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to prepare video blob';
      setError(msg);
    }
  };

  const handleLoadFbPages = async () => {
    setError(null);
    setLoadingPages(true);
    try {
      const res = await api.getFacebookPages();
      setFbPages(res.pages);
      if (res.pages.length > 0) setSelectedPageId(res.pages[0].id);
      onToast?.({
        type: 'success',
        title: 'Facebook Pages API',
        description: t(
          lang,
          `تم تحديث قائمة الصفحات (${res.pages.length} صفحة).`,
          `Loaded ${res.pages.length} Facebook Pages.`
        ),
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to load Facebook Pages';
      setError(msg);
      onToast?.({
        type: 'error',
        title: 'Facebook Pages API',
        description: msg,
      });
    } finally {
      setLoadingPages(false);
    }
  };

  const handlePublish = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setPubSuccess(null);
    setPublishing(true);

    try {
      const videoBlob = customUploadBlob || exportedBlob;

      if (pubPlatform === 'facebook') {
        if (!fbAccount) {
          throw new Error(t(lang, 'يرجى ربط حساب Facebook أولاً.', 'Please connect your Facebook account first.'));
        }
        const selectedPage = fbPages.find((p) => p.id === selectedPageId);
        if (!selectedPage) {
          throw new Error(t(lang, 'يرجى اختيار صفحة فيسبوك للنشر عليها.', 'Please select a Facebook Page to publish to.'));
        }

        let mediaBase64: string | undefined;
        let mediaMimeType: string | undefined;

        if (fbMediaType === 'video') {
          if (!videoBlob) {
            throw new Error(
              t(lang, 'يرجى تصدير الفيديو أولاً أو رفع ملف فيديو.', 'Please export the video or upload a video file first.')
            );
          }
          mediaBase64 = await blobToBase64(videoBlob);
          mediaMimeType = videoBlob.type || 'video/webm';
        } else if (fbMediaType === 'photo') {
          const firstImg = scenes.find((s) => s.image_data_url?.startsWith('data:image'))?.image_data_url;
          if (!firstImg) {
            throw new Error(t(lang, 'لا توجد صورة مشهد مولّدة للنشر.', 'No scene image available for photo post.'));
          }
          mediaBase64 = firstImg;
          mediaMimeType = 'image/png';
        }

        const res = await api.publishFacebook({
          projectId: activeProject?.id,
          pageId: selectedPage.id,
          pageName: selectedPage.name,
          title: pubTitle,
          description: pubDesc,
          mediaType: fbMediaType,
          mediaBase64,
          mediaMimeType,
        });
        onJobCreated(res.job);
        const okMsg = t(
          lang,
          `تم النشر على صفحة ${selectedPage.name} بنجاح.`,
          `Published to Facebook Page ${selectedPage.name}.`
        );
        setPubSuccess(okMsg);
        onToast?.({
          type: 'success',
          title: t(lang, 'اكتمل النشر على Facebook', 'Published to Facebook'),
          description: okMsg,
        });
      } else {
        if (!tkAccount) {
          throw new Error(t(lang, 'يرجى ربط حساب TikTok أولاً.', 'Please connect your TikTok account first.'));
        }
        if (!videoBlob) {
          throw new Error(
            t(lang, 'يرجى تصدير الفيديو أولاً أو رفع ملف فيديو قبل النشر على TikTok.', 'Please export or upload a video file before publishing to TikTok.')
          );
        }
        const videoBase64 = await blobToBase64(videoBlob);
        const res = await api.publishTikTok({
          projectId: activeProject?.id,
          title: pubTitle,
          description: pubDesc,
          privacyLevel: tkPrivacy,
          disableComment: tkDisableComment,
          disableDuet: tkDisableDuet,
          disableStitch: tkDisableStitch,
          videoBase64,
          videoMimeType: videoBlob.type || 'video/webm',
        });
        onJobCreated(res.job);
        const okMsg = t(
          lang,
          'تم إرسال الفيديو إلى TikTok Content Posting API بنجاح.',
          'Video submitted to TikTok Content Posting API.'
        );
        setPubSuccess(okMsg);
        onToast?.({
          type: 'success',
          title: t(lang, 'اكتمل النشر على TikTok', 'Submitted to TikTok'),
          description: okMsg,
        });
      }
    } catch (err) {
      if (err instanceof ApiError && err.details?.job) {
        onJobCreated(err.details.job as PublishJob);
      }
      const msg = err instanceof Error ? err.message : 'Publishing failed';
      setError(msg);
      onToast?.({
        type: 'error',
        title:
          pubPlatform === 'facebook'
            ? t(lang, 'خطأ أثناء النشر عبر Facebook API', 'Facebook Publishing Error')
            : t(lang, 'خطأ أثناء النشر عبر TikTok API', 'TikTok Publishing Error'),
        description: msg,
      });
    } finally {
      setPublishing(false);
    }
  };

  return (
    <div className="space-y-8">
      <audio ref={audioElRef} className="hidden" />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {t(lang, 'محرر الفيديو والنشر المباشر', 'Video Editor & Social Publishing')}
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            {t(
              lang,
              'عاين المشاهد مع الصوت والترجمة، صدّر الفيديو بصيغة WebM، وانشره عبر واجهات TikTok وFacebook الرسمية.',
              'Preview scenes with synced TTS & subtitles, export WebM video, and publish via official Facebook & TikTok APIs.'
            )}
          </p>
        </div>

        {projects.length > 0 && (
          <select
            value={activeProject?.id ?? ''}
            onChange={(e) => onSelectProject(e.target.value)}
            className="px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-xs font-medium text-slate-900 dark:text-white self-start"
          >
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.title}
              </option>
            ))}
          </select>
        )}
      </div>

      {error && (
        <div role="alert" className="p-4 rounded-xl border border-red-500/30 bg-red-500/10 text-red-700 dark:text-red-300 text-sm leading-relaxed">
          {error}
        </div>
      )}
      {pubSuccess && (
        <div className="p-4 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 text-sm">
          {pubSuccess}
        </div>
      )}

      {/* Video Player & Timeline Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Canvas Preview Column */}
        <div className="lg:col-span-5 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              {t(lang, 'معاينة الاستوديو', 'Studio Preview')} ({aspectRatio})
            </span>
            <span className="font-mono-nums text-xs text-slate-500 dark:text-slate-400">
              {currentTime.toFixed(1)}s / {totalDuration.toFixed(1)}s
            </span>
          </div>

          <div className="rounded-xl overflow-hidden bg-black flex items-center justify-center max-h-[460px]">
            <canvas
              ref={canvasRef}
              width={dims.width}
              height={dims.height}
              className="max-h-[450px] w-auto max-w-full object-contain"
            />
          </div>

          <input
            type="range"
            min={0}
            max={Math.max(0.1, totalDuration)}
            step={0.1}
            value={currentTime}
            onChange={(e) => {
              setIsPlaying(false);
              setCurrentTime(Number(e.target.value));
            }}
            className="w-full accent-amber-500"
          />

          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={timeline.length === 0 || isExporting}
                onClick={() => setIsPlaying((p) => !p)}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white text-xs font-semibold"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                <span>{isPlaying ? t(lang, 'إيقاف مؤقت', 'Pause') : t(lang, 'تشغيل', 'Play')}</span>
              </button>
              <button
                type="button"
                onClick={handleStop}
                className="p-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                aria-label={t(lang, 'إيقاف', 'Stop')}
              >
                <Square className="w-4 h-4" />
              </button>
            </div>

            <button
              type="button"
              disabled={timeline.length === 0 || isExporting}
              onClick={handleExportVideo}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 disabled:opacity-50 text-white text-xs font-semibold"
            >
              {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Film className="w-4 h-4" />}
              <span>
                {isExporting
                  ? `${t(lang, 'جاري التصيير', 'Rendering')} ${exportProgress}%`
                  : t(lang, 'تصدير الفيديو (WebM)', 'Export Video')}
              </span>
            </button>
          </div>

          {exportedVideoUrl && (
            <div className="p-3.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 flex items-center justify-between gap-3">
              <span className="text-xs font-medium text-emerald-700 dark:text-emerald-300">
                {t(lang, 'الفيديو جاهز للتحميل والنشر!', 'Video rendered & ready!')}
              </span>
              <a
                href={exportedVideoUrl}
                download={`${activeProject?.title || 'storymaster'}.webm`}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{t(lang, 'تنزيل', 'Download')}</span>
              </a>
            </div>
          )}
        </div>

        {/* Scene Timeline Controls */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-4">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {t(lang, 'الخط الزمني للمشاهد', 'Scene Timeline')}
            </h2>

            {scenes.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400">
                {t(lang, 'لا توجد مشاهد في هذا المشروع بعد.', 'No scenes in this project yet.')}
              </p>
            ) : (
              <div className="space-y-3 max-h-[460px] overflow-y-auto pe-1">
                {scenes.map((sc) => (
                  <div
                    key={sc.id}
                    className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#0B0F17] flex flex-wrap items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-[180px] flex-1">
                      <span className="font-mono-nums text-xs font-bold text-amber-500">
                        {String(sc.scene_order).padStart(2, '0')}
                      </span>
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-900 dark:text-white truncate">{sc.title}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                          {sc.audio_data_url ? t(lang, 'صوت جاهز', 'Audio ready') : t(lang, 'بدون صوت', 'No audio')}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <select
                        value={sc.transition}
                        onChange={async (e) => {
                          const res = await api.updateScene(sc.id, {
                            transition: e.target.value as Scene['transition'],
                          });
                          onSceneUpdated(res.scene);
                        }}
                        className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-xs"
                      >
                        <option value="fade">{t(lang, 'تلاشي (Fade)', 'Fade')}</option>
                        <option value="zoom">{t(lang, 'تقريب (Zoom)', 'Zoom')}</option>
                        <option value="slide">{t(lang, 'انزلاق (Slide)', 'Slide')}</option>
                        <option value="none">{t(lang, 'مباشر (Cut)', 'Cut')}</option>
                      </select>

                      <input
                        type="number"
                        min={2}
                        max={60}
                        value={sc.duration_sec}
                        onChange={async (e) => {
                          const val = Math.max(2, Number(e.target.value) || 6);
                          const res = await api.updateScene(sc.id, { durationSec: val });
                          onSceneUpdated(res.scene);
                        }}
                        className="w-16 px-2 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-xs font-mono-nums text-center"
                      />

                      <label className="inline-flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={Boolean(sc.subtitle_enabled)}
                          onChange={async (e) => {
                            const res = await api.updateScene(sc.id, { subtitleEnabled: e.target.checked });
                            onSceneUpdated(res.scene);
                          }}
                          className="accent-amber-500"
                        />
                        <span>{t(lang, 'ترجمة', 'Subtitles')}</span>
                      </label>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* AI Text-to-Video Generator (gemini-omni-1.2-flash) */}
      <section className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <span>{t(lang, 'توليد فيديو من النص بالذكاء الاصطناعي (Omni Flash)', 'AI Text-to-Video Studio (Omni Flash)')}</span>
            </h2>
            <p className="mt-1 text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              {t(
                lang,
                'أنشئ مقطع فيديو سينمائي عالي الدقة (720p MP4) مباشرة من وصف نصي عبر Gemini Omni Flash واستخدمه في النشر.',
                'Generate a 720p MP4 clip directly from a prompt using Gemini Omni Flash and send it to publishing.'
              )}
            </p>
          </div>
          {scenes[0]?.image_prompt && (
            <button
              type="button"
              onClick={() => setAiVideoPrompt(scenes[0].image_prompt)}
              className="px-3.5 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              {t(lang, 'استيراد وصف المشهد الأول', 'Import Scene 1 Prompt')}
            </button>
          )}
        </div>

        <form onSubmit={handleGenerateAiVideo} className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-end">
          <div className="lg:col-span-6">
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t(lang, 'الوصف البصري للفيديو (يفضل بالإنجليزية)', 'Video Generation Prompt')}
            </label>
            <input
              type="text"
              required
              minLength={5}
              value={aiVideoPrompt}
              onChange={(e) => setAiVideoPrompt(e.target.value)}
              placeholder="Cinematic golden desert dunes at sunset, slow aerial drone tracking shot..."
              dir="ltr"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
            />
          </div>

          <div className="lg:col-span-2">
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t(lang, 'الأبعاد', 'Aspect Ratio')}
            </label>
            <select
              value={aiVideoRatio}
              onChange={(e) => setAiVideoRatio(e.target.value as '16:9' | '9:16')}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
            >
              <option value="16:9">16:9 (Landscape)</option>
              <option value="9:16">9:16 (Vertical Reels/TikTok)</option>
            </select>
          </div>

          <div className="lg:col-span-2">
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t(lang, 'المدة', 'Duration')}
            </label>
            <select
              value={aiVideoDuration}
              onChange={(e) => setAiVideoDuration(e.target.value as '5s' | '8s' | '10s')}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
            >
              <option value="5s">5s</option>
              <option value="8s">8s</option>
              <option value="10s">10s</option>
            </select>
          </div>

          <div className="lg:col-span-2">
            <button
              type="submit"
              disabled={generatingAiVideo}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-60 text-white text-xs font-semibold min-h-[42px]"
            >
              {generatingAiVideo ? <Loader2 className="w-4 h-4 animate-spin" /> : <Film className="w-4 h-4" />}
              <span>{generatingAiVideo ? t(lang, 'جاري التوليد...', 'Generating...') : t(lang, 'توليد فيديو AI', 'Generate Video')}</span>
            </button>
          </div>
        </form>

        {aiVideoUrl && (
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#0B0F17] flex flex-col md:flex-row items-center gap-4">
            <video controls src={aiVideoUrl} className="w-full md:w-72 rounded-xl bg-black max-h-56" />
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={handleUseAiVideoForPublish}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{t(lang, 'استخدام هذا الفيديو للنشر', 'Use for Publishing')}</span>
              </button>
              <a
                href={aiVideoUrl}
                download="storymaster-omni-video.mp4"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <Download className="w-3.5 h-3.5" />
                <span>MP4</span>
              </a>
            </div>
          </div>
        )}
      </section>

      {/* Publishing Section (Facebook Pages & TikTok Content Posting API) */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <form
          onSubmit={handlePublish}
          className="lg:col-span-7 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-5"
        >
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              {t(lang, 'النشر المباشر على المنصات', 'Publish to Connected Platforms')}
            </h2>

            <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setPubPlatform('facebook')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  pubPlatform === 'facebook'
                    ? 'bg-white dark:bg-[#111827] text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                Facebook Pages
              </button>
              <button
                type="button"
                onClick={() => setPubPlatform('tiktok')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  pubPlatform === 'tiktok'
                    ? 'bg-white dark:bg-[#111827] text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                TikTok Content API
              </button>
            </div>
          </div>

          {/* Video source selector */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#0B0F17] flex flex-wrap items-center justify-between gap-3">
            <div className="text-xs">
              <p className="font-semibold text-slate-900 dark:text-white">
                {t(lang, 'مصدر الفيديو للنشر', 'Video Source')}
              </p>
              <p className="text-slate-500 dark:text-slate-400 mt-0.5">
                {customUploadName
                  ? `${t(lang, 'ملف مرفوع:', 'Uploaded:')} ${customUploadName}`
                  : exportedBlob
                  ? t(lang, 'يتم استخدام الفيديو المصدّر من المحرر حالياً', 'Using rendered WebM video from editor')
                  : t(lang, 'قم بتصدير الفيديو من المحرر أو ارفع ملف MP4/WebM', 'Export from editor or upload an MP4/WebM file')}
              </p>
            </div>
            <label className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#111827] text-xs font-semibold cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-800">
              <Upload className="w-3.5 h-3.5" />
              <span>{t(lang, 'اختيار ملف فيديو', 'Choose Video File')}</span>
              <input
                type="file"
                accept="video/mp4,video/webm,video/quicktime"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    setCustomUploadBlob(file);
                    setCustomUploadName(file.name);
                  }
                }}
              />
            </label>
          </div>

          {pubPlatform === 'facebook' && (
            <div className="space-y-4">
              {!fbAccount ? (
                <div className="p-4 rounded-xl border border-amber-500/30 bg-amber-500/10 flex items-center justify-between gap-3">
                  <p className="text-xs text-amber-800 dark:text-amber-300">
                    {t(lang, 'حساب Facebook غير مرتبط بعد.', 'Facebook account is not connected yet.')}
                  </p>
                  <button
                    type="button"
                    onClick={() => onNavigate('accounts')}
                    className="px-3 py-1.5 rounded-lg bg-amber-600 text-white text-xs font-semibold whitespace-nowrap"
                  >
                    {t(lang, 'ربط Facebook', 'Connect Facebook')}
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-medium text-slate-700 dark:text-slate-300">
                        {t(lang, 'صفحة فيسبوك المستهدفة', 'Target Facebook Page')}
                      </label>
                      <button
                        type="button"
                        onClick={handleLoadFbPages}
                        disabled={loadingPages}
                        className="text-xs text-amber-600 dark:text-amber-400 hover:underline"
                      >
                        {loadingPages ? t(lang, 'جاري التحديث...', 'Refreshing...') : t(lang, 'تحديث الصفحات', 'Refresh Pages')}
                      </button>
                    </div>
                    <select
                      value={selectedPageId}
                      onChange={(e) => setSelectedPageId(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
                    >
                      {fbPages.length === 0 ? (
                        <option value="">{t(lang, 'اضغط تحديث الصفحات لجلب صفحاتك', 'Click Refresh Pages')}</option>
                      ) : (
                        fbPages.map((pg) => (
                          <option key={pg.id} value={pg.id}>
                            {pg.name}
                          </option>
                        ))
                      )}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                      {t(lang, 'نوع المنشور', 'Post Format')}
                    </label>
                    <select
                      value={fbMediaType}
                      onChange={(e) => setFbMediaType(e.target.value as 'video' | 'photo' | 'text')}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
                    >
                      <option value="video">{t(lang, 'فيديو (Page Video API)', 'Video (Page Video API)')}</option>
                      <option value="photo">{t(lang, 'صورة المشهد الأول', 'First Scene Photo')}</option>
                      <option value="text">{t(lang, 'منشور نصي', 'Text Post')}</option>
                    </select>
                  </div>
                </div>
              )}
            </div>
          )}

          {pubPlatform === 'tiktok' && (
            <div className="space-y-4">
              {!tkAccount ? (
                <div className="p-4 rounded-xl border border-amber-500/30 bg-amber-500/10 flex items-center justify-between gap-3">
                  <p className="text-xs text-amber-800 dark:text-amber-300">
                    {t(lang, 'حساب TikTok غير مرتبط بعد.', 'TikTok account is not connected yet.')}
                  </p>
                  <button
                    type="button"
                    onClick={() => onNavigate('accounts')}
                    className="px-3 py-1.5 rounded-lg bg-amber-600 text-white text-xs font-semibold whitespace-nowrap"
                  >
                    {t(lang, 'ربط TikTok', 'Connect TikTok')}
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                      {t(lang, 'إعدادات الخصوصية', 'Privacy Level')}
                    </label>
                    <select
                      value={tkPrivacy}
                      onChange={(e) => setTkPrivacy(e.target.value as typeof tkPrivacy)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
                    >
                      <option value="SELF_ONLY">{t(lang, 'خاص بي فقط (SELF_ONLY)', 'Only Me (SELF_ONLY)')}</option>
                      <option value="PUBLIC_TO_EVERYONE">{t(lang, 'عام للجميع (PUBLIC)', 'Public to Everyone')}</option>
                      <option value="MUTUAL_FOLLOW_FRIENDS">{t(lang, 'الأصدقاء (Friends)', 'Friends')}</option>
                      <option value="FOLLOWER_OF_CREATOR">{t(lang, 'المتابعون (Followers)', 'Followers')}</option>
                    </select>
                  </div>

                  <div className="flex flex-wrap items-center gap-4 pt-5 text-xs text-slate-700 dark:text-slate-300">
                    <label className="inline-flex items-center gap-1.5">
                      <input
                        type="checkbox"
                        checked={tkDisableComment}
                        onChange={(e) => setTkDisableComment(e.target.checked)}
                        className="accent-amber-500"
                      />
                      <span>{t(lang, 'تعطيل التعليقات', 'No comments')}</span>
                    </label>
                    <label className="inline-flex items-center gap-1.5">
                      <input
                        type="checkbox"
                        checked={tkDisableDuet}
                        onChange={(e) => setTkDisableDuet(e.target.checked)}
                        className="accent-amber-500"
                      />
                      <span>{t(lang, 'تعطيل Duet', 'No duet')}</span>
                    </label>
                    <label className="inline-flex items-center gap-1.5">
                      <input
                        type="checkbox"
                        checked={tkDisableStitch}
                        onChange={(e) => setTkDisableStitch(e.target.checked)}
                        className="accent-amber-500"
                      />
                      <span>{t(lang, 'تعطيل Stitch', 'No stitch')}</span>
                    </label>
                  </div>
                </div>
              )}
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t(lang, 'عنوان الفيديو', 'Video Title')}
            </label>
            <input
              type="text"
              required
              value={pubTitle}
              onChange={(e) => setPubTitle(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              {t(lang, 'الوصف والوسوم (Hashtags)', 'Description & Hashtags')}
            </label>
            <textarea
              rows={3}
              value={pubDesc}
              onChange={(e) => setPubDesc(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#0B0F17] text-sm"
            />
          </div>

          <button
            type="submit"
            disabled={publishing}
            className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-60 text-white text-sm font-semibold"
          >
            {publishing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            <span>
              {publishing
                ? t(lang, 'جاري النشر...', 'Publishing...')
                : pubPlatform === 'facebook'
                ? t(lang, 'نشر على صفحة Facebook', 'Publish to Facebook Page')
                : t(lang, 'نشر على TikTok', 'Publish to TikTok')}
            </span>
          </button>
        </form>

        {/* Publish Jobs History */}
        <div className="lg:col-span-5 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111827] space-y-4">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            {t(lang, 'سجل وحالة عمليات النشر', 'Publishing Status & Logs')}
          </h2>

          {publishJobs.length === 0 ? (
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {t(lang, 'لم تقم بأي عملية نشر بعد.', 'No publishing jobs recorded yet.')}
            </p>
          ) : (
            <div className="space-y-3 max-h-[420px] overflow-y-auto">
              {publishJobs.map((job) => (
                <div
                  key={job.id}
                  className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#0B0F17] space-y-1.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {job.platform === 'facebook' ? 'Facebook' : 'TikTok'} · {job.title}
                    </span>
                    <span
                      className={`inline-flex items-center gap-1 text-xs font-semibold shrink-0 ${
                        job.status === 'published'
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : job.status === 'failed'
                          ? 'text-red-600 dark:text-red-400'
                          : 'text-amber-600 dark:text-amber-400'
                      }`}
                    >
                      {job.status === 'published' ? (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      ) : job.status === 'failed' ? (
                        <XCircle className="w-3.5 h-3.5" />
                      ) : (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      )}
                      <span>
                        {job.status === 'published'
                          ? t(lang, 'تم النشر', 'Published')
                          : job.status === 'failed'
                          ? t(lang, 'فشل', 'Failed')
                          : t(lang, 'قيد المعالجة', 'Processing')}
                      </span>
                    </span>
                  </div>
                  {job.target_name && (
                    <p className="text-xs text-slate-500 dark:text-slate-400">{job.target_name}</p>
                  )}
                  {job.external_post_id && (
                    <p className="text-xs font-mono-nums text-slate-500 dark:text-slate-400">
                      ID: {job.external_post_id}
                    </p>
                  )}
                  {job.error_message && (
                    <p className="text-xs text-red-600 dark:text-red-400 leading-relaxed">{job.error_message}</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
