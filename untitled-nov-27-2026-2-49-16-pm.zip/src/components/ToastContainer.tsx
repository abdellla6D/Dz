import { CheckCircle2, Info, X, XCircle } from 'lucide-react';
import type { ToastMessage } from '../types';

interface ToastContainerProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export function ToastContainer({ toasts, onDismiss }: ToastContainerProps) {
  if (toasts.length === 0) return null;

  return (
    <div
      aria-live="polite"
      className="fixed bottom-5 end-5 z-50 flex flex-col gap-3 w-full max-w-sm pointer-events-none px-4 sm:px-0"
    >
      {toasts.map((toast) => {
        const isSuccess = toast.type === 'success';
        const isError = toast.type === 'error';

        return (
          <div
            key={toast.id}
            role={isError ? 'alert' : 'status'}
            className={`pointer-events-auto flex items-start gap-3 p-4 rounded-2xl border shadow-lg backdrop-blur bg-white/95 dark:bg-[#111827]/95 ${
              isSuccess
                ? 'border-emerald-500/40 text-slate-900 dark:text-white'
                : isError
                ? 'border-red-500/40 text-slate-900 dark:text-white'
                : 'border-amber-500/40 text-slate-900 dark:text-white'
            }`}
          >
            <div className="shrink-0 mt-0.5">
              {isSuccess ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              ) : isError ? (
                <XCircle className="w-5 h-5 text-red-500" />
              ) : (
                <Info className="w-5 h-5 text-amber-500" />
              )}
            </div>

            <div className="flex-1 min-w-0 space-y-1">
              <p className="text-xs sm:text-sm font-bold leading-snug">{toast.title}</p>
              {toast.description && (
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed break-words">
                  {toast.description}
                </p>
              )}
            </div>

            <button
              type="button"
              onClick={() => onDismiss(toast.id)}
              aria-label="Dismiss notification"
              className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
}
