# StoryMaster AI Publisher — النسخة الاحترافية

منصة متكاملة لإنتاج القصص والمشاهد والصور والتعليق الصوتي والفيديو بالذكاء الاصطناعي عبر **Google Gemini**، مع نظام مستخدمين مستقل، وتسجيل دخول رسمي عبر **Facebook Login** و**TikTok Login Kit**، ونشر مباشر عبر **Facebook Pages Publishing API** و**TikTok Content Posting API**.

---

## المزايا الرئيسية

1. **نظام مستخدمين مستقل وآمن + Firebase Auth & Firestore**
   - إنشاء حساب بالبريد الإلكتروني وكلمة المرور (تشفير كلمات المرور بخوارزمية `scrypt`).
   - تسجيل الدخول عبر **Google (Firebase Auth)** ومزامنة بيانات المشاريع وسجلات النشر مع **Cloud Firestore** وفق قواعد أمان صارمة (`firestore.rules`).
   - تسجيل الدخول والخروج وإدارة الجلسات (`Authorization: Bearer` + `HttpOnly` Cookie).
   - استعادة كلمة المرور عبر رمز الاسترداد الاحتياطي (Backup Recovery Key) أو عبر البريد الإلكتروني (`RESEND_API_KEY`).
   - تعديل الملف الشخصي وحذف الحساب نهائياً مع عزل تام لمشاريع كل مستخدم في قاعدة البيانات.

2. **ربط وتسجيل الدخول الرسمي عبر المنصات (OAuth 2.0)**
   - **Facebook Login OAuth v21.0**: يفتح نافذة فيسبوك الرسمية ويعود للتطبيق مع حفظ الرموز مشفرة بـ `AES-256-GCM`.
   - **TikTok Login Kit v2 (PKCE)**: يفتح نافذة تيك توك الرسمية مع دعم `code_challenge` وإدارة فصل وربط الحساب.

3. **الذكاء الاصطناعي عبر Google Gemini (`@google/genai`)**
   - تأليف القصص الطويلة بالعربية والإنجليزية وتقسيمها إلى مشاهد (`gemini-4-hydrogen`).
   - تعديل نص القصة وإعادة توليد المشاهد والأوصاف البصرية.
   - توليد صور المشاهد (`gemini-3.1-flash-lite-image`) أو رفع صور مخصصة.
   - توليد التعليق الصوتي بصيغة WAV (`gemini-3.8-flash-lite-tts`) بالعربية والإنجليزية.
   - **توليد الفيديو من النص (`gemini-omni-1.2-flash`)** بدقة 720p (`16:9` أو `9:16`) مباشرة داخل محرر الفيديو.
   - **المحادثة الصوتية الفورية (`gemini-3.8-live`)** عبر WebSocket (`/api/live`) مع بث صوتي ثنائي الاتجاه وتفريغ فوري للنص.
   - **تفريغ الصوت إلى نص (`gemini-3.5-transcribe`)** من تسجيل الميكروفون أو الملفات الصوتية المرفوعة.

4. **محرر الفيديو والنشر المباشر ونظام التنبيهات (Toast Notifications)**
   - معاينة فورية على Canvas مع حركة Ken Burns وانتقالات وترجمة مدمجة باللغتين.
   - تصدير حقيقي لملف الفيديو (`video/webm`) مدمجاً بالتعليق الصوتي.
   - النشر المباشر عبر **Facebook Pages Publishing API** و**TikTok Content Posting API** مع تنبيهات فورية (Toast) في زاوية الشاشة عند اكتمال النشر أو حدوث أي خطأ مع واجهات البرمجة.

---

## متطلبات التشغيل والإعداد

### 1. تثبيت الاعتمادات
```bash
npm install
```

### 2. إعداد متغيرات البيئة (`.env`)
انسخ ملف `.env.example` إلى `.env` وأضف القيم المطلوبة في بيئة الخادم (لا تضع المفاتيح داخل ملفات HTML أو الواجهة الأمامية):

| المتغير | الوصف | مطلوب؟ |
|---|---|---|
| `GEMINI_API_KEY` | مفتاح Google Gemini API لتوليد القصص والصوت والصور | نعم |
| `APP_URL` | رابط التطبيق الكامل بصيغة HTTPS (يُستخدم لروابط Callback) | نعم |
| `SESSION_SECRET` | مفتاح سري لتوقيع الجلسات وتشفير رموز OAuth | مستحسن |
| `DATABASE_PATH` | مسار قاعدة بيانات SQLite (الافتراضي `./data/storymaster.db`) | اختياري |
| `FACEBOOK_APP_ID` | معرف تطبيق Meta / Facebook | لتسجيل دخول ونشر فيسبوك |
| `FACEBOOK_APP_SECRET` | السر الخاص بتطبيق Meta / Facebook | لتسجيل دخول ونشر فيسبوك |
| `TIKTOK_CLIENT_KEY` | مفتاح تطبيق TikTok Developer | لتسجيل دخول ونشر تيك توك |
| `TIKTOK_CLIENT_SECRET` | السر الخاص بتطبيق TikTok Developer | لتسجيل دخول ونشر تيك توك |
| `RESEND_API_KEY` | مفتاح Resend لإرسال رموز استعادة كلمة المرور بالبريد | اختياري |

---

## إعداد منصات النشر والموافقات الخارجية

### إعداد Facebook (Meta for Developers)
1. أنشئ تطبيقاً من نوع **Business** أو **Consumer** في [Meta for Developers](https://developers.facebook.com/).
2. فعّل منتج **Facebook Login for Business** وأضف رابط Callback التالي في **Valid OAuth Redirect URIs**:
   ```
   https://<YOUR-APP-URL>/auth/facebook/callback
   ```
3. الصلاحيات المطلوبة:
   - لتسجيل الدخول: `public_profile`, `email`.
   - لنشر الفيديوهات والمنشورات على الصفحات: `pages_show_list`, `pages_read_engagement`, `pages_manage_posts` (تتطلب مراجعة Meta App Review للنشر العام، أو إضافة حسابك كـ Admin/Tester أثناء التطوير).

### إعداد TikTok (TikTok for Developers)
1. أنشئ تطبيقاً في [TikTok for Developers](https://developers.tiktok.com/).
2. فعّل **Login Kit** و**Content Posting API**.
3. أضف رابط Redirect URI التالي:
   ```
   https://<YOUR-APP-URL>/auth/tiktok/callback
   ```
4. الصلاحيات المطلوبة:
   - لتسجيل الدخول: `user.info.basic`, `user.info.profile`.
   - لرفع ونشر الفيديوهات: `video.upload`, `video.publish` (يتطلب موافقة TikTok Audit على Content Posting API للنشر العام؛ في وضع Sandbox يمكن النشر بحسابات الاختبار المصرح بها كـ `SELF_ONLY`).

### ملاحظة حول توليد الصور عبر Gemini
- نموذج توليد النصوص والقصص (`gemini-4-hydrogen`) والتعليق الصوتي (`gemini-3.8-flash-lite-tts`) يعملان عبر مفتاح Gemini القياسي.
- نموذج توليد الصور (`gemini-3.1-flash-lite-image`) يتطلب مفتاح Gemini مرتبطاً بحساب فوترة مفعّل (Paid API Key) في **Settings > Secrets**.

---

## أوامر التشغيل والبناء

- **التشغيل في بيئة التطوير:**
  ```bash
  npm run dev
  ```
- **فحص الأنواع (TypeScript):**
  ```bash
  npm run lint
  ```
- **بناء الواجهة للإنتاج:**
  ```bash
  npm run build
  ```
- **التشغيل في الإنتاج (Node.js):**
  ```bash
  NODE_ENV=production npm start
  ```

---

## الأمان وحماية البيانات
- جميع مفاتيح API ورموز OAuth تُعالج حصراً على خادم Node.js ولا تُرسل إلى المتصفح.
- تُشفَّر رموز الوصول (`access_token` / `refresh_token`) داخل قاعدة البيانات باستخدام `AES-256-GCM`.
- يدعم الخادم العمل خلف Reverse Proxy مع HTTPS (`trust proxy`) وكوكيز محمية (`HttpOnly; Secure; SameSite=None; Partitioned`).
