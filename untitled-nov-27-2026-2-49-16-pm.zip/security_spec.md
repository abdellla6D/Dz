# Firestore Security Specification

## 1. Data Invariants
1. Every user profile under `/users/{userId}/private/profile` is readable and writable exclusively by the verified owner (`request.auth.uid == userId` and `email_verified == true`), preventing cross-user PII exposure.
2. Every project document under `/projects/{projectId}` has an immutable `ownerId` matching `request.auth.uid`, valid `id == projectId`, server-verified `createdAt`/`updatedAt == request.time`, and strict field bounds (`title <= 160`, `storyText <= 25000`).
3. Every publish job under `/publishJobs/{jobId}` has an immutable `ownerId == request.auth.uid`, strict platform enum (`facebook` | `tiktok`), and server-enforced `createdAt == request.time`.
4. List queries on `/projects` and `/publishJobs` enforce `resource.data.ownerId == request.auth.uid` at the rule layer.

## 2. Adversarial Payloads ("Dirty Dozen")
1. Unauthenticated read/write on `/projects/p1` -> `PERMISSION_DENIED`
2. Cross-user get on `/users/otherUid/private/profile` -> `PERMISSION_DENIED`
3. Unverified email (`email_verified: false`) attempting create on `/projects/p1` -> `PERMISSION_DENIED`
4. Spoofed `ownerId` (`ownerId: "victimUid"`) on create `/projects/p1` -> `PERMISSION_DENIED`
5. Shadow field injection (`isAdmin: true`) on create `/users/uid/private/profile` -> `PERMISSION_DENIED`
6. Oversized document ID (`1500` chars) on `/projects/{id}` -> `PERMISSION_DENIED`
7. Client-forged timestamp (`createdAt` != `request.time`) -> `PERMISSION_DENIED`
8. Mutating immutable `ownerId` or `createdAt` on `/projects/p1` update -> `PERMISSION_DENIED`
9. Oversized `storyText` (`> 25000` chars) -> `PERMISSION_DENIED`
10. Invalid `aspectRatio` (`"4:5"`) -> `PERMISSION_DENIED`
11. Unfiltered `list` query on `/projects` without `where("ownerId", "==", uid)` -> `PERMISSION_DENIED`
12. Deleting another user's `/publishJobs/j1` -> `PERMISSION_DENIED`
